package com.innovative.logics.wms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

/**
 * This is the main application class for the Innovative Logics Warehouse
 * Management System (WMS). It is a Spring Boot application that initializes and
 * starts the web server. When executed, it launches the application and enables
 * the WMS to receive and respond to HTTP requests.
 * 
 * @author manus
 * @date 15-Apr-2023
 */
@SpringBootApplication
@EnableEncryptableProperties
public class InnovativeLogicsWMSApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(InnovativeLogicsWMSApplication.class, args);
	}

}