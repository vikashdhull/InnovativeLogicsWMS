package com.innovative.logics.wms.controller;

import java.security.Principal;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.OrderDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.PurchaseOrderResponseDto;
import com.innovative.logics.wms.service.PurchaseOrderService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
/**
 * The PurchaseOrderController class defines the REST endpoints for creating
 * and retrieving purchase order details.Endpoints are secured with
 * Spring Security's @PreAuthorize annotation to ensure that only authorized
 * users can perform CRUD operations on purchase order.
 * 
 * @author manus
 * @date 13-Dec-2023
 */

@RestController
@RequestMapping("/orders")
@Slf4j
public class PurchaseOrderController {

	@Autowired
	private PurchaseOrderService purchaseOrderService;

	/**
	 * 
	 * The createPurchaseOrder method is used to create the purchase order based on given details.
	 * 
	 * @author manus
	 * @date 05-Dec-2023
	 * @param orderDto
	 * @return ResponseEntity containing an ApiResponse with the PurchaseIOrderResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<PurchaseOrderResponseDto>> createPurchaseOrder(@Valid @RequestBody final OrderDto orderDto,
			Principal principal) {
		log.info("Enter in createPurchaseOrder Method present in OrderController class");
		ApiResponse<PurchaseOrderResponseDto> response = purchaseOrderService.createPurchaseOrder(orderDto, principal);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	/**
	 * 
	 * The getPurchaseOrderById method is used to get the purchase order based on given orderId.
	 * 
	 * @author manus
	 * @date 07-Dec-2023
	 * @param id
	 * @return ResponseEntity containing an ApiResponse with the PurchaseOrderResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<PurchaseOrderResponseDto>> getPurchaseOrderById(@PathVariable final String id) {
		log.info("Enter in getPurchaseOrderById Method present in OrderController class");
		ApiResponse<PurchaseOrderResponseDto> response = purchaseOrderService.getPurchaseOrderById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	/**
	 * 
	 * The getAllPurchaseOrderByDestination method is used to get the all purchase order
	 * page wise based on given destination and page.
	 * 
	 * @author manus
	 * @date 09-Dec-2023
	 * @param destination
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return ResponseEntity containing an PageableResponse with the PurchaseOrderResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/location")
	public ResponseEntity<PageableResponse<PurchaseOrderResponseDto>> getAllPurchaseOrderByDestination(
			@RequestParam(value = "destination", required = true) String destination,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllPurchaseOrderByDestination Method present in OrderController class");
		PageableResponse<PurchaseOrderResponseDto> response = purchaseOrderService
				.getAllPurchaseOrderByDestination(destination, pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAllPurchaseOrderByDestinationStatusReceived method is used to get the all purchase order
	 * page wise based on given destination and page.
	 * 
	 * @author manus
	 * @date 12-Dec-2023
	 * @param destination
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return ResponseEntity containing an PageableResponse with the PurchaseOrderResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/receive/location")
	public ResponseEntity<PageableResponse<PurchaseOrderResponseDto>> getAllPurchaseOrderByDestinationStatusReceived(
			@RequestParam(value = "destination", required = true) String destination,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllPurchaseOrderByDestinationStatusReceived Method present in OrderController class");
		PageableResponse<PurchaseOrderResponseDto> response = purchaseOrderService
				.getAllReceivedPurchaseOrderByDestination(destination, pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
