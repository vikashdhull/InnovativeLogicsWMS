package com.innovative.logics.wms.dto.response;

import java.time.LocalDateTime;

import com.innovative.logics.wms.entity.InventoryItem;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class StockRecordResponseDto {

	private String id;

	private String productName;

	private String productCode;

	private String locationName;

	private String lotNumber;

	private Long quantityOnHand;

	private String comment;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

	public StockRecordResponseDto(InventoryItem inventoryItem) {

		this.id = inventoryItem.getId();

		this.productName = inventoryItem.getProductAvailability().getProduct().getName();

		this.productCode = inventoryItem.getProductAvailability().getProduct().getCode();

		this.locationName = inventoryItem.getProductAvailability().getLocation().getName();

		this.lotNumber = inventoryItem.getLotNumber();

		this.quantityOnHand = inventoryItem.getQuantityOnHand();

		this.comment = inventoryItem.getComment();

		this.createdDate = inventoryItem.getCreatedDate();

		this.updatedDate = inventoryItem.getUpdatedDate();
	}

}
