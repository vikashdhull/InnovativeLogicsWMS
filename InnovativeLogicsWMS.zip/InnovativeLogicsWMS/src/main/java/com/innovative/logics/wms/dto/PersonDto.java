package com.innovative.logics.wms.dto;

import java.time.LocalDateTime;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class PersonDto {

	private String id;

	@NotBlank(message = "First name is required !!")
	@Size(min = 2, max = 30, message = "First Name must be between 2 and 30 characters long") 
	private String firstName;

	@NotBlank(message = "Last name is required !!")
	@Size(min = 3, max = 30, message = "Last Name must be between 3 and 30 characters long") 
	private String lastName;

	@Email(message = "Invalid User Email !!")
   //@Pattern(regexp = "^[a-z0-9][-a-z0-9._]+@([-a-z0-9]+\\.)+[a-z]{2,5}$", message = "Invalid User Email !!")
    @NotBlank(message = "Email is required !!")
	private String email;

	@Pattern(regexp="(^$|\\d{10})", message = "Invalid Phone number")
	private String phoneNumber;
	
	private String streetAddress;
	
	private String city;
	
	private String state;
	
	private String country;
	
	private String zipCode;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
