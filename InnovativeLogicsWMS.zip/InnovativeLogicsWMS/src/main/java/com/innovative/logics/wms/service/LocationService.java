package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.LocationDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.LocationResponseDto;
import com.innovative.logics.wms.dto.response.NumberOfQuantity;

public interface LocationService {

	/**
	 * This method is used to create the Location based on given details.
	 * 
	 * @author manus
	 * @date 08-May-2023
	 * @param locationDto
	 * @return
	 */
	ApiResponse<LocationResponseDto> createLocation(LocationDto locationDto);

	/**
	 * 
	 * This method is used to update the Location details based on id
	 * 
	 * @author manus
	 * @date 12-Jun-2023
	 * @param locationDto
	 * @param locationGroupId
	 * @return
	 */
	ApiResponse<LocationResponseDto> updateLocation(LocationDto locationDto, String locationGroupId);

	/**
	 * 
	 * This method is used to delete the the location details based on id
	 * 
	 * @author manus
	 * @date 09-Jun-2023
	 * @param locationId
	 * @return
	 */
	ApiResponse<LocationResponseDto> deleteLocationById(String locationId);

	/**
	 * 
	 * This method is used to fetch the single location details based on id
	 * 
	 * @author manus
	 * @date 15-May-2023
	 * @param locationId
	 * @return
	 */
	ApiResponse<LocationResponseDto> getLocationById(String locationId);

	/**
	 * 
	 * This method is used to fetch all the locations
	 * 
	 * @author manus
	 * @date 23-May-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<LocationResponseDto> getAllLocation(int pageNumber, int pageSize, String sortBy, String sortDir);

	/**
	 * 
	 * This method is used to search the locations based on LocationName
	 * 
	 * @author manus
	 * @date 06-Jun-2023
	 * @param keyword
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<LocationResponseDto> searchLocation(String keyword, int pageNumber, int pageSize, String sortBy,
			String sortDir);

	/**
	 * 
	 * This method is used to fetch all the location based on OrganizationName
	 * 
	 * @author manus
	 * @date 17-May-2023
	 * @param organizationId
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<LocationResponseDto> findLocationByOrganizationName(String name, int pageNumber, int pageSize,
			String sortBy, String sortDir);

	/**
	 * 
	 * This method is used to get the locations based on RoleName
	 * 
	 * @author manus
	 * @date 04-Sep-2023
	 * @param roleName
	 * @return
	 */
	ApiResponse<List<LocationResponseDto>> getLocationsByRole(String roleName);

	ApiResponse<List<LocationResponseDto>> getDepotLocationByOrganizationName(String partyName);

	/**
	 * 
	 * This method is used to count all the Supplier
	 * 
	 * @author manus
	 * @date 04-Oct-2023
	 * @return
	 */
	ApiResponse<NumberOfQuantity> getNumberOfSupplier(String org);

}
