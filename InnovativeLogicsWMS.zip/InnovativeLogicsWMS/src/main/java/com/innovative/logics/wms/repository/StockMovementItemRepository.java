package com.innovative.logics.wms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.StockMovementItem;

public interface StockMovementItemRepository extends JpaRepository<StockMovementItem, String> {

	final String FIND_STOCK_MOVEMENT_ITEM_BY_ID = "SELECT oi.* FROM stock_movement_item oi WHERE oi.stock_movement_id = :stockMovementId";
	
	//To handle multiple products against one order	
	  @Query(value = FIND_STOCK_MOVEMENT_ITEM_BY_ID, nativeQuery = true)
	  List<StockMovementItem> findStockMovementItemByStockMovementId(String stockMovementId);



}
