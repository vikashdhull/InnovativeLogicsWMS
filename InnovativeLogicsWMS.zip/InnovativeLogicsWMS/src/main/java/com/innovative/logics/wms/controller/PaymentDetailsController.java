package com.innovative.logics.wms.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PaymentDetailsDto;
import com.innovative.logics.wms.dto.response.PaymentDetailsResponseDto;
import com.innovative.logics.wms.service.PaymentDetailsService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/payments")
@Slf4j
public class PaymentDetailsController {

	@Autowired
	private PaymentDetailsService paymentDetailsService;

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@PostMapping
	public ResponseEntity<ApiResponse<PaymentDetailsResponseDto>> insertPaymentDetails(
			@Valid @RequestBody final PaymentDetailsDto personDto, Principal principal) {
		log.info("Enter in insertPaymentDetails Method present in PaymentDetailsController class");
		ApiResponse<PaymentDetailsResponseDto> response = paymentDetailsService.createPaymentDetails(personDto,
				principal);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPERADMIN')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<PaymentDetailsResponseDto>> updatePaymentDetails(
			@Valid @RequestBody final PaymentDetailsDto paymentDetailsDto, @PathVariable final String id,
			Principal principal) {
		log.info("Enter in updatePaymentDetails Method present in PaymentDetailsController class");
		ApiResponse<PaymentDetailsResponseDto> response = paymentDetailsService.updatePaymentDetails(paymentDetailsDto,
				id, principal);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<PaymentDetailsResponseDto>> getPaymentDetailsById(
			@PathVariable("id") final String id) {
		log.info("Enter in getPaymentDetailsById Method present in PaymentDetailsController class");
		ApiResponse<PaymentDetailsResponseDto> response = paymentDetailsService.getPaymentDetailsById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@GetMapping
	public ResponseEntity<PageableResponse<PaymentDetailsResponseDto>> getAllPaymentDetails(
			@RequestParam(value = "org", required = true) String name,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "email", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllPaymentDetails Method present in PaymentDetailsController class");

		PageableResponse<PaymentDetailsResponseDto> response = paymentDetailsService.getAllPaymentDetails(name,
				pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<PaymentDetailsResponseDto>> deletePaymentDetails(@PathVariable final String id) {
		log.info("Enter in deletePaymentDetails Method present in PaymentDetailsController class");
		ApiResponse<PaymentDetailsResponseDto> response = paymentDetailsService.deletePaymentDetailsById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
}
