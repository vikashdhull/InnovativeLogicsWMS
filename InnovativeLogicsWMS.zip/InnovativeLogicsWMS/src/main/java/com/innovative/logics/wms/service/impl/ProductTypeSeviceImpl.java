package com.innovative.logics.wms.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductTypeDto;
import com.innovative.logics.wms.entity.Party;
import com.innovative.logics.wms.entity.ProductType;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.repository.PartyRepository;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.repository.ProductTypeRepository;
import com.innovative.logics.wms.service.ProductTypeService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProductTypeSeviceImpl implements ProductTypeService {

	@Autowired
	private ProductTypeRepository productTypeRepository;

	@Autowired
	private Environment env;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private PartyRepository partyRepository;

	@Autowired
	private Utility utility;

	private String productTypeFetchErrorMessage = "product.type.fetch.error.message";

	@Override
	public ApiResponse<ProductTypeDto> createProductType(ProductTypeDto productTypeDto) {

		ApiResponse<ProductTypeDto> response = new ApiResponse<>();

		Optional<ProductType> existProductTypeByName = productTypeRepository.findByName(productTypeDto.getName());

		Optional<ProductType> existProductTypeByCode = productTypeRepository.findByCode(productTypeDto.getCode());

		Optional<Party> findOrgByName = partyRepository.findByName(productTypeDto.getParty());

		try {

			if (existProductTypeByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "product.type.name.error.message");
			}

			if (existProductTypeByCode.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "product.type.code.error.message");
			}

			ProductType productType = modelMapper.map(productTypeDto, ProductType.class);

			if (findOrgByName.isPresent()) {
				productType.setParty(findOrgByName.get());
			}
			ProductType savedProductType = productTypeRepository.save(productType);
			ProductTypeDto newDto = entityToDto(savedProductType);

			response.setData(newDto);
			response.setResult(true);
			response.setMessage(env.getProperty("product.type.create.success.message"));
			response.setStatus(HttpStatus.CREATED.value());
			return response;

		} catch (Exception exp) {
			log.error("Exception Occured in createProductType Method present in ProductTypeSeviceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<ProductTypeDto> updateProductType(ProductTypeDto productTypeDto, String productTypeId) {
		ApiResponse<ProductTypeDto> response = new ApiResponse<>();

		Optional<ProductType> productTypeDetails = productTypeRepository.findById(productTypeId);
		Optional<ProductType> existByName = productTypeRepository.findByName(productTypeDto.getName());
		Optional<ProductType> existByCode = productTypeRepository.findByCode(productTypeDto.getCode());

		try {

			if (productTypeDetails.isPresent()) {
				ProductType productTypeData = productTypeDetails.get();

				if (existByName.isPresent() && !Objects.equals(productTypeData.getName(), productTypeDto.getName())) {
					throw new BadApiRequestException(env.getProperty("product.type.name.error.message"));
				}
				productTypeData.setName(productTypeDto.getName());
				if (existByCode.isPresent() && !Objects.equals(productTypeData.getCode(), productTypeDto.getCode())) {
					throw new BadApiRequestException(env.getProperty("product.type.code.error.message"));
				}
				productTypeData.setCode(productTypeDto.getCode());
				productTypeData.setProductIdentifierFormat(productTypeDto.getProductIdentifierFormat());

				ProductType updatedProductType = productTypeRepository.save(productTypeData);
				ProductTypeDto updatedProductTypeDto = entityToDto(updatedProductType);
				response.setData(updatedProductTypeDto);
				response.setResult(true);
				response.setMessage(env.getProperty("product.type.update.success.message"));
				response.setStatus(HttpStatus.OK.value());

				return response;
			} else {
				throw new BadApiRequestException(env.getProperty(productTypeFetchErrorMessage));
			}

		} catch (Exception exp) {
			log.error("Exception Occured in updateProductType Method present in ProductTypeSeviceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<ProductTypeDto> deleteProductTypeById(String productTypeId) {
		ApiResponse<ProductTypeDto> response = new ApiResponse<>();
		try {

			Optional<ProductType> productTypeDetails = productTypeRepository.findById(productTypeId);

			if (productTypeDetails.isPresent()) {

				boolean productTypeInUse = checkIfProductTypeInUse(productTypeId);

				if (productTypeInUse) {
					response.setMessage(env.getProperty("product.type.use.error.message"));
					response.setResult(false);
					response.setStatus(HttpStatus.CONFLICT.value());
					return response;
				}

				productTypeRepository.deleteById(productTypeId);
				response.setMessage(env.getProperty("product.type.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				response.setMessage(env.getProperty(productTypeFetchErrorMessage));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteProductTypeById Method present in ProductTypeSeviceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<ProductTypeDto> getProductTypeById(String productTypeId) {
		ApiResponse<ProductTypeDto> response = new ApiResponse<>();
		try {
			Optional<ProductType> productType = productTypeRepository.findById(productTypeId);

			if (productType.isPresent()) {
				ProductTypeDto productTypeDtoDto = entityToDto(productType.get());
				response.setMessage(env.getProperty("product.type.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(productTypeDtoDto);
				return response;
			} else {
				response.setMessage(env.getProperty(productTypeFetchErrorMessage));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getProductTypeById Method present in ProductTypeSeviceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public PageableResponse<ProductTypeDto> getAllProductType(String org, int pageNumber, int pageSize, String sortBy,
			String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<ProductType> page = productTypeRepository.findProductTypesByParty(org, pageable);

		PageableResponse<ProductTypeDto> response = new PageableResponse<>();
		try {
			if (!page.isEmpty()) {

				List<ProductTypeDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, productTypeFetchErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getAllProductType Method present in ProductTypeSeviceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	private boolean checkIfProductTypeInUse(String productTypeId) {
		return productRepository.existProductTypeInProduct(productTypeId);
	}

	@Override
	public ApiResponse<List<ProductTypeDto>> getAllProductTypesByOrganization(String orgnization) {
		ApiResponse<List<ProductTypeDto>> response = new ApiResponse<>();

		try {
			List<ProductType> productTypesByorg = productTypeRepository.findByPartyName(orgnization);
			if (!productTypesByorg.isEmpty()) {
				List<ProductTypeDto> productTypeDto = productTypesByorg.stream().map(this::entityToDto).toList();

				response.setData(productTypeDto);
				response.setMessage(env.getProperty("product.type.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productTypeFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occured in getAllProductTypesByOrganization Method present in ProductTypeSeviceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private ProductTypeDto entityToDto(ProductType productType) {
		ProductTypeDto productTypeDto = modelMapper.map(productType, ProductTypeDto.class);

		productTypeDto.setParty(productType.getParty().getName());

		return productTypeDto;
	}

}
