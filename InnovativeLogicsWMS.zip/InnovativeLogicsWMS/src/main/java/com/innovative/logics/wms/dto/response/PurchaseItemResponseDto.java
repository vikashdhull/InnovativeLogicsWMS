package com.innovative.logics.wms.dto.response;

import java.time.LocalDate;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PurchaseItemResponseDto {
	
	private String id;

	private String orderType;

	private String name;

	private String description;

	private String orderNumber;
	
	private String status;

	private String origin;

	private String originParty;

	private String destination;

	private String destinationParty;

	private String approvedBy;

	private String orderedBy;

	private String completedBy;
	
	private LocalDate dateApproved;

	private LocalDate dateOrdered;

	private LocalDate dateCompleted;

	private String paymentMethodType;

	private String paymentTerm;
	
	private List<OrderItemResponseDto> orderItem;

}
