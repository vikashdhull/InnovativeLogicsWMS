package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.StockList;

public interface StockListRepository extends JpaRepository<StockList, String> {

	final String EXIST_STOCK_LIST_BY_NAME = "SELECT CASE WHEN EXISTS (SELECT r.* FROM requisition r WHERE r.name = :stockName) THEN 'true' ELSE 'false' END AS result";

	final String FIND_STOCK_LIST_BY_ORIGIN_NAME_AND_DESTINATION_NAME = "SELECT r.* FROM requisition r LEFT JOIN location l ON l.id = r.origin_id LEFT JOIN location ll ON ll.id = r.destination_id WHERE l.name = :originName and ll.name = :destinationName";

	final String EXIST_ORIGIN_LOCATION_IN_STOCK_LIST = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM requisition r WHERE r.origin_id = :originId";

	final String EXIST_DESTINATION_LOCATION_IN_STOCK_LIST = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM requisition r WHERE r.destination_id = :destinationId";

	@Query(value = EXIST_STOCK_LIST_BY_NAME, nativeQuery = true)
	Boolean existStockListByName(String stockName);

	Optional<StockList> findByName(String name);

	@Query(value = FIND_STOCK_LIST_BY_ORIGIN_NAME_AND_DESTINATION_NAME, nativeQuery = true)
	List<StockList> findStockListByOriginAndDestination(String originName, String destinationName);

	@Query(value = EXIST_ORIGIN_LOCATION_IN_STOCK_LIST, nativeQuery = true)
	boolean existOriginInStockList(String originId);

	@Query(value = EXIST_DESTINATION_LOCATION_IN_STOCK_LIST, nativeQuery = true)
	boolean existDestinationInStockList(String destinationId);
	
	@Query(value = "SELECT sl FROM StockList sl WHERE sl.party.name =:name")
	Page<StockList> findStockListsByParty(String name, Pageable pageable);
}
