package com.innovative.logics.wms.service;

import java.security.Principal;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.StockMovementDto;
import com.innovative.logics.wms.dto.StockMovementItemDto;
import com.innovative.logics.wms.dto.StockMovementShippingDto;
import com.innovative.logics.wms.dto.StockMovementUpdateDto;
import com.innovative.logics.wms.dto.response.NumberOfQuantity;
import com.innovative.logics.wms.dto.response.StockMovementResponseDto;
import com.innovative.logics.wms.dto.response.TopDemandingProductResponseDto;
import com.innovative.logics.wms.entity.Location;
import com.innovative.logics.wms.entity.StockMovement;
import com.innovative.logics.wms.entity.StockMovementItem;

public interface StockMovementService {

	/**
	 * 
	 * This createStockMovement method is used to create the stock movement with
	 * multiple products.
	 * 
	 * @author manus
	 * @date 05-Jan-2024
	 * @param stockMovementDto
	 * @return This will return ApiResponse with the StockMovementResponseDto
	 */
	ApiResponse<StockMovementResponseDto> createStockMovement(StockMovementDto stockMovementDto);

	/**
	 * 
	 * This updateStockMovement method is used to update by the shipper with product
	 * availability status and all products status will be given at a single time.
	 * 
	 * @author manus
	 * @date 08-Jan-2024
	 * @param stockMovementUpdateDto
	 * @param movementId
	 * @param principal
	 * @return This will return ApiResponse with the StockMovementResponseDto
	 */
	ApiResponse<StockMovementResponseDto> updateStockMovement(
			Map<String, StockMovementUpdateDto> stockMovementUpdateDto, String movementId, Principal principal);

	/**
	 * 
	 * This shipStockMovement method is used to ship product to the destination
	 * user, user can also partially ship the order.
	 * 
	 * @author manus
	 * @date 11-Jan-2024
	 * @param stockMovementShippingDto
	 * @param principal
	 * @return This will return ApiResponse with the StockMovementResponseDto
	 */
	ApiResponse<StockMovementResponseDto> shipStockMovement(StockMovementShippingDto stockMovementShippingDto,
			Principal principal);

	StockMovement getStockMovement(String movementName);

	Location checkOriginLocation(StockMovementDto stockMovementDto);

	Location checkDestinationLocation(StockMovementDto stockMovementDto);

	void productListCannotBeNull(Collection<StockMovementItemDto> items);

	StockMovementItem checkUserProductShippingStatus(String productName, List<StockMovementItem> filteredList);

	StockMovementResponseDto entityToDto(StockMovement stockMovement);

	/**
	 * 
	 * This method is used to get product and its sum, purchased and transferred
	 * from other locations by given time of the particular organization + location.
	 * 
	 * @author manus
	 * @date 22-Jan-2024
	 * @param topDemandingDto
	 * @return ResponseEntity will return ApiResponse with the
	 *         TopDemandingProductResponseDto
	 */
	ApiResponse<List<TopDemandingProductResponseDto>> getTopDemandingProducts(String locationName,
			String organizationName, LocalDate dateFrom, LocalDate dateTo, Long recordsCount);
	
	ApiResponse<NumberOfQuantity> getPendingMovementCounts(String org);

}