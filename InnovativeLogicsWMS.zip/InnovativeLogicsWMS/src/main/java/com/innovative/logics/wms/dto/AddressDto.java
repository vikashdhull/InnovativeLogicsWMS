package com.innovative.logics.wms.dto;

import java.time.LocalDateTime;

import com.innovative.logics.wms.entity.Address;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AddressDto {

	private String id;

	@Size(max = 30, message = "Address1 maximum 30 characters long")
	private String address1;

	@Size(max = 30, message = "Address2 maximum 30 characters long")
	private String address2;

	@Size(max = 30, message = "Street address maximum 30 characters long")
	private String streetAddress;

	@Size(max = 30, message = "City maximum 30 characters long")
	private String city;

	@Size(max = 30, message = "State maximum 30 characters long")
	private String state;

	@Size(max = 30, message = "Country address maximum 30 characters long")
	private String country;

	@Size(max = 30, message = "Postal code maximum 6 characters long")
	private String postalCode;

	@Size(max = 100, message = "address description maximum 100 characters long")
	private String description;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

	public AddressDto(Address address) {
		this.id = address.getId();
		this.address1 = address.getAddress1();
		this.address2 = address.getAddress2();
		this.streetAddress = address.getStreetAddress();
		this.city = address.getCity();
		this.state = address.getState();
		this.country = address.getCountry();
		this.postalCode = address.getPostalCode();
		this.description = address.getDescription();
		this.createdDate = address.getCreatedDate();
		this.updatedDate = address.getUpdatedDate();
	}

}
