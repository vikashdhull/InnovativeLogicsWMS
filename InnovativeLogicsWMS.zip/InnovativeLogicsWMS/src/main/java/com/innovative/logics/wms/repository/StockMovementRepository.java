package com.innovative.logics.wms.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.innovative.logics.wms.dto.response.NumberOfQuantity;
import com.innovative.logics.wms.entity.StockMovement;

public interface StockMovementRepository extends JpaRepository<StockMovement, String> {

	final String FIND_STOCK_MOVEMENT_BY_ORIGIN_NAME = "SELECT od.* FROM stock_movement od LEFT JOIN location l ON l.id = od.origin_id WHERE l.name = :originName";

	final String GET_TOP_DEMANDING_PRODUCTS = "with top_demanding as"
			+ "((SELECT p.name as product_name, l.name as location_name, smi.date_received as by_date, pa.name as organization_name, smi.quantity "
			+ "from stock_movement_item as smi " + "LEFT JOIN stock_movement as sm on smi.stock_movement_id = sm.id "
			+ "LEFT JOIN location as l on sm.destination_id = l.id "
			+ "LEFT JOIN product as p on smi.product_id = p.id "
			+ "LEFT JOIN party as pa on l.organization_id = pa.id WHERE smi.status='RECEIVED')" + "UNION"
			+ "(SELECT p.name as product_name, l.name as location_name, oi.delivery_date as by_date, pa.name as organization_name, oi.quantity "
			+ "from order_items as oi " + "LEFT JOIN orders as o on oi.order_id = o.id "
			+ "LEFT JOIN location as l on o.destination = l.id " + "LEFT JOIN party as pa on l.organization_id = pa.id "
			+ "LEFT JOIN product as p on oi.product_id = p.id WHERE o.status='RECEIVED'))"
			+ "SELECT td.product_name, td.location_name, td.organization_name, sum(quantity) as quantity from top_demanding as td "
			+ "WHERE td.location_name =:locationName and td.organization_name =:organizationName and "
			+ "by_date between :#{#dateFrom} AND :#{#dateTo} group by product_name order by quantity desc limit :#{#recordsCount}";

	Optional<StockMovement> findByName(String name);

	@Query(value = "SELECT od FROM StockMovement od LEFT JOIN od.origin l WHERE l.name =:originName")
	Page<StockMovement> findStockMovementByOrigin(String originName, Pageable pageable);

	@Query(value = "SELECT od FROM StockMovement od LEFT JOIN od.destination l WHERE l.name =:destinationName")
	Page<StockMovement> findStockMovementByDestination(String destinationName, Pageable pageable);

	@Query(value = GET_TOP_DEMANDING_PRODUCTS, nativeQuery = true)
	List<Object[]> getTopDemandingProducts(@Param("locationName") String locationName,
			@Param("organizationName") String organizationName, @Param("dateFrom") LocalDate dateFrom,
			@Param("dateTo") LocalDate dateTo, @Param("recordsCount") Long recordsCount);

	@Query(value = "SELECT COUNT(*) AS numberOfCount FROM stock_movement stk LEFT JOIN location loc ON stk.origin_id = loc.id WHERE stk.status='PENDING' and loc.name=:origin", nativeQuery = true)
	NumberOfQuantity getPendingStockMovement(String origin);

}
