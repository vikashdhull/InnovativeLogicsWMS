package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.TagDto;
import com.innovative.logics.wms.service.TagService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/tags")
@Slf4j
public class TagController {

	@Autowired
	private TagService tagService;

	/**
	 * 
	 * The createTag method is used to create the Tag and save the data in tag table
	 * based on given details
	 * 
	 * @author manus
	 * @date 09-Aug-2023
	 * @param tagDto
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<TagDto>> createTag(@Valid @RequestBody final TagDto tagDto) {
		log.info("Enter in createTag method present in TagController class");
		ApiResponse<TagDto> response = tagService.createTag(tagDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The updateTag method is used to update the Tag details based on id
	 * 
	 * @author manus
	 * @date 11-Aug-2023
	 * @param tagDto
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<TagDto>> updateTag(@Valid @RequestBody final TagDto tagDto,
			@PathVariable("id") final String id) {
		log.info("Enter in updateTag Method present in TagController class");
		ApiResponse<TagDto> response = tagService.updateTag(tagDto, id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getTagById method is used to fetch the single Tag details from the tag
	 * table based on id
	 * 
	 * @author manus
	 * @date 10-Aug-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<TagDto>> getTagById(@PathVariable("id") final String id) {
		log.info("Enter in getTagById method present in TagController class");
		ApiResponse<TagDto> response = tagService.getTagById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAllTag method is used to fetch all the Tag from the tag table with
	 * Pagination and Sorting
	 * 
	 * @author manus
	 * @date 14-Aug-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<PageableResponse<TagDto>> getAllTag(@RequestParam(value = "org", required = true) String name,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllTag Method present in TagController class");

		PageableResponse<TagDto> response = tagService.getAllTag(name, pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The deleteTagById method is used to delete the Tag from tag table based on id
	 * 
	 * @author manus
	 * @date 05-Sep-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<TagDto>> deleteTagById(@PathVariable final String id) {
		log.info("Enter in deleteTagById Method present in TagController class");
		ApiResponse<TagDto> response = tagService.deleteTagById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('MANAGER') or hasRole('ADMIN') or hasRole('BROWSER')")
	@GetMapping("org")
	public ResponseEntity<ApiResponse<List<TagDto>>> getAllTagsByOrganization(@RequestParam("name") String name) {
		log.info("Enter in getAllTagsByOrganization Method present in TagController class");

		ApiResponse<List<TagDto>> response = tagService.getAllTagsByOrganization(name);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
