package com.innovative.logics.wms.service;

import java.security.Principal;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.OrderItemDto;
import com.innovative.logics.wms.dto.response.PurchaseOrderItemResponseDto;
import com.innovative.logics.wms.dto.response.PurchaseOrderResponseDto;
import com.innovative.logics.wms.entity.Order;

public interface PurchaseOrderItemService {

	/**
	 * 
	 * This createPurchaseOrderWithItems method is used to Ship the purchase Order with 
	 * multiple products.
	 * 
	 * @author manus
	 * @date 15-Dec-2023
	 * @param orderId
	 * @param orderItemDto
	 * @param principal
	 * @return This will return ApiResponse with the PurchaseOrderResponseDto
	 */	
	ApiResponse<PurchaseOrderResponseDto> createPurchaseOrderWithItems(String orderId, List<OrderItemDto> orderItemDto, Principal principal);

	/**
	 * 
	 * This getPurchaseOrderItemsByOrderId method is used to fetch the OrderItems details based on OrderId
	 * 
	 * @author manus
	 * @date 19-Dec-2023
	 * @param orderId
	 * @return This will return ApiResponse with the list of PurchaseOrderItemsResponseDto
	 */
	ApiResponse<List<PurchaseOrderItemResponseDto>> getPurchaseOrderItemsByOrderId(String orderId);

	/**
	 * 
	 * This receivedPurchaseOrderItems method is used to Received the Order based on given orderId.
	 * 
	 * @author manus
	 * @date 21-Dec-2023
	 * @param principal
	 * @param order
	 * @return This will return ApiResponse with the PurchaseOrderResponseDto
	 */
	ApiResponse<PurchaseOrderResponseDto> receivedPurchaseOrderItems(Principal principal, Order order);
	
}
