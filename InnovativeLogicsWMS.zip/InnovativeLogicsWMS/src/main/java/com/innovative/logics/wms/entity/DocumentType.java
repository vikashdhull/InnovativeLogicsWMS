package com.innovative.logics.wms.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.UuidGenerator;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "document_Type" , uniqueConstraints = {@UniqueConstraint(columnNames = "name")})
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentType implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "id")
	@Id
	@UuidGenerator
	private String id;
	
	@Column(name = "name" , length = 100)
	private String name;
	
	@Column(name = "created_date" , nullable = false , updatable = false)
	@CreationTimestamp
	private LocalDateTime createdDate;
	
	@Column(name = "updated_date")
	@UpdateTimestamp
	private LocalDateTime updatedDate;
}
