package com.innovative.logics.wms.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.innovative.logics.wms.repository.UserRepository;

/**
 * This class provides implementation of the Spring Security UserDetailsService
 * interface. It is responsible for retrieving the user details based on the
 * username provided during authentication process.
 * 
 * @author manus
 * @date 15-Apr-2023
 */
@Service
public class CustomUserDetailService implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		return userRepository.findByUsername(username)
				.orElseThrow(() -> new UsernameNotFoundException("User with given username not found !!"));
	}
}
