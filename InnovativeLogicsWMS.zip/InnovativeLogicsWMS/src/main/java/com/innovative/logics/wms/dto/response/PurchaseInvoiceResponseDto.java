package com.innovative.logics.wms.dto.response;

import java.time.LocalDateTime;
import java.util.List;

import com.innovative.logics.wms.dto.AddressDto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PurchaseInvoiceResponseDto {
	
	private String id;
	
	private String invoiceNumber;
	
	private String orderName;
	
	private List<PurchaseOrderItemResponseDto> products;
	
	private LocalDateTime issueDate;
	
	private Double totalAmount;
	
	private boolean receivedStatus;
	
	private String origin;

	private AddressDto sender;

	private String destination;

	private AddressDto client;
	
	private String orderedBy;
	
	private String createdBy;

}
