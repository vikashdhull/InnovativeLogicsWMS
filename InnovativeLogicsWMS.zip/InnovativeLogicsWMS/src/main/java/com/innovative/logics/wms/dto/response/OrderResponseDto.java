package com.innovative.logics.wms.dto.response;

import java.time.LocalDate;
import java.util.Optional;

import com.innovative.logics.wms.dto.AddressDto;
import com.innovative.logics.wms.entity.Address;
import com.innovative.logics.wms.entity.Location;
import com.innovative.logics.wms.entity.Order;
import com.innovative.logics.wms.entity.Party;
import com.innovative.logics.wms.entity.User;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderResponseDto {

	private String id;

	private String orderType;

	private String name;

	private String description;

	private String orderNumber;

	private String status;

	private boolean receivedStatus;

	private String origin;

	private AddressDto sender;

	private String originParty;

	private String destination;

	private AddressDto client;

	private String destinationParty;

	private String approvedBy;

	private String orderedBy;

	private String completedBy;

	private LocalDate dateApproved;

	private LocalDate dateOrdered;

	private LocalDate dateCompleted;

	private String paymentMethodType;

	private String paymentTerm;

	private String product;

	private Long quantity;

	private String lot;

	private Double unitPrice;

	private String productSource;

	public OrderResponseDto(Order order) {

		this.id = order.getId();
		this.orderType = order.getOrderType();
		this.name = order.getName();
		this.description = order.getDescription();
		this.orderNumber = order.getOrderNumber();
		this.status = order.getStatus();

		Location originLocation = Optional.ofNullable(order.getOrigin()).orElse(null);

		this.origin = originLocation != null ? originLocation.getName() : null;
		if (originLocation != null) {
			Address originAddress = originLocation.getAddress();
			AddressDto originAddressDto = new AddressDto(originAddress);
			this.sender = originAddressDto;
		} else {
			this.sender = null;
		}

		Party originPartyData = Optional.ofNullable(order.getOriginParty()).orElse(null);

		this.originParty = originPartyData != null ? originPartyData.getName() : null;

		Location destinationLocation = Optional.ofNullable(order.getDestination()).orElse(null);

		this.destination = destinationLocation != null ? destinationLocation.getName() : null;

		if (destinationLocation != null) {
			Address destinationAddress = destinationLocation.getAddress();
			AddressDto destinationAddressDto = new AddressDto(destinationAddress);
			this.client = destinationAddressDto;
		} else {
			this.client = null;
		}
		Party destinationPartyData = Optional.ofNullable(order.getOriginParty()).orElse(null);

		this.destinationParty = destinationPartyData != null ? destinationPartyData.getName() : null;

		User approvedByData = Optional.ofNullable(order.getApprovedBy()).orElse(null);

		this.approvedBy = approvedByData != null ? approvedByData.getUsername() : null;

		User orderedByData = Optional.ofNullable(order.getOrderedBy()).orElse(null);

		this.orderedBy = orderedByData != null ? orderedByData.getUsername() : null;

		User completedByData = Optional.ofNullable(order.getCompletedBy()).orElse(null);

		this.completedBy = completedByData != null ? completedByData.getUsername() : null;

		this.dateApproved = order.getDateApproved();
		this.dateOrdered = order.getDateOrdered();
		this.dateCompleted = order.getDateCompleted();
		this.paymentMethodType = order.getPaymentMethodType();
		this.paymentTerm = order.getPaymentTerm();
	}

}
