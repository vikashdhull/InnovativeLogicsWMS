package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.Attribute;

public interface AttributeRepository extends JpaRepository<Attribute, String> {

	Optional<Attribute> findByName(String name);
	
	List<Attribute> findByNameIn(List<String> attributeNames);
	
	@Query(value = "SELECT a FROM Attribute a WHERE a.party.name =:name")
	Page<Attribute> findAttributesByParty(String name, Pageable pageable);
	
	List<Attribute> findByPartyName(String name);
}
