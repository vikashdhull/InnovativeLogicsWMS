package com.innovative.logics.wms.service;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.SynonymDto;

public interface SynonymService {
	
	ApiResponse<SynonymDto> createSynonym(SynonymDto synonymDto);

	ApiResponse<SynonymDto> getSynonymById(String synonymId);
	
	PageableResponse<SynonymDto> getSynonymByProductname(String productName, int pageNumber, int pageSize, String sortBy, String sortDir);

}
