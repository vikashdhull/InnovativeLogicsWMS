package com.innovative.logics.wms.service;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.StockRecordDto;
import com.innovative.logics.wms.dto.response.StockRecordResponseDto;

public interface InventoryItemService {
	
	PageableResponse<StockRecordResponseDto> getAllInventoryItemByLocation(String locationName, int pageNumber, int pageSize, String sortBy,
			String sortDir);
	
	ApiResponse<StockRecordResponseDto> updateInventoryItem(StockRecordDto inventoryItemDto, String id);
	
	ApiResponse<StockRecordResponseDto> deleteInventoryItemById(String inventoryItemId);

}
