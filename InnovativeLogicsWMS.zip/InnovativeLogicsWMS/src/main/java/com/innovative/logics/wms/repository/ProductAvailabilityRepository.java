package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.innovative.logics.wms.dto.InventorySummary;
import com.innovative.logics.wms.dto.ProductQuantity;
import com.innovative.logics.wms.dto.StockRecord;
import com.innovative.logics.wms.dto.response.InStockReportResponseDto;
import com.innovative.logics.wms.entity.Location;
import com.innovative.logics.wms.entity.Product;
import com.innovative.logics.wms.entity.ProductAvailability;

public interface ProductAvailabilityRepository extends JpaRepository<ProductAvailability, String> {

	final String PRODUCT_AVAILABILITY_BY_LOCATION = "SELECT p.* FROM product p JOIN product_catalog pc ON p.product_catalog_id = pc.id WHERE pc.name = :productCatalog";
	
	final String EXIST_PRODUCT_IN_PRODUCT_AVAILABILITY = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product_availability pa WHERE pa.product_id = :productId";
	
	final String EXIST_LOCATION_IN_PRODUCT_AVAILABILITY = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product_availability pa WHERE pa.supplier_id = :suplierId";

	final String PRODUCT_AVAILABILITY_BY_LOCATION_AND_LOT = "SELECT pa FROM product_availability pa INNER JOIN PA.location l WHERE l.name = :locationName";

	final String PRODUCT_AVAILABILITY_BY_LOCATION_AND_PRODUCT =

			"SELECT pa.* FROM product_availability pa JOIN product p ON pa.product_id = p.id JOIN location l ON pa.supplier_id = l.id WHERE p.name = :location and l.name = :product";

	final String FIND_PRODUCT_STOCK_QUANTITY_BY_LOCATION = "SELECT " + "(CASE "
			+ "WHEN SUM(ii.quantity_on_hand) < inv.minimum_quantity THEN 'Low Stock'"
			+ "WHEN SUM(ii.quantity_on_hand) > inv.maximum_quantity THEN 'Overstock'"
			+ "WHEN SUM(ii.quantity_on_hand) = 0 THEN 'Out of Stock'" 
			+ " else 'In Stock' " + "END) AS status,"
			+ "p.id AS productId, " + "p.code as productCode," + "p.name AS productName," + "l.name AS location,"
			+ "p.abc_class as abcClass," + "inv.minimum_quantity AS minimumQuantity,"
			+ "inv.maximum_quantity AS maximumQuantity, " + "inv.reorder_quantity as reorderQuantity,"
			+ "SUM(ii.quantity_on_hand) AS currentQuantity," + "p.average_unit_price as averageUnitPrice,"
			+ "(p.average_unit_price*SUM(ii.quantity_on_hand)) AS totalValue " + "FROM product_availability pa"
			+ "INNER JOIN inventory_item ii ON pa.id = ii.product_availability_id "
			+ "INNER JOIN product p ON pa.product_id = p.id" + "INNER JOIN location l ON pa.supplier_id = l.id"
			+ "INNER JOIN inventory_level inv ON inv.product_id = p.id" + "WHERE l.name = :locationName " + " AND inv.default_location_id = l.`id`"
			+ "GROUP BY pa.product_id, p.name, pa.supplier_id, l.name";

	Optional<ProductAvailability> findByProductAndLocation(Product product, Location location);

	@Query(value = PRODUCT_AVAILABILITY_BY_LOCATION_AND_PRODUCT, nativeQuery = true)
	List<ProductAvailability> getProductAvailablityByProductAndLocation(String product, String location);

	@Query(value = "SELECT p.id AS productId, p.name AS productName, p.code as productCode, p.average_unit_price as averageUnitPrice, "
			+ "SUM(ii.quantity_on_hand) AS totalQuantity " + "FROM product_availability pa "
			+ "INNER JOIN inventory_item ii ON pa.id = ii.product_availability_id "
			+ "INNER JOIN product p ON pa.product_id = p.id " + "INNER JOIN location l ON pa.supplier_id = l.id "
			+ "WHERE l.name = :locationName "
			+ "GROUP BY pa.product_id, p.name, pa.supplier_id, l.name", nativeQuery = true)
	Page<InventorySummary> getProductSummaries(@Param("locationName") String locationName, Pageable page);

	@Query(value = "SELECT p.name AS productName, SUM(ii.quantity_on_hand) AS totalQuantity"
			+ "FROM product_availability pa " + "INNER JOIN inventory_item ii ON pa.id = ii.product_availability_id "
			+ "INNER JOIN product p ON pa.product_id = p.id " + "INNER JOIN location l ON pa.supplier_id = l.id "
			+ "WHERE l.name = :locationName "
			+ "GROUP BY pa.product_id, p.name, pa.supplier_id, l.name", nativeQuery = true)
	ProductQuantity getProductQuantities(@Param("locationName") String locationName);

	@Query(value = "SELECT pa FROM ProductAvailability pa INNER JOIN pa.location l WHERE l.name = :locationName")
	Page<ProductAvailability> findAllByLocation(String locationName, Pageable pageable);

	@Query(value = FIND_PRODUCT_STOCK_QUANTITY_BY_LOCATION, nativeQuery = true)
	List<StockRecord> getProductStockQuantityByLocation(String locationName);
	
	@Query(name = "getInStockReport", nativeQuery = true)
	List<InStockReportResponseDto> getInStockReport(@Param("locationName") String locationName);
	
	@Query(value = EXIST_LOCATION_IN_PRODUCT_AVAILABILITY, nativeQuery = true)
	boolean existSuplierInProductAvailablity(String suplierId);
	
	@Query(value = EXIST_PRODUCT_IN_PRODUCT_AVAILABILITY, nativeQuery = true)
	boolean existProductInProductAvailablity(String productId);

}
