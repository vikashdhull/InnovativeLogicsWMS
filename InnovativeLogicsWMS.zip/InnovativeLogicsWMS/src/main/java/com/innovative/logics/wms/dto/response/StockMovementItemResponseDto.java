package com.innovative.logics.wms.dto.response;

import java.time.LocalDate;

import com.innovative.logics.wms.entity.StockMovementItem;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StockMovementItemResponseDto {

	private String id;

	private String comments;

	private String product;

	private Long quantity;

	private String requestedBy;

	private LocalDate shipmentDate;

	private LocalDate expectedDeliveryDate;
	
	private LocalDate expectedShippingDate;
	
	private String shipmentNumber;
	
	private String receivedBy;
	
	private String status;
	
	private Long shippedQuantity;
	
	private Long receivedQuantity;
	
	private String additionalInformation;
	
	
	public StockMovementItemResponseDto(StockMovementItem item) {
		
		String productName = item.getProduct() != null ? item.getProduct().getName() : null;
		String requestedUser = item.getRequestedBy() != null ? item.getRequestedBy().getUsername(): null;
		String receivedUser = item.getReceivedBy() != null ? item.getReceivedBy().getUsername(): null;
		
		this.id = item.getId();
		this.comments = item.getComments();
		this.product = productName;
		this.quantity = item.getQuantity();
		this.requestedBy = requestedUser;
		this.shipmentDate = item.getShippedDate();
		this.expectedShippingDate = item.getExpectedShippingDate();
		this.expectedDeliveryDate = item.getExpectedDeliveryDate();
		this.shipmentNumber = item.getShipmentNumber();
		this.receivedBy = receivedUser;
		this.status = item.getStatus();
		this.shippedQuantity = item.getShippedQuantity();
		this.receivedQuantity = item.getReceivedQuantity();
		this.additionalInformation = item.getAdditionalInformation();
	}
	
}
