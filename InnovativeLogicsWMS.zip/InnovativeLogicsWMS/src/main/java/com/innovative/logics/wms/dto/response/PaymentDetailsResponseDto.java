package com.innovative.logics.wms.dto.response;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentDetailsResponseDto {

	private String id;

	private String firstName;

	private String lastName;

	private String email;

	private String phoneNumber;

	private String accountNumber;

	private String description;
	
	private String party;

	private String createdBy;

	private String updatedBy;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
