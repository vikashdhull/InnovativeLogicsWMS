package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.LocationGroupDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.service.LocationGroupService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * The LocationGroupController class defines the REST endpoints for managing
 * Location Groups,such as creating a new Location Group, retrieving a Location
 * Group and deleting a Location Group etc.This class also includes role-based
 * authorization using Spring Security annotations.
 * 
 * @author manus
 * @date 15-Apr-2023
 */

@RestController
@RequestMapping("/locationgroup")
@Slf4j
public class LocationGroupController {

	@Autowired
	private LocationGroupService locationGroupService;

	/**
	 * 
	 * The createLocationGroup method is used to create the locationGroup and save
	 * the data in location_group table based on given details
	 * 
	 * @author manus
	 * @date 02-May-2023
	 * @param locationGroupDto
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<LocationGroupDto>> createLocationGroup(
			@Valid @RequestBody final LocationGroupDto locationGroupDto) {
		log.info("Enter in createLocationGroup Method present in LocationGroupController class");
		ApiResponse<LocationGroupDto> response = locationGroupService.createLocationGroup(locationGroupDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getLocationGroupById method is used to fetch the single locationGroup
	 * details from the location_Group table based on id
	 * 
	 * @author manus
	 * @date 04-May-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<LocationGroupDto>> getLocationGroupById(@PathVariable("id") final String id) {
		log.info("Enter in getLocationGroupById Method present in LocationGroupController class");
		ApiResponse<LocationGroupDto> response = locationGroupService.getLocationGroupById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The deleteLocationGroupById method is used to delete the the locationGroup
	 * details from the location_group table based on id
	 * 
	 * @author manus
	 * @date 05-June-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<LocationGroupDto>> deleteLocationGroupById(@PathVariable final String id) {
		log.info("Enter in deleteLocationGroupById Method present in LocationGroupController class");
		ApiResponse<LocationGroupDto> response = locationGroupService.deleteLocationGroupById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAllLocationGroup method is used to fetch all the locationGroup from
	 * the location_group table
	 * 
	 * @author manus
	 * @date 12-May-2023
	 * @param name
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<PageableResponse<LocationGroupDto>> getAllLocationGroup(
			@RequestParam(value = "org", required = true) String name,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllLocationGroup Method present in LocationGroupController class");

		PageableResponse<LocationGroupDto> response = locationGroupService.getAllLocationGroup(name, pageNumber,
				pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	/**
	 * 
	 * The searchLocationGroup method is used to search the locations based on
	 * LocationGroupName
	 * 
	 * @author manus
	 * @date 27-May-2023
	 * @param keyword
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/search/{keyword}")
	public ResponseEntity<PageableResponse<LocationGroupDto>> searchLocationGroup(@PathVariable String keyword,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in searchLocationGroup Method present in LocationGroupController class");

		PageableResponse<LocationGroupDto> response = locationGroupService.searchLocationGroup(keyword, pageNumber,
				pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The updateLocationGroup method is used to update the LocationGroup details
	 * based on id
	 * 
	 * @author manus
	 * @date 31-May-2023
	 * @param locationGroupDto
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<LocationGroupDto>> updateLocationGroup(
			@Valid @RequestBody final LocationGroupDto locationGroupDto, @PathVariable("id") final String id) {
		log.info("Enter in updateLocationGroup Method present in LocationGroupController class");
		ApiResponse<LocationGroupDto> response = locationGroupService.updateLocationGroup(locationGroupDto, id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('MANAGER') or hasRole('ADMIN') or hasRole('BROWSER')")
	@GetMapping("/org")
	public ResponseEntity<ApiResponse<List<LocationGroupDto>>> getAllLocationGroupsByOrganization(
			@RequestParam("name") String name) {
		log.info("Enter in getAllLocationGroupsByOrganization Method present in LocationGroupController class");

		ApiResponse<List<LocationGroupDto>> response = locationGroupService.getAllLocationGroupsByOrganization(name);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
