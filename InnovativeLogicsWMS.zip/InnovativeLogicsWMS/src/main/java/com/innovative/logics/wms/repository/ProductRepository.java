package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.innovative.logics.wms.dto.response.NumberOfQuantity;
import com.innovative.logics.wms.entity.Product;

public interface ProductRepository extends JpaRepository<Product, String> {

	final String EXIST_PRODUCT_TYPE = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product p WHERE p.product_type_id = :productTypeId";

	final String EXIST_TAG = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product_tag p WHERE p.tag_id = :tagId";

	final String EXIST_PRODUCT_CATALOG_ID = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product p WHERE p.product_catalog_id = :productCatalogId";

	final String EXIST_CATEGORY = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product_category p WHERE p.category_id = :categoryId";

	final String PRODUCT_BY_PRODUCT_CATALOG = "SELECT p.* FROM product p JOIN product_catalog pc ON p.product_catalog_id = pc.id WHERE pc.name = :productCatalog";

	final String GET_ALL_ACTIVE_PRODUCT = "SELECT * FROM product WHERE active = true";

	final String EXIST_PRODUCT_INBOUND = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM inbound i WHERE i.product_id = :productId";

	final String EXIST_PRODUCT_OUTBOUND = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM outbound_delivery od WHERE od.product_id = :productId";

	final String EXIST_MENUFACTURER_IN_PRODUCT = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product p WHERE p.manufacturer_id = :manufacturerId";

	final String EXIST_VENDOR_IN_PRODUCT = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product p WHERE p.vendor_id = :vendorId";

	final String EXIST_PARTY_IN_PRODUCT = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product p WHERE p.manufacturer_id = :manufacturerId";

	final String GET_ALL_ACTIVE_PRODUCT_BY_ORG = "SELECT p.* FROM product p LEFT JOIN party org ON org.id = p.organization_id WHERE p.active = true and org.name =:name";
	
	Page<Product> findByNameContaining(String keywords, Pageable pageable);
	
	@Query(value = GET_ALL_ACTIVE_PRODUCT_BY_ORG, nativeQuery = true)
	List<Product> getAllActiveProductsByOrg(String name);

	Optional<Product> findByName(String name);
	
	List<Product> findByPartyName(String name);

	Optional<Product> findByCode(String code);

	@Query(value = PRODUCT_BY_PRODUCT_CATALOG, nativeQuery = true)
	Page<Product> findByProductCatalog(String productCatalog, Pageable pageable);

	@Query(value = EXIST_PRODUCT_TYPE, nativeQuery = true)
	boolean existProductTypeInProduct(String productTypeId);

	@Query(value = EXIST_TAG, nativeQuery = true)
	boolean existTagInProduct(String tagId);

	@Query(value = EXIST_PRODUCT_CATALOG_ID, nativeQuery = true)
	boolean existProductCatalogInProduct(String productCatalogId);

	@Query(value = EXIST_CATEGORY, nativeQuery = true)
	boolean existCategoryInProduct(String categoryId);

	@Query(value = "SELECT COUNT(*) AS numberOfCount FROM product pro LEFT JOIN party p ON pro.organization_id = p.id WHERE p.name =:org", nativeQuery = true)
	NumberOfQuantity getProductInHand(String org);

	@Query(value = GET_ALL_ACTIVE_PRODUCT, nativeQuery = true)
	List<Product> getAllActiveProducts();

	@Query(value = EXIST_PRODUCT_INBOUND, nativeQuery = true)
	boolean existProductInInbound(String productId);

	@Query(value = EXIST_PRODUCT_OUTBOUND, nativeQuery = true)
	boolean existProductInOutbound(String productId);

	@Query(value = EXIST_MENUFACTURER_IN_PRODUCT, nativeQuery = true)
	boolean existManufacturerInProduct(String manufacturerId);

	@Query(value = EXIST_VENDOR_IN_PRODUCT, nativeQuery = true)
	boolean existVendorInProduct(String vendorId);

	@Query(value = EXIST_PARTY_IN_PRODUCT, nativeQuery = true)
	boolean existPartyInProduct(String manufacturerId);
	
	@Query(value = "SELECT pro FROM Product pro WHERE pro.party.name =:name")
	Page<Product> findProductsByOrganization(@Param("name") String name, Pageable pageable);

}
