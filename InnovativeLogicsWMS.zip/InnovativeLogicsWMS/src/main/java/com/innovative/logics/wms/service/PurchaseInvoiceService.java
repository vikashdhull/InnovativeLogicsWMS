package com.innovative.logics.wms.service;

import java.security.Principal;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.PurchaseInvoiceResponseDto;
import com.innovative.logics.wms.entity.Order;

public interface PurchaseInvoiceService {
	
	/**
	 * 
	 * The createPurchaseInvoice method is used to create the invoice based on given details.
	 * 
	 * @author manus
	 * @date 17-Dec-2023
	 * @param order
	 * @param principal
	 * @return ResponseEntity containing an ApiResponse with the PurchaseInvoiceResponseDto
	 */
	ApiResponse<PurchaseInvoiceResponseDto> createPurchaseInvoice(Order order, Principal principal);
		
	
	/**
	 * 
	 * The getAllPurchaseInvoiceByDestination method is used to get the all invoices page wise based on given destination and page.
	 * 
	 * @author manus
	 * @date 20-Dec-2023
	 * @param destination
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return ResponseEntity containing an PageableResponse with the PurchaseInvoiceResponseDto
	 */
	PageableResponse<PurchaseInvoiceResponseDto> getAllPurchaseInvoiceByDestination(String destination, int pageNumber,
			int pageSize, String sortBy, String sortDir);

	/**
	 * 
	 * The getPurchaseInvoiceByPurchaseOrderId method is used to get the invoice based on given orderId.
	 * 
	 * @author manus
	 * @date 22-Dec-2023
	 * @param purchaseOrderId
	 * @return ResponseEntity containing an ApiResponse with the PurchaseInvoiceResponseDto
	 */
	ApiResponse<PurchaseInvoiceResponseDto> getPurchaseInvoiceByPurchaseOrder(String orderId); 
	
	/**
	 * 
	 * The getPurchaseInvoiceByInvoiceId method is used to get the invoice based on given invoiceId.
	 * 
	 * @author manus
	 * @date 17-Jan-2024
	 * @param invoiceId
	 * @return ResponseEntity containing an ApiResponse with the PurchaseInvoiceResponseDto
	 */
	ApiResponse<PurchaseInvoiceResponseDto> getPurchaseInvoiceByInvoiceId(String invoiceId); 

}
