package com.innovative.logics.wms.dto.response;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.lang.Nullable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PurchaseOrderItemResponseDto {

	private String product;

	private Long quantity;
	
	private String lot;

	private String requestedBy;

	private Double unitPrice;

	private String productSource;

	private LocalDate shipmentDate;

	private LocalDate deliveryDate;
	
	private Double totalCost;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;
	
	public PurchaseOrderItemResponseDto(){
		
	}

	public PurchaseOrderItemResponseDto(String product, Long quantity, String lot, String requestedBy, Double unitPrice,
			@Nullable String productSource, LocalDate shipmentDate, LocalDate deliveryDate, Double totalCost,
			LocalDateTime createdDate, LocalDateTime updatedDate) {
		super();
		this.product = product;
		this.quantity = quantity;
		this.lot = lot;
		this.requestedBy = requestedBy;
		this.unitPrice = unitPrice;
		this.productSource = productSource;
		this.shipmentDate = shipmentDate;
		this.deliveryDate = deliveryDate;
		this.totalCost = totalCost;
		this.createdDate = createdDate;
		this.updatedDate = updatedDate;
	}	
}
