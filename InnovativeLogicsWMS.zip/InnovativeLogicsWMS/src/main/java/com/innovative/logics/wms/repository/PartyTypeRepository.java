package com.innovative.logics.wms.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.innovative.logics.wms.entity.PartyType;

public interface PartyTypeRepository extends JpaRepository<PartyType, String> {
	
	Optional<PartyType> findByName(String name);
	
	Optional<PartyType> findByCode(String code);
	
	Page<PartyType> findByNameContaining(String keywords, Pageable pageable);

}
