package com.innovative.logics.wms.service.impl;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PersonDto;
import com.innovative.logics.wms.entity.Person;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.repository.PersonRepository;
import com.innovative.logics.wms.service.PersonService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PersonServiceImpl implements PersonService {

	@Autowired
	private PersonRepository personRepository;

	@Autowired
	private Environment env;

	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private Utility utility;
	
	private String personFetchErrorMessage = "person.fetch.error.message";
	
	@Override
	public ApiResponse<PersonDto> createPerson(PersonDto personDto) {

		Person existByPhone = personRepository.findByPhoneNumber(personDto.getPhoneNumber());
		Person existByEmail = personRepository.findByEmail(personDto.getEmail());

		ApiResponse<PersonDto> response = new ApiResponse<>();

		try {
			if (existByEmail != null) {
				throw new BadApiRequestException(env.getProperty("user.email.create.error.message"));
			} else if (existByPhone != null) {
				throw new BadApiRequestException(env.getProperty("user.phone.create.error.message"));
			} else {

				Person person = modelMapper.map(personDto, Person.class);
				Person savedPerson = personRepository.save(person);
				PersonDto newDto = modelMapper.map(savedPerson, PersonDto.class);

				response.setData(newDto);
				response.setResult(true);
				response.setMessage(env.getProperty("person.create.success.message"));
				response.setStatus(HttpStatus.CREATED.value());
				return response;
			}
		} catch (Exception exp) {
			log.error("Exception in createPerson Method present in PersonServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<PersonDto> updatePerson(PersonDto personDto) {
		ApiResponse<PersonDto> response = new ApiResponse<>();

		Person personDetails = personRepository.findByEmail(personDto.getEmail());
		try {
			if (personDetails != null) {

				personDetails.setFirstName(personDto.getFirstName());
				personDetails.setLastName(personDto.getLastName());
				personDetails.setEmail(personDto.getEmail());
				personDetails.setPhoneNumber(personDto.getPhoneNumber());
				personDetails.setStreetAddress(personDto.getStreetAddress());
				personDetails.setCity(personDto.getCity());
				personDetails.setState(personDto.getState());
				personDetails.setCountry(personDto.getCountry());
				personDetails.setZipCode(personDetails.getZipCode());

				// save data
				Person updatedPerson = personRepository.save(personDetails);
				PersonDto updatedDto = modelMapper.map(updatedPerson, PersonDto.class);

				response.setData(updatedDto);
				response.setResult(true);
				response.setMessage(env.getProperty("person.update.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return createPerson(personDto);
			}
		} catch (Exception exp) {
			log.error("Exception in updatePerson Method present in PersonServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<PersonDto> deletePerson(String email) {
		ApiResponse<PersonDto> response = new ApiResponse<>();
		try {

			Person personDetails = personRepository.findByEmail(email);

			if (personDetails != null) {
				personRepository.deleteById(personDetails.getId());
				response.setMessage(env.getProperty("person.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				response.setMessage(env.getProperty(personFetchErrorMessage));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deletePerson Method present in PersonServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public ApiResponse<PersonDto> getPersonById(String id) {
		ApiResponse<PersonDto> response = new ApiResponse<>();
		try {
			Optional<Person> persionDetails = personRepository.findById(id);

			if (persionDetails.isPresent()) {
				Person person = persionDetails.get();
				response.setMessage(env.getProperty("person.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(modelMapper.map(person, PersonDto.class));
				return response;

			} else {
				response.setMessage(env.getProperty(personFetchErrorMessage));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getPersonById Method present in PersonServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public PageableResponse<PersonDto> getAllPerson(int pageNumber, int pageSize, String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<Person> page = personRepository.findAll(pageable);

		PageableResponse<PersonDto> response = utility.getPageableResponse(page, PersonDto.class);
		try {
			if (!response.getData().isEmpty()) {

				return response;

			} else {
				response.setMessage(env.getProperty(personFetchErrorMessage));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getAllPerson Method present in PersonServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

}
