package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.InventoryLevel;

public interface InventoryLevelRepository extends JpaRepository<InventoryLevel, String> {

	final String EXIST_INVENTORY_LEVEL_BY_PRODUCT_AND_LOCATION = "SELECT CASE WHEN EXISTS (SELECT 1 FROM inventory_level il JOIN product p ON il.product_id = p.id "
			+ "JOIN location l ON il.default_location_id = l.id WHERE p.name = :productName AND l.name = :locationName) THEN 'true' ELSE 'false' END AS result";

	final String FIND_INVENTORY_LEVEL_BY_PRODUCT_AND_LOCATION = "SELECT il.* FROM inventory_level il JOIN product p ON il.product_id = p.id "
			+ "JOIN location l ON il.default_location_id = l.id WHERE p.name = :productName AND l.name = :locationName";

	final String FIND_PRODUCT_OVERSTOCK_QUANTITY_BY_LOCATION = "SELECT Count(*) AS count " + "FROM (SELECT p.NAME, "
			+ " Sum(ii.quantity_on_hand), " + "Max(il.maximum_quantity)" + "FROM   product p "
			+ "INNER JOIN product_availability pa" + "ON pa.product_id = p.id " + "INNER JOIN inventory_item ii "
			+ "ON pa.id = ii.product_availability_id " + " INNER JOIN location l " + "ON pa.supplier_id = l.id "
			+ "INNER JOIN inventory_level il " + "ON p.id = il.product_id " + " WHERE l.NAME = :locationName "
			+ "GROUP BY p.id " + "HAVING Sum(ii.quantity_on_hand) > Max(il.maximum_quantity)) AS SUBQUERY";

	final String EXIST_LOCATION_IN_INVENTORY_LEVEL = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM inventory_level il WHERE il.default_location_id = :locationId";

	final String EXIST_REPLENISHMENT_SOURCE_IN_INVENTORY_LEVEL = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM inventory_level il WHERE il.default_replenishment_source_id = :replenishmentSourceId";

	final String EXIST_PUTAWAY_LOCATION_IN_INVENTORY_LEVEL = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM inventory_level il WHERE il.default_put_away_location_id = :putawayLocationId";

	final String EXIST_PRODUCT_IN_INVENTORY_LEVEL = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM inventory_level il WHERE il.product_id = :productId";

	@Query(value = EXIST_INVENTORY_LEVEL_BY_PRODUCT_AND_LOCATION, nativeQuery = true)
	Boolean existInventoryLevelByProductAndLocation(String productName, String locationName);

	List<InventoryLevel> findByProductId(String productId);
	
	//method to take response by product name
	List<InventoryLevel> findByLocationName(String name);

	Optional<InventoryLevel> findByStatus(String status);

	@Query(value = FIND_INVENTORY_LEVEL_BY_PRODUCT_AND_LOCATION, nativeQuery = true)
	InventoryLevel getInventoryLevelByProductAndLocation(String productName, String locationName);

	@Query(value = FIND_PRODUCT_OVERSTOCK_QUANTITY_BY_LOCATION, nativeQuery = true)
	Integer getProductOverstockQuantityByLocation(String locationName);

	@Query(value = EXIST_LOCATION_IN_INVENTORY_LEVEL, nativeQuery = true)
	boolean existsByLocationId(String locationId);

	@Query(value = EXIST_REPLENISHMENT_SOURCE_IN_INVENTORY_LEVEL, nativeQuery = true)
	boolean existsByReplenishmentSourceId(String replenishmentSourceId);

	@Query(value = EXIST_PUTAWAY_LOCATION_IN_INVENTORY_LEVEL, nativeQuery = true)
	boolean existsByPutawayLocationId(String putawayLocationId);

	@Query(value = EXIST_PRODUCT_IN_INVENTORY_LEVEL, nativeQuery = true)
	boolean existProductInInventoryLevel(String productId);
	
	@Query(value = "SELECT il FROM InventoryLevel il WHERE il.party.name =:name")
	Page<InventoryLevel> findInventoryLevelsByParty(String name, Pageable pageable);
}
