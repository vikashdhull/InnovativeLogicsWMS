package com.innovative.logics.wms.dto;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.innovative.logics.wms.entity.Document;
import com.innovative.logics.wms.entity.Location;
import com.innovative.logics.wms.entity.Party;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProductDto {

    private String id;
    @NotNull(message = "Name should not be null")
    private String name;
    private boolean status;
    @NotNull(message = "Code should not be null")
    private String code;
    private String description;
    private ProductTypeDto productType;
    private ProductCatalogDto productCatalog;
    private Set<CategoryDto> category;
    private Map<String, List<AttributeOptionDto>> attributeOptionsMap;
    private Set<TagDto> tag;
    private Double averageUnitPrice;
    private String abcClass;
    private boolean coldChain;
    private boolean controlledSubstance;
    private boolean reconditioned;
    private boolean hazardousMaterial;
    private boolean lotAndExpiryControl;
    private String brandName;
    private Party manufacturer;
    private String modelNumber;
    private Location vendor;
    private String ndc;
    private String upc;
    private Set<Document> documents;
    private String party;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
    
    private Integer totalQuantity;
}