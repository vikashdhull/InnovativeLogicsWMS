package com.innovative.logics.wms.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.innovative.logics.wms.entity.PasswordResetOtp;

public interface PasswordResetOtpRepository extends JpaRepository<PasswordResetOtp, String> {
	
	final String USER_DETAILS = "SELECT p.* FROM password_reset_otp p WHERE p.user_id = :id ";

	
	PasswordResetOtp findByOtp(String otp);
	
	@Query(value = USER_DETAILS, nativeQuery = true)
	Optional<PasswordResetOtp> findByUserId(@Param("id") String id);

}
