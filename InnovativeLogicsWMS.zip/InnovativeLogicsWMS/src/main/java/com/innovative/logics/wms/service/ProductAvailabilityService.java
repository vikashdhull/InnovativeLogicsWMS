package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.InventorySummary;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductAvailabilityDto;
import com.innovative.logics.wms.dto.response.InStockReportResponseDto;
import com.innovative.logics.wms.dto.response.ProductAvailabilityResponseDto;

public interface ProductAvailabilityService {
	
	ApiResponse<ProductAvailabilityResponseDto> createProductAvailability(ProductAvailabilityDto productAvailabilityDto);

	ApiResponse<List<ProductAvailabilityResponseDto>> getproductAvailabilityByLocationAndProduct(String locationName, String productName);
	
	PageableResponse<InventorySummary> getProductSummariesByLocation(String locationName, int pageNumber, int pageSize, String sortBy,
			String sortDir);
	
	PageableResponse<ProductAvailabilityResponseDto> getAllProductAvailablityByLocationAndLot(String locationName, int pageNumber, int pageSize, String sortBy,
			String sortDir);
	
	ApiResponse<List<InStockReportResponseDto>> getInStockReport(String locationName);
}
