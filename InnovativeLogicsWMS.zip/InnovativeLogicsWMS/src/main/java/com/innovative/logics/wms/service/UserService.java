package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.MakeUserDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PersonDto;
import com.innovative.logics.wms.dto.UserDto;
import com.innovative.logics.wms.dto.response.UserResponseDto;

public interface UserService {

	/**
	 * 
	 * This method is used to create the new user based on given details
	 * 
	 * @author manus
	 * @date 22-Feb-2023
	 * @param userDto
	 * @return an ApiResponse containing the UserDto representing the newly created
	 *         user and a success message,
	 */
	ApiResponse<UserResponseDto> createUser(UserDto userDto);

	/**
	 * 
	 * This method is used to update the existing user based on given details
	 * 
	 * @author manus
	 * @date 28-Feb-2023
	 * @param userDto
	 * @return
	 */
	ApiResponse<UserDto> updateUser(UserDto userDto);

	/**
	 * 
	 * This method is used to delete the user based on given id
	 * 
	 * @author manus
	 * @date 17-Mar-2023
	 * @param id
	 * @param username
	 * @return
	 */
	ApiResponse<UserDto> deleteUser(String id, String username);

	/**
	 * 
	 * This method is used to get the single user based on given username
	 * 
	 * @author manus
	 * @date 24-Feb-2023
	 * @param username
	 * @return
	 */
	ApiResponse<UserDto> getUserByUsername(String username);

	/**
	 * 
	 * This method is used to get all users
	 * 
	 * @author manus
	 * @date 23-Mar-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<UserResponseDto> getAllUser(String org, int pageNumber, int pageSize, String sortBy, String sortDir);

	/**
	 * 
	 * This method is used to search the user based on given details
	 * 
	 * @author manus
	 * @date 23-Mar-2023
	 * @param keyword
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<UserResponseDto> searchUser(String keyword, int pageNumber, int pageSize, String sortBy,
			String sortDir);

	/**
	 * 
	 * This method is used to convert the person to user
	 * 
	 * @author manus
	 * @date 14-Apr-2023
	 * @param userDto
	 * @return
	 */
	ApiResponse<UserDto> covertUserToPerson(UserDto userDto);

	/**
	 * 
	 * This method is used to update the logged in user information
	 * 
	 * @author manus
	 * @date 29-May-2023
	 * @param personDto
	 * @param username
	 * @return
	 */
	ApiResponse<PersonDto> updateCurrentUserProfile(PersonDto personDto, String username);

	/**
	 * 
	 * This method is used to enable the register user
	 * 
	 * @author manus
	 * @date 10-Jun-2023
	 * @param makeUserDto
	 * @return
	 */
	ApiResponse<MakeUserDto> makeUser(MakeUserDto makeUserDto);

	ApiResponse<List<UserResponseDto>> getAllUsersByOrganization(String orgnization);

	ApiResponse<List<UserResponseDto>> getAllActiveUsersByOrganization(String orgnization);
}
