package com.innovative.logics.wms.dto.response;

import java.time.LocalDateTime;

import com.innovative.logics.wms.dto.AddressDto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InvoiceResponseDto {
	
	private String id;
	
	private String invoiceNumber;
	
	private String orderName;
	
	private String product;

	private Long quantity;

	private Double unitPrice;
	
	private LocalDateTime issueDate;
	
	private Double totalAmount;
	
	private boolean receivedStatus;
	
	private String origin;

	private AddressDto sender;

	private String destination;

	private AddressDto client;
	
	private String orderedBy;
	
	private String createdBy;

}
