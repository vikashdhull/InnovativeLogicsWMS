package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.ProductPackageDto;
import com.innovative.logics.wms.dto.response.ProductPackageResponseDto;
import com.innovative.logics.wms.service.ProductPackageService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/product-package")
@Slf4j
public class ProductPackageController {

	@Autowired
	private ProductPackageService productPackageService;

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<ProductPackageResponseDto>> createProductPackage(
			@Valid @RequestBody final ProductPackageDto productPackageDto) {
		log.info("Enter in createProductPackage Method present in ProductPackageController class");
		ApiResponse<ProductPackageResponseDto> response = productPackageService.createProductPackage(productPackageDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<ProductPackageResponseDto>> getProductPackageById(
			@PathVariable("id") final String id) {
		log.info("Enter in getProductPackageById Method present in ProductPackageController class");
		ApiResponse<ProductPackageResponseDto> response = productPackageService.getProductPackageById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/product/{productName}")
	public ResponseEntity<ApiResponse<List<ProductPackageResponseDto>>> getProductPackagesByProductname(
			@PathVariable("productName") final String productName) {
		log.info("Enter in getProductPackagesByProductname Method present in ProductPackageController class");
		ApiResponse<List<ProductPackageResponseDto>> response = productPackageService
				.getProductPackagesByProductname(productName);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<ProductPackageResponseDto>> deleteProductPackageById(
			@PathVariable final String id) {
		log.info("Enter in deleteProductById Method present in ProductPackageController class");
		ApiResponse<ProductPackageResponseDto> response = productPackageService.deleteProductPackageById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
