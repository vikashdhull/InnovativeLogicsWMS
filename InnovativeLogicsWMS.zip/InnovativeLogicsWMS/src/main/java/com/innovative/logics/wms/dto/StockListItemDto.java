package com.innovative.logics.wms.dto;

import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class StockListItemDto {

	private String id;

	private ProductDto product;

	private StockListDto stockList;
	
	@Min(value = 0, message = " quantity must be equal or greater then 0")
	private Double quantity;

	private Double totalCost;

}
