package com.innovative.logics.wms.controller;

import java.security.Principal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.StockMovementDto;
import com.innovative.logics.wms.dto.StockMovementShippingDto;
import com.innovative.logics.wms.dto.StockMovementUpdateDto;
import com.innovative.logics.wms.dto.response.NumberOfQuantity;
import com.innovative.logics.wms.dto.response.StockMovementResponseDto;
import com.innovative.logics.wms.dto.response.TopDemandingProductResponseDto;
import com.innovative.logics.wms.service.StockMovementService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * The StockMovementController class defines the REST endpoints for creating,
 * updating and retrieving stock movement details.Endpoints are secured with
 * Spring Security's @PreAuthorize annotation to ensure that only authorized
 * users can perform CRUD operations on stock movement.
 * 
 * @author manus
 * @date 11-Jan-2024
 */
@RestController
@RequestMapping("/movement")
@Slf4j
public class StockMovementController {

	@Autowired
	private StockMovementService stockMovementService;

	/**
	 * 
	 * This createStockMovement method is used to create the stock movement with
	 * multiple products.
	 * 
	 * @author manus
	 * @date 05-Jan-2024
	 * @param stockMovementDto
	 * @return ResponseEntity will return ApiResponse with the
	 *         StockMovementResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<StockMovementResponseDto>> createStockMovement(
			@Valid @RequestBody final StockMovementDto stockMovementDto) {
		log.info("Enter in createStockMovement Method present in StockMovementController class");
		ApiResponse<StockMovementResponseDto> response = stockMovementService.createStockMovement(stockMovementDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * This updateStockMovement method is used to update by the shipper with product
	 * availability status and all products status will be given at a single time.
	 * 
	 * @author manus
	 * @date 08-Jan-2024
	 * @param stockMovementUpdateDto
	 * @param movementId
	 * @param principal
	 * @return ResponseEntity will return ApiResponse with the
	 *         StockMovementResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/update/{id}")
	public ResponseEntity<ApiResponse<StockMovementResponseDto>> updateStockMovement(
			@Valid @RequestBody final Map<String, StockMovementUpdateDto> stockMovementUpdateDto,
			@PathVariable("id") final String movementId, Principal principal) {
		log.info("Enter in updateStockMovement Method present in StockMovementController class");

		ApiResponse<StockMovementResponseDto> response = stockMovementService
				.updateStockMovement(stockMovementUpdateDto, movementId, principal);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	/**
	 * 
	 * This shipStockMovement method is used to ship product to the destination
	 * user, user can also partially ship the order.
	 * 
	 * @author manus
	 * @date 11-Jan-2024
	 * @param stockMovementShippingDto
	 * @param principal
	 * @return ResponseEntity will return ApiResponse with the
	 *         StockMovementResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping("/ship")
	public ResponseEntity<ApiResponse<StockMovementResponseDto>> shipStockMovement(
			@Valid @RequestBody final StockMovementShippingDto stockMovementShippingDto, Principal principal) {
		log.info("Enter in shipStockMovement Method present in StockMovementController class");

		ApiResponse<StockMovementResponseDto> response = stockMovementService
				.shipStockMovement(stockMovementShippingDto, principal);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	/**
	 * 
	 * This method is used to get product and its sum, purchased and transferred
	 * from other locations by given time of the particular organization + location.
	 * 
	 * @author manus
	 * @date 22-Jan-2024
	 * @param topDemandingDto
	 * @param principal
	 * @return ResponseEntity will return ApiResponse with the
	 *         TopDemandingProductResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@GetMapping("/demand")
	public ResponseEntity<ApiResponse<List<TopDemandingProductResponseDto>>> getTopDemandingProducts(
			@RequestParam(value = "locationName", required = true) String locationName,
			@RequestParam(value = "organizationName", required = true) String organizationName,
			@RequestParam(value = "dateFrom", required = false) LocalDate dateFrom,
			@RequestParam(value = "dateTo", required = false) LocalDate dateTo,
			@RequestParam(value = "recordsCount", required = false) Long recordsCount) {
		log.info("Enter in getTopDemandingProducts Method present in StockMovementController class");

		ApiResponse<List<TopDemandingProductResponseDto>> response = stockMovementService
				.getTopDemandingProducts(locationName, organizationName, dateFrom, dateTo, recordsCount);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@GetMapping("/pending-counts")
	public ResponseEntity<ApiResponse<NumberOfQuantity>> getPendingMovementCounts(@RequestParam("origin") String origin) {
		log.info("Enter in getPendingMovementCounts Method present in StockMovementController class");
		ApiResponse<NumberOfQuantity> response = stockMovementService.getPendingMovementCounts(origin);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
