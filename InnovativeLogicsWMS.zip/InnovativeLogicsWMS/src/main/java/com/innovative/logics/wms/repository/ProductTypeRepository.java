package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.ProductType;

public interface ProductTypeRepository extends JpaRepository<ProductType, String> {

	Optional<ProductType> findByName(String name);

	Optional<ProductType> findByCode(String code);
	
	@Query(value = "SELECT pt FROM ProductType pt WHERE pt.party.name =:name")
	Page<ProductType> findProductTypesByParty(String name, Pageable pageable);
	
	List<ProductType> findByPartyName(String name);

}
