package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.ProductPackage;

public interface ProductPackageRepository extends JpaRepository<ProductPackage, String>{
	
	final String PRODUCT_PACKAGE_BY_PRODUCT_NAME = "SELECT pp.* FROM product_package pp JOIN product p ON pp.product_id = p.id WHERE p.name = :productName";
	
	final String EXIST_PRODUCT_IN_PRODUCT_PACKAGE = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product_package pp WHERE pp.product_id = :productId";
	
	final String EXIST_PRODUCT_SOURCE_IN_PRODUCT_PACKAGE = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product_package pp WHERE pp.product_source_id = :productSourceId";
	
	Optional<ProductPackage> findByDescriptiveName(String descriptiveName);
	
	@Query(value = PRODUCT_PACKAGE_BY_PRODUCT_NAME, nativeQuery = true)
	List<ProductPackage> findProductPackageByProductName(String productName);
	
	@Query(value = EXIST_PRODUCT_IN_PRODUCT_PACKAGE, nativeQuery = true)
	boolean existProductInProductPackage(String productId);
	
	@Query(value = EXIST_PRODUCT_SOURCE_IN_PRODUCT_PACKAGE, nativeQuery = true)
	boolean existProductSourceInProductPackage(String productSourceId);
}