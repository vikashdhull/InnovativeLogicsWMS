package com.innovative.logics.wms.service.impl;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.innovative.logics.wms.dto.AddressDto;
import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.PurchaseInvoiceResponseDto;
import com.innovative.logics.wms.dto.response.PurchaseOrderItemResponseDto;
import com.innovative.logics.wms.entity.Address;
import com.innovative.logics.wms.entity.Invoice;
import com.innovative.logics.wms.entity.Location;
import com.innovative.logics.wms.entity.Order;
import com.innovative.logics.wms.entity.OrderItem;
import com.innovative.logics.wms.entity.ProductSource;
import com.innovative.logics.wms.entity.User;
import com.innovative.logics.wms.exception.ResourceNotFoundException;
import com.innovative.logics.wms.repository.InvoiceRepository;
import com.innovative.logics.wms.repository.OrderItemRepository;
import com.innovative.logics.wms.repository.OrderRepository;
import com.innovative.logics.wms.repository.UserRepository;
import com.innovative.logics.wms.service.PurchaseInvoiceService;
import com.innovative.logics.wms.util.Constants;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PurchaseInvoiceServiceImpl implements PurchaseInvoiceService {

	@Autowired
	private InvoiceRepository invoiceRepository;

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private OrderItemRepository orderItemRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;
	
	private String invoiceSuccessMessage = "invoice.fetch.success.message";

	@Override
	public ApiResponse<PurchaseInvoiceResponseDto> createPurchaseInvoice(Order order, Principal principal) {

		ApiResponse<PurchaseInvoiceResponseDto> response = new ApiResponse<>();

		try {
				if (Constants.RECEIVED.equals(order.getStatus())) {

					Optional<Invoice> findInvoiceByOrder = invoiceRepository.findByOrder(order.getId());

					if (findInvoiceByOrder.isPresent()) {
						return utility.errorResponse(response, HttpStatus.CONFLICT, "invoice.error.message");
					}

					Invoice invoice = findInvoiceByOrder.orElseGet(Invoice::new);

					String generateUniqueCode = utility.generateUniqueCode(order.getName());

					invoice.setInvoiceNumber("INV-" + generateUniqueCode.toUpperCase());
					invoice.setOrder(order);
					
					List<OrderItem> orderItem = orderItemRepository.findPurchaseOrderByOrderId(order.getId());
					
					if(!orderItem.isEmpty()) {	
						
					List<PurchaseOrderItemResponseDto> items = orderItem.stream().map(this::entityToDto).toList();
					
					Double totalAmount = items.stream().mapToDouble(i->i.getTotalCost()).sum();	
					
					invoice.setTotalAmount(totalAmount);
					
					Optional<User> findByUsername = userRepository.findByUsername(principal.getName());

					if (!findByUsername.isPresent()) {
						return utility.errorResponse(response, HttpStatus.NOT_FOUND,
								"userdetails.delete.error.message");
					}

					invoice.setCreatedBy(findByUsername.get());

					Invoice savedInvoice = invoiceRepository.save(invoice);

					PurchaseInvoiceResponseDto invoiceResponseDto = entityToDto(savedInvoice, items);

					response.setData(invoiceResponseDto);
					response.setResult(true);
					response.setMessage(env.getProperty("invoice.create.success.message"));
					response.setStatus(HttpStatus.OK.value());
					}
					return response;
					
				} else {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND,
							"invoice.create.receive.error.message");
				}
	
		} catch (Exception exp) {
			log.error("Exception Occurred in createPurchaseInvoice Method present in PurchaseInvoiceServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public PageableResponse<PurchaseInvoiceResponseDto> getAllPurchaseInvoiceByDestination(String destination, int pageNumber,
			int pageSize, String sortBy, String sortDir) {

		PageableResponse<PurchaseInvoiceResponseDto> response = new PageableResponse<>();
		
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
		
		List<PurchaseInvoiceResponseDto> list = new ArrayList<>();		

		try {

			Page<Invoice> invoiceList = invoiceRepository.findPurchaseInvoiceByDestination(destination, pageable);
			
			if (!invoiceList.isEmpty()) {
				
			invoiceList.stream().forEach(i-> {
				List<OrderItem> orderItem  = orderItemRepository.findPurchaseOrderByOrderId(i.getOrder().getId());
				
				List<PurchaseOrderItemResponseDto> items = orderItem.stream().map(this::entityToDto).toList();
				
				PurchaseInvoiceResponseDto result = entityToDto(i, items);
				list.add(result);				
			});
						
			long totalElements = invoiceList.getTotalElements();
			int totalPages = invoiceList.getTotalPages();

			response.setPageNumber(invoiceList.getNumber());
			response.setPageSize(invoiceList.getSize());
			response.setTotalElements(totalElements);
			response.setTotalPages(totalPages);
			response.setLastPage(invoiceList.isLast());
			response.setMessage(env.getProperty(invoiceSuccessMessage));
			response.setResult(true);
			response.setStatus(HttpStatus.OK.value());
			response.setData(list);
			return response;

			} else {

				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, "invoice.fetch.error.message");
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in getAllPurchaseInvoiceByDestination Method present in PurchaseInvoiceServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<PurchaseInvoiceResponseDto> getPurchaseInvoiceByPurchaseOrder(String orderId) {
		ApiResponse<PurchaseInvoiceResponseDto> response = new ApiResponse<>();

		try {
			Optional<Invoice> findInvoiceByOrder = invoiceRepository.findByOrder(orderId);
			if (findInvoiceByOrder.isPresent()) {
				
				List<OrderItem> orderItem = orderItemRepository.findPurchaseOrderByOrderId(findInvoiceByOrder.get().getOrder().getId());
				
				List<PurchaseOrderItemResponseDto> items = orderItem.stream().map(this::entityToDto).toList();

				PurchaseInvoiceResponseDto invoiceResponseDto = entityToDto(findInvoiceByOrder.get(), items);

				response.setData(invoiceResponseDto);
				response.setResult(true);
				response.setMessage(env.getProperty(invoiceSuccessMessage));
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "invoice.generate.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occurred in getInvoiceByPurchaseOrder Method present in InvoiceServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}
	
	@Override
	public ApiResponse<PurchaseInvoiceResponseDto> getPurchaseInvoiceByInvoiceId(String invoiceId) {
		ApiResponse<PurchaseInvoiceResponseDto> response = new ApiResponse<>();

		try {
			Optional<Invoice> findInvoiceByOrder = invoiceRepository.findById(invoiceId);
			if (findInvoiceByOrder.isPresent()) {
				
				List<OrderItem> orderItem = orderItemRepository.findPurchaseOrderByOrderId(findInvoiceByOrder.get().getOrder().getId());
				
				List<PurchaseOrderItemResponseDto> items = orderItem.stream().map(this::entityToDto).toList();

				PurchaseInvoiceResponseDto invoiceResponseDto = entityToDto(findInvoiceByOrder.get(), items);

				response.setData(invoiceResponseDto);
				response.setResult(true);
				response.setMessage(env.getProperty(invoiceSuccessMessage));
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "invoice.generate.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occurred in getPurchaseInvoiceByInvoiceId Method present in InvoiceServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	private PurchaseInvoiceResponseDto entityToDto(Invoice invoice, List<PurchaseOrderItemResponseDto> items) {

		PurchaseInvoiceResponseDto invoiceResponseDto = new PurchaseInvoiceResponseDto();

		Optional<Order> findOrderById = orderRepository.findById(invoice.getOrder().getId());

		if (!findOrderById.isPresent()) {

			throw new ResourceNotFoundException("Not Found");
		}
		Order order = findOrderById.get();

		invoiceResponseDto.setId(invoice.getId());
		invoiceResponseDto.setInvoiceNumber(invoice.getInvoiceNumber());		
		invoiceResponseDto.setOrderName(order.getName());

		Location origin = order.getOrigin();
		invoiceResponseDto.setOrigin(origin.getName());
		Address originAddress = origin.getAddress();
		AddressDto originAddressDto = new AddressDto(originAddress);
		invoiceResponseDto.setSender(originAddressDto);

		Location destination = order.getDestination();
		invoiceResponseDto.setDestination(destination.getName());
		Address destinationAddress = destination.getAddress();
		AddressDto destinationAddressDto = new AddressDto(destinationAddress);
		invoiceResponseDto.setClient(destinationAddressDto);
		invoiceResponseDto.setReceivedStatus(true);
		invoiceResponseDto.setOrderedBy(order.getOrderedBy().getUsername());
		invoiceResponseDto.setTotalAmount(invoice.getTotalAmount());
		invoiceResponseDto.setIssueDate(invoice.getIssueDate());
		invoiceResponseDto.setCreatedBy(invoice.getCreatedBy().getUsername());
		
		invoiceResponseDto.setProducts(items);

		return invoiceResponseDto;
	}
	
	private PurchaseOrderItemResponseDto entityToDto(OrderItem orderItem) {

		PurchaseOrderItemResponseDto orderItemResponseDto = new PurchaseOrderItemResponseDto();
		orderItemResponseDto.setRequestedBy(orderItem.getRequestedBy().getUsername());
		orderItemResponseDto.setProduct(orderItem.getProduct().getName());
		orderItemResponseDto.setQuantity(orderItem.getQuantity());
		String lot = orderItem.getLot();
		if (lot == null) {
			orderItemResponseDto.setLot(null);
		} else {
			orderItemResponseDto.setLot(orderItem.getLot());
		}

		orderItemResponseDto.setUnitPrice(orderItem.getUnitPrice());
		
		ProductSource productSource = orderItem.getProductSource();
		
		if (productSource == null) {
			orderItemResponseDto.setProductSource(null);
		} else {
			orderItemResponseDto.setProductSource(productSource.getName());
		}
		orderItemResponseDto.setShipmentDate(orderItem.getShipmentDate());
		orderItemResponseDto.setDeliveryDate(orderItem.getDeliveryDate());
		orderItemResponseDto.setCreatedDate(orderItem.getCreatedDate());
		orderItemResponseDto.setUpdatedDate(orderItem.getUpdatedDate());
		Long quantity = orderItem.getQuantity();
		Double totalCost = (quantity * orderItem.getUnitPrice());
		orderItemResponseDto.setTotalCost(totalCost);

		return orderItemResponseDto;
	}
	
}
