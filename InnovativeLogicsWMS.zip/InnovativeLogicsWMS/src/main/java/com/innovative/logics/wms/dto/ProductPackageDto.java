package com.innovative.logics.wms.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProductPackageDto {

	private String id;

	@NotNull(message = "Descriptive Name should not be null")
	private String descriptiveName;

	private String gtin;

	private Integer quantity;

	private String description;
	
	private Double price;

	private ProductSourceDto productSource;

	private ProductDto product;

}
