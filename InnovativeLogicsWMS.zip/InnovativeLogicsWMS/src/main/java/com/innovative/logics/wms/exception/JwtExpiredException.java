package com.innovative.logics.wms.exception;
 
 public class JwtExpiredException extends RuntimeException{

	/** long Short Description */
	private static final long serialVersionUID = 1L;
	
	
	public JwtExpiredException() {
		super("Jwt Expired !!");
	}

	public JwtExpiredException(String message) {
		super(message);
	}

}
