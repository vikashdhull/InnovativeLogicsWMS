package com.innovative.logics.wms.service.impl;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.innovative.logics.wms.dto.RoleDto;
import com.innovative.logics.wms.dto.response.JwtResponse;
import com.innovative.logics.wms.entity.Person;
import com.innovative.logics.wms.entity.User;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.repository.UserRepository;
import com.innovative.logics.wms.security.JwtHelper;
import com.innovative.logics.wms.service.LoginService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LoginServiceImpl implements LoginService {

	@Autowired
	private UserDetailsService userDetailsService;

	@Autowired
	private AuthenticationManager manager;

	@Autowired
	private Environment env;

	@Autowired
	private JwtHelper helper;

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private ModelMapper modelMapper;

	private String loginErrorMessage = "login.error.message";

	@Override
	public JwtResponse login(String username, String password) {
		log.info("Entering in login user method {} ", username);
		this.doAuthenticate(username, password);
		UserDetails userDetails = userDetailsService.loadUserByUsername(username);
		String name = userDetails.getUsername();
		Optional<User> findByUsername = userRepo.findByUsername(name);
		if (!findByUsername.isPresent()) {
			log.info("ERROR empty user {} ", username);
			throw new UsernameNotFoundException(env.getProperty(loginErrorMessage));
		} else {
			User user = findByUsername.get();
			if (Boolean.TRUE.equals(user.getStatus())) {
				String token = this.helper.generateJwtToken(userDetails);
				user.setLastLoginDate(Utility.dateFormattor());
				userRepo.save(user);
				return entityToDto(user, token);
			} else
				throw new BadApiRequestException(env.getProperty(loginErrorMessage));
		}
	}

	private void doAuthenticate(String username, String password) {

		UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(username,
				password);
		try {
			manager.authenticate(authentication);
		} catch (BadCredentialsException e) {
			throw new BadApiRequestException(env.getProperty(loginErrorMessage));
		}
	}

	private JwtResponse entityToDto(User user, String token) {

		JwtResponse jwtResponse = new JwtResponse();

		Person person = user.getPerson();
		jwtResponse.setJwtToken(token);
		jwtResponse.setFirstName(person.getFirstName());
		jwtResponse.setLastName(person.getLastName());
		jwtResponse.setUsername(user.getUsername());
		jwtResponse.setOrganization(user.getParty().getName());

		Set<RoleDto> collect = user.getRole().stream().map(role -> modelMapper.map(role, RoleDto.class))
				.collect(Collectors.toSet());

		Optional<RoleDto> roleDto = collect.stream().findFirst();
		if (roleDto.isPresent()) {
			String roleName = roleDto.get().getRoleName();
			jwtResponse.setRole(roleName.substring(5));
		} else {
			jwtResponse.setRole(null);
		}
		return jwtResponse;
	}

}
