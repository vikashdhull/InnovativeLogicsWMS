package com.innovative.logics.wms.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RoleDto {

	private String id;

	@NotBlank(message = "Role name should not be blank")
	private String roleName;
	private String description;
	
	//@JsonProperty(access = Access.WRITE_ONLY)
	@NotBlank(message = "Role code should not be blank")
	private String roleCode;

	public RoleDto(String roleName) {
		this.roleName = roleName;
	}

}