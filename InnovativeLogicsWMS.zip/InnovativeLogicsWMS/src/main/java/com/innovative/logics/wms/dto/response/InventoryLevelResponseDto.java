package com.innovative.logics.wms.dto.response;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InventoryLevelResponseDto {
	
	private String id;

	private String status;
	
	private String productCode;

	private String product;

	private String location;

	private String abcAnalysisClass;

	private String comments;

	private int minimumQuantity;

	private int maximumQuantity;

	private String defaultReplenishmentSource;

	private String replenishmentPeriodDays;

	private String defaultPutAwayLocation;

	private int forecastQuantity;

	private int forecastPeriod;
	
	private int reorderQuantity;
	
	private String expectedLeadTimeDays;
	
	private String party;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
