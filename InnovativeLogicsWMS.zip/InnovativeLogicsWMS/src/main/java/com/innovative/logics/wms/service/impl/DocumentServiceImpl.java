package com.innovative.logics.wms.service.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.naming.SizeLimitExceededException;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.DocumentDto;
import com.innovative.logics.wms.entity.Document;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.repository.DocumentRepository;
import com.innovative.logics.wms.service.DocumentService;
import com.innovative.logics.wms.util.Constants;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DocumentServiceImpl implements DocumentService {

	@Autowired
	private DocumentRepository documentRepository;

	@Value("${upload.file}")
	private String uploadFolder;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Environment env;

	@Override
	public ApiResponse<DocumentDto> uploadDocument(MultipartFile file, String documentDto) {

		Optional<Document> documents = documentRepository.findByFileName(file.getOriginalFilename());
		ApiResponse<DocumentDto> response = new ApiResponse<>();
		if (file.getSize() > Constants.MAX_SIZE) {
			response.setMessage(env.getProperty("document.upload.max.size.exceed.error.message"));
			response.setStatus(HttpStatus.INSUFFICIENT_STORAGE.value());
			response.setResult(true);
			return response;
		}
		if (documents.isPresent()) {
			response.setMessage(env.getProperty("document.upload.file.duplicate.error.message"));
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			response.setResult(false);
			return response;
		}
		ObjectMapper objectMapper = new ObjectMapper();
		DocumentDto docuType;
		try {
			docuType = objectMapper.readValue(documentDto, DocumentDto.class);
			Optional<Document> findByName = documentRepository.findByFileName(docuType.getFileName());
			if (findByName.isPresent()) {
				throw new BadApiRequestException(env.getProperty("document.name.create.error.message"));
			} else {
				Path folderPath = Paths.get(uploadFolder);
				if (!Files.exists(folderPath)) {
					createDirectories(folderPath);
				}

				byte[] bytes;
				bytes = file.getBytes();
				Path path = Paths.get(uploadFolder + UUID.randomUUID().toString() + "-" + file.getOriginalFilename());
				Files.write(path, bytes);
				Document document = this.modelMapper.map(documentDto, Document.class);
				int lastIndex = file.getOriginalFilename().lastIndexOf(".");
				if (lastIndex != -1) {
					document.setName(file.getOriginalFilename().substring(0, lastIndex));
				}
				document.setFileName(file.getOriginalFilename());
				Document doc = documentRepository.save(document);
				DocumentDto docDto = this.modelMapper.map(doc, DocumentDto.class);
				response.setData(docDto);
				response.setMessage(env.getProperty("document.upload.success.message"));
				response.setStatus(HttpStatus.OK.value());
				response.setResult(true);
				return response;
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in uploadDocument method in DocumentServiceImpl class: {}", exp.getMessage());
			throw new BadApiRequestException(exp.getMessage());
		}

	}

	@Override
	public Document uploadDocument(MultipartFile file, DocumentDto documentDto) throws SizeLimitExceededException {
		if (file.getSize() > Constants.MAX_SIZE) {
			log.info("Log from uploadDocument method in DocumentServiceImpl class: "
					+ "uploaded file size is above max size");
			throw new SizeLimitExceededException(env.getProperty("document.upload.max.size.exceed.error.message"));
		}
		Optional<Document> documents = documentRepository.findByFileNameOrName(file.getOriginalFilename(),
				documentDto.getName().trim());
		if (documents.isPresent()) {
			log.info("Log from uploadDocument method in DocumentServiceImpl class: " + "file with name: "
					+ file.getOriginalFilename() + " already exist");
			throw new BadApiRequestException(env.getProperty("document.upload.file.duplicate.error.message"));
		}
		try {
			Path folderPath = Paths.get(uploadFolder);
			if (!Files.exists(folderPath)) {

				createDirectories(folderPath);
			}

			byte[] bytes;
			bytes = file.getBytes();
			Path path = Paths.get(uploadFolder + UUID.randomUUID().toString() + "-" + file.getOriginalFilename());
			Path createdDocument = Files.write(path, bytes);
			Document document = new Document();
			document.setUrl(createdDocument.toAbsolutePath().toString());
			document.setDocumentType(documentDto.getDocumentType());
			document.setName(documentDto.getName().trim());
			document.setFileName(file.getOriginalFilename());
			document.setDescription(documentDto.getDescription());
			return documentRepository.save(document);

		} catch (Exception exp) {
			log.error("Exception Occurred in uploadDocument method in DocumentServiceImpl class: {}", exp.getMessage());
			throw new BadApiRequestException(exp.getMessage());
		}
	}

	private void createDirectories(Path folderPath) {
		try {
			Files.createDirectories(folderPath);
		} catch (IOException exp) {
			log.error("IoException Occurred in uploadDocumentInProduct method in DocumentServiceImpl class: {}",
					exp.getMessage());
			throw new BadApiRequestException(exp.getMessage());
		}

	}

	public ApiResponse<List<DocumentDto>> getAllDocuments() {
		ApiResponse<List<DocumentDto>> response = new ApiResponse<>();

		List<Document> documents = documentRepository.findAll();
		if (!documents.isEmpty()) {
			List<DocumentDto> documentDtos = documents.stream()
					.map(document -> this.modelMapper.map(document, DocumentDto.class)).toList();
			response.setData(documentDtos);
			response.setMessage(env.getProperty("document.fetch.success.message"));
			response.setStatus(HttpStatus.OK.value());
			response.setResult(true);
			return response;
		} else {
			response.setMessage(env.getProperty("document.fetch.error.message"));
			response.setStatus(HttpStatus.NOT_FOUND.value());
			response.setResult(false);
			return response;
		}
	}

	public ApiResponse<Optional<DocumentDto>> getDocumentById(String id) {
		Optional<Document> document = documentRepository.findById(id);
		Optional<DocumentDto> documentDto = document.map(option -> this.modelMapper.map(option, DocumentDto.class));
		ApiResponse<Optional<DocumentDto>> apiResponse = new ApiResponse<>();
		if (document.isPresent()) {
			apiResponse.setData(documentDto);
			apiResponse.setMessage(env.getProperty("document.fetch.success.message"));
			apiResponse.setStatus(HttpStatus.OK.value());
			apiResponse.setResult(true);
		} else {
			apiResponse.setMessage(env.getProperty("document.fetch.error.message"));
			apiResponse.setStatus(HttpStatus.NOT_FOUND.value());
			apiResponse.setResult(false);
		}
		return apiResponse;
	}

	public ApiResponse<DocumentDto> updateDocument(String id, DocumentDto updateDocumentDto) {
		Optional<Document> documentOptional = documentRepository.findById(id);
		ApiResponse<DocumentDto> apiResponse = new ApiResponse<>();
		if (documentOptional.isPresent()) {
			Document existingDocument = documentOptional.get();
			Document updated = documentRepository.save(existingDocument);
			DocumentDto updatedDtoDocument = this.modelMapper.map(updated, DocumentDto.class);

			apiResponse.setData(updatedDtoDocument);
			apiResponse.setMessage(env.getProperty("document.update.success.message"));
			apiResponse.setStatus(HttpStatus.OK.value());
			apiResponse.setResult(true);

		} else {
			apiResponse.setMessage(env.getProperty("document.update.error.message"));
			apiResponse.setStatus(HttpStatus.NO_CONTENT.value());
			apiResponse.setResult(false);
		}
		return apiResponse;
	}

	@Override
	public ApiResponse<DocumentDto> deleteDocument(String id) {
		Optional<Document> documentOptional = documentRepository.findById(id);
		ApiResponse<DocumentDto> apiResponse = new ApiResponse<>();
		Optional<DocumentDto> documentDtoOptional = documentOptional
				.map(docOption -> this.modelMapper.map(docOption, DocumentDto.class));
		if (documentDtoOptional.isPresent()) {
			DocumentDto documentDto = documentDtoOptional.get();
			Document document = this.modelMapper.map(documentDto, Document.class);
			documentRepository.delete(document);
			apiResponse.setMessage(env.getProperty("document.delete.success.message"));
			apiResponse.setStatus(HttpStatus.NO_CONTENT.value());
			apiResponse.setResult(true);
			return apiResponse;
		} else {
			apiResponse.setMessage(env.getProperty("document.delete.error.message"));
			apiResponse.setStatus(HttpStatus.NOT_FOUND.value());
			apiResponse.setResult(false);
			return apiResponse;
		}
	}
}
