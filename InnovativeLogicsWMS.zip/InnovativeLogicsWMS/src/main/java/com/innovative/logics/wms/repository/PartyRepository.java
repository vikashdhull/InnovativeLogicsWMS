package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.Party;

public interface PartyRepository extends JpaRepository<Party, String> {

	final String EXIST_ROLE = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM party_role pr WHERE pr.role = :roleId";

	final String EXIST_PARTY_TYPE = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM party p WHERE p.party_type_id = :partyTypeId";

	final String PARTY_BY_ROLE_NAME = "SELECT p.* FROM party p JOIN party_role pr ON p.id = pr.party JOIN role r ON pr.role = r.id WHERE r.role_name = :roleName";

	Optional<Party> findByName(String name);

	Optional<Party> findByCode(String code);

	Page<Party> findByNameContaining(String keywords, Pageable pageable);

	@Query(value = EXIST_ROLE, nativeQuery = true)
	boolean existByRoleId(String roleId);

	@Query(value = EXIST_PARTY_TYPE, nativeQuery = true)
	boolean existByPartyType(String partyTypeId);

	@Query(value = PARTY_BY_ROLE_NAME, nativeQuery = true)
	List<Party> findPartyByRoleName(String roleName);

}