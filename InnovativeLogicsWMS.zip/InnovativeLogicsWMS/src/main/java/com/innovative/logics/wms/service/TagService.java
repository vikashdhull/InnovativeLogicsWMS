package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.TagDto;

public interface TagService {

	/**
	 * 
	 * This method is used to create the Tag based on given details
	 * 
	 * @author manus
	 * @date 09-Aug-2023
	 * @param tagDto
	 * @return
	 */
	ApiResponse<TagDto> createTag(TagDto tagDto);

	/**
	 * 
	 * This method is used to update the Tag details based on id
	 * 
	 * @author manus
	 * @date 11-Aug-2023
	 * @param tagDto
	 * @param tagId
	 * @return
	 */
	ApiResponse<TagDto> updateTag(TagDto tagDto, String tagId);

	/**
	 * 
	 * This method is used to delete the Tag based on id
	 * 
	 * @author manus
	 * @date 05-Sep-2023
	 * @param tagId
	 * @return
	 */
	ApiResponse<TagDto> deleteTagById(String tagId);

	/**
	 * 
	 * This method is used to fetch the single Tag details from the tag table based
	 * on id
	 * 
	 * @author manus
	 * @date 10-Aug-2023
	 * @param tagId
	 * @return
	 */
	ApiResponse<TagDto> getTagById(String tagId);

	/**
	 * 
	 * This method is used to fetch all the Tag with Pagination and Sorting
	 * 
	 * @author manus
	 * @date 14-Aug-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<TagDto> getAllTag(String org, int pageNumber, int pageSize, String sortBy, String sortDir);
	
	ApiResponse<List<TagDto>> getAllTagsByOrganization(String orgnization);

}