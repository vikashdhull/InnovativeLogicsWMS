package com.innovative.logics.wms.dto;

import java.util.List;

import jakarta.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class StockMovementItemDto {
	
	private String product;
	private Long quantity;
	
	@Nullable
	private List<String> lotNumber;

	
}
