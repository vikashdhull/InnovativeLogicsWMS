package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductCatalogDto;
import com.innovative.logics.wms.service.ProductCatalogService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/product-catalog")
@Slf4j
public class ProductCatalogController {

	@Autowired
	private ProductCatalogService productCatalogService;

	/**
	 * 
	 * The createProductCatalog method is used to create the ProductCatalog and save
	 * the data in product_catalog table based on given details
	 * 
	 * @author manus
	 * @date 21-Jun-2023
	 * @param productCatalogDto
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<ProductCatalogDto>> createProductCatalog(
			@Valid @RequestBody final ProductCatalogDto productCatalogDto) {
		log.info("Enter in createProductCatalog Method present in ProductCatalogController class");
		ApiResponse<ProductCatalogDto> response = productCatalogService.createProductCatalog(productCatalogDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getProductCatalogById method is used to fetch the single Product Catalog
	 * details from the product_catalog table based on id
	 * 
	 * @author manus
	 * @date 24-Jun-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<ProductCatalogDto>> getProductCatalogById(@PathVariable("id") final String id) {
		log.info("Enter in getProductCatalogById Method present in ProductCatalogController class");
		ApiResponse<ProductCatalogDto> response = productCatalogService.getProductCatalogById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The updateProductCatalog method is used to update the Product Catalog details
	 * based on id
	 * 
	 * @author manus
	 * @date 29-Jun-2023
	 * @param productCatalogDto
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<ProductCatalogDto>> updateProductCatalog(
			@Valid @RequestBody final ProductCatalogDto productCatalogDto, @PathVariable("id") final String id) {
		log.info("Enter in updateProductCatalog Method present in ProductCatalogController class");
		ApiResponse<ProductCatalogDto> response = productCatalogService.updateProductCatalog(productCatalogDto, id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	/**
	 * 
	 * The deleteProductCatalogById method is used to delete the Product Catalog
	 * from the product_catalog table based on id
	 * 
	 * @author manus
	 * @date 31-Aug-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<ProductCatalogDto>> deleteProductCatalogById(@PathVariable final String id) {
		log.info("Enter in deleteProductCatalogById Method present in ProductCatalogController class");
		ApiResponse<ProductCatalogDto> response = productCatalogService.deleteProductCatalogById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAllProductCatalog method is used to fetch all the ProductCatalog from
	 * the product_catalog table
	 * 
	 * @author manus
	 * @date 27-Jun-2023
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<PageableResponse<ProductCatalogDto>> getAllProductCatalog(
			@RequestParam(value = "org", required = true) String name,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllProductCatalog Method present in ProductCatalogController class");

		PageableResponse<ProductCatalogDto> response = productCatalogService.getAllProductCatalog(name, pageNumber, pageSize,
				sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	/**
	 * 
	 * Add method description here
	 * 
	 * @author manus
	 * @date 26-Oct-2023
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/active")
	public ResponseEntity<ApiResponse<List<ProductCatalogDto>>> getAllActiveProductCatalogs(
			@RequestParam("org") String name) {
		log.info("Enter in getAllActiveProductCatalogs Method present in ProductCatalogController class");

		ApiResponse<List<ProductCatalogDto>> response = productCatalogService.getAllActiveProductCatalogs(name);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}