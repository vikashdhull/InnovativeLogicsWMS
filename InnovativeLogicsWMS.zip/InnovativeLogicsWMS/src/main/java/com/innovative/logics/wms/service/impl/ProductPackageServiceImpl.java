package com.innovative.logics.wms.service.impl;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.ProductPackageDto;
import com.innovative.logics.wms.dto.response.ProductPackageResponseDto;
import com.innovative.logics.wms.entity.Product;
import com.innovative.logics.wms.entity.ProductPackage;
import com.innovative.logics.wms.entity.ProductSource;
import com.innovative.logics.wms.repository.ProductPackageRepository;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.repository.ProductSourceRepository;
import com.innovative.logics.wms.service.ProductPackageService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProductPackageServiceImpl implements ProductPackageService {

	@Autowired
	private ProductPackageRepository productPackageRepository;

	@Autowired
	private ProductSourceRepository productSourceRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private Environment env;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Utility utility;

	private String productPackageFetchError = "product.package.fetch.error.message";

	@Override
	public ApiResponse<ProductPackageResponseDto> createProductPackage(ProductPackageDto productPackageDto) {
		ApiResponse<ProductPackageResponseDto> response = new ApiResponse<>();

		Optional<ProductPackage> findByDescriptiveName = productPackageRepository
				.findByDescriptiveName(productPackageDto.getDescriptiveName());

		try {

			if (findByDescriptiveName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "product.package.name.error.message");
			}

			Optional<Product> findProductByName = productRepository
					.findByName(productPackageDto.getProduct().getName());
			Optional<ProductSource> findProductSourceByName = productSourceRepository
					.findByName(productPackageDto.getProductSource().getName());

			ProductPackage productPackage = modelMapper.map(productPackageDto, ProductPackage.class);

			if (!findProductByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "product.fetch.error.message");
			}

			if (!findProductSourceByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "product.source.fetch.error.message");
			}

			Product product = findProductByName.get();
			productPackage.setProduct(product);

			productPackage.setPrice(productPackageDto.getQuantity() * product.getAverageUnitPrice());

			productPackage.setProductSource(findProductSourceByName.get());

			ProductPackage savedProductPackage = productPackageRepository.save(productPackage);

			ProductPackageResponseDto packageResponseDto = entityToDto(savedProductPackage);

			response.setData(packageResponseDto);
			response.setResult(true);
			response.setMessage(env.getProperty("product.package.create.success.message"));
			response.setStatus(HttpStatus.CREATED.value());
			return response;

		} catch (Exception exp) {
			log.error("Exception Occurred in createProductPackage Method present in ProductPackageService class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<ProductPackageResponseDto> getProductPackageById(String productPackageId) {
		ApiResponse<ProductPackageResponseDto> response = new ApiResponse<>();
		try {
			Optional<ProductPackage> productPackageOptional = productPackageRepository.findById(productPackageId);

			if (productPackageOptional.isPresent()) {
				ProductPackage productPackage = productPackageOptional.get();

				ProductPackageResponseDto packageResponseDto = entityToDto(productPackage);

				response.setMessage(env.getProperty("product.package.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(packageResponseDto);
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productPackageFetchError);
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in getProductPackageById Method present in ProductPackageService class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<List<ProductPackageResponseDto>> getProductPackagesByProductname(String productName) {

		ApiResponse<List<ProductPackageResponseDto>> response = new ApiResponse<>();

		try {

			List<ProductPackage> productPackages = productPackageRepository
					.findProductPackageByProductName(productName);
			List<ProductPackageResponseDto> productPackageDtos = productPackages.stream().map(this::entityToDto)
					.toList();

			if (!productPackages.isEmpty()) {
				response.setMessage(env.getProperty("product.package.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(productPackageDtos);
				return response;

			} else {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productPackageFetchError);
			}
		} catch (Exception exp) {
			log.error(
					"Exception Occurred in getProductPackagesByProductname Method present in ProductPackageService class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<ProductPackageResponseDto> deleteProductPackageById(String productPackageId) {
		ApiResponse<ProductPackageResponseDto> response = new ApiResponse<>();
		try {

			Optional<ProductPackage> productPackageDetails = productPackageRepository.findById(productPackageId);

			if (productPackageDetails.isPresent()) {

				productPackageRepository.deleteById(productPackageId);
				response.setMessage(env.getProperty("product.package.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productPackageFetchError);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteProductPackageById Method present in ProductPackageService class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private ProductPackageResponseDto entityToDto(ProductPackage productPackage) {

		ProductPackageResponseDto productPackageResponseDto = new ProductPackageResponseDto();

		productPackageResponseDto.setId(productPackage.getId());
		productPackageResponseDto.setDescriptiveName(productPackage.getDescriptiveName());
		productPackageResponseDto.setGtin(productPackage.getGtin());
		productPackageResponseDto.setQuantity(productPackage.getQuantity());
		productPackageResponseDto.setPrice(productPackage.getPrice());
		productPackageResponseDto.setDescription(productPackage.getDescription());
		productPackageResponseDto.setCreatedDate(productPackage.getCreatedDate());
		productPackageResponseDto.setUpdatedDate(productPackage.getUpdatedDate());

		productPackageResponseDto.setProductSource(productPackage.getProductSource().getName());

		productPackageResponseDto.setProduct(productPackage.getProduct().getName());

		return productPackageResponseDto;
	}
}
