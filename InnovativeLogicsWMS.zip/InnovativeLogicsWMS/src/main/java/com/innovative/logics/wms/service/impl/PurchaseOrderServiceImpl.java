package com.innovative.logics.wms.service.impl;

import java.security.Principal;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.OrderDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.PurchaseOrderItemResponseDto;
import com.innovative.logics.wms.dto.response.PurchaseOrderResponseDto;
import com.innovative.logics.wms.entity.Location;
import com.innovative.logics.wms.entity.Order;
import com.innovative.logics.wms.entity.OrderItem;
import com.innovative.logics.wms.entity.User;
import com.innovative.logics.wms.repository.LocationRepository;
import com.innovative.logics.wms.repository.OrderItemRepository;
import com.innovative.logics.wms.repository.OrderRepository;
import com.innovative.logics.wms.repository.UserRepository;
import com.innovative.logics.wms.service.PurchaseOrderService;
import com.innovative.logics.wms.util.Constants;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PurchaseOrderServiceImpl implements PurchaseOrderService {

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private OrderItemRepository orderItemRepository;

	@Autowired
	private LocationRepository locationRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;

	private String orderFetchSuccess = "order.fetch.success.message";

	private String orderFetchError = "order.fetch.error.message";

	@Override
	public ApiResponse<PurchaseOrderResponseDto> createPurchaseOrder(OrderDto orderDto, Principal principal) {

		ApiResponse<PurchaseOrderResponseDto> response = new ApiResponse<>();

		try {
			Optional<Order> findOrderByName = orderRepository.findByName(orderDto.getName());

			if (findOrderByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "order.name.create.error.message");
			}
			Optional<Location> findOriginByName = locationRepository.findByName(orderDto.getOrigin());
			Optional<Location> findDestinationByName = locationRepository.findByName(orderDto.getDestination());

			Optional<User> findByUsername = userRepository.findByUsername(principal.getName());

			Order order = modelMapper.map(orderDto, Order.class);

			if (!findOriginByName.isPresent()) {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "stocklist.location.origin.error.message");
			}

			Location originLocation = findOriginByName.get();
			order.setOrigin(originLocation);

			order.setOriginParty(originLocation.getParty());

			if (!findDestinationByName.isPresent()) {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND,
						"stocklist.location.destination.error.message");
			}
			Location destinationLocation = findDestinationByName.get();
			order.setDestination(destinationLocation);

			order.setDestinationParty(destinationLocation.getParty());

			if (!findByUsername.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "userdetails.delete.error.message");
			}

			order.setOrderedBy(findByUsername.get());
			order.setOrderType(Constants.PURCHASING_ORDER);
			order.setStatus(Constants.PENDING);

			String generateUniqueCode = utility.generateUniqueCode(orderDto.getName());
			order.setOrderNumber("PO-" + generateUniqueCode.toUpperCase());

			Order savedOrder = orderRepository.save(order);

			PurchaseOrderResponseDto orderResponseDto = entityToPurchaseOrderDto(savedOrder);

			response.setData(orderResponseDto);
			response.setResult(true);
			response.setMessage(env.getProperty("order.create.success.message"));
			response.setStatus(HttpStatus.OK.value());
			return response;
		} catch (Exception exp) {
			log.error("Exception Occurred in createOrder Method present in OrderServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<PurchaseOrderResponseDto> getPurchaseOrderById(String orderId) {
		ApiResponse<PurchaseOrderResponseDto> response = new ApiResponse<>();

		try {
			Optional<Order> optionalOrder = orderRepository.findById(orderId);
			if (optionalOrder.isPresent()) {
				PurchaseOrderResponseDto orderDto = optionalOrder.stream().map(this::entityToPurchaseOrderDto)
						.findFirst().get();
				response.setData(orderDto);
				response.setMessage(env.getProperty(orderFetchSuccess));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, orderFetchError);
			}

		} catch (Exception e) {
			log.error("Exception Occured in getPurchaseOrderById Method present in OrderServiceImpl class{}",
					e.getMessage());
			response.setMessage(e.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	@Override
	public PageableResponse<PurchaseOrderResponseDto> getAllPurchaseOrderByDestination (String destinationName, int pageNumber,
				int pageSize, String sortBy, String sortDir) {
		PageableResponse<PurchaseOrderResponseDto> response = new PageableResponse<>();
		
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		try {

			Page<Order> orders = orderRepository.findPurchaseOrdersByDestination(destinationName, pageable);

			List<PurchaseOrderResponseDto> orderResponseDtoDtos = orders.stream().map(this::entityToPurchaseOrderDto)
					.toList();

			if (!orders.isEmpty()) {
				long totalElements = orders.getTotalElements();
				int totalPages = orders.getTotalPages();

				response.setPageNumber(orders.getNumber());
				response.setPageSize(orders.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(orders.isLast());
				response.setMessage(env.getProperty(orderFetchSuccess));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(orderResponseDtoDtos);
				return response;

			} else {

				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, orderFetchError);
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in getAllOrderByDestination Method present in OrderServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public PageableResponse<PurchaseOrderResponseDto> getAllReceivedPurchaseOrderByDestination(String destinationName, int pageNumber,
			int pageSize, String sortBy, String sortDir) {
		
		PageableResponse<PurchaseOrderResponseDto> response = new PageableResponse<>();
		
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		try {

			Page<Order> orders = orderRepository.findPurchaseOrderByStatus(destinationName, pageable);

			List<PurchaseOrderResponseDto> orderResponseDtoDtos = orders.stream().map(this::entityToPurchaseOrderDto)
					.toList();

			if (!orders.isEmpty()) {
				
				long totalElements = orders.getTotalElements();
				int totalPages = orders.getTotalPages();

				response.setPageNumber(orders.getNumber());
				response.setPageSize(orders.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(orders.isLast());
								
				response.setMessage(env.getProperty(orderFetchSuccess));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(orderResponseDtoDtos);

				return response;

			} else {

				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, orderFetchError);
			}
		} catch (Exception exp) {
			log.error(
					"Exception Occurred in getAllReceivedOrderByDestination Method present in OrderServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private PurchaseOrderResponseDto entityToPurchaseOrderDto(Order order) {

		PurchaseOrderResponseDto orderResponse = new PurchaseOrderResponseDto(order);

		List<OrderItem> orderItem = orderItemRepository.findPurchaseOrderByOrderId(order.getId());

		if (!orderItem.isEmpty()) {

			List<PurchaseOrderItemResponseDto> product = orderItem.stream().map(r ->

			new PurchaseOrderItemResponseDto(r.getProduct().getName(), r.getQuantity(), r.getLot(),
					r.getRequestedBy().getUsername(), r.getUnitPrice(),
					r.getProductSource() == null ? null : r.getProductSource().getName(), r.getShipmentDate(),
					r.getDeliveryDate(), (r.getQuantity() * r.getUnitPrice()), r.getCreatedDate(), r.getUpdatedDate()))
					.toList();

			return new PurchaseOrderResponseDto(order, product);
		}
		return orderResponse;
	}

}
