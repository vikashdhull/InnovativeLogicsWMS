package com.innovative.logics.wms.service.impl;

import java.security.Principal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductAvailabilityDto;
import com.innovative.logics.wms.dto.StockMovementDeliveryDto;
import com.innovative.logics.wms.dto.StockMovementItemDto;
import com.innovative.logics.wms.dto.response.StockMovementResponseDto;
import com.innovative.logics.wms.entity.Document;
import com.innovative.logics.wms.entity.InventoryItem;
import com.innovative.logics.wms.entity.Product;
import com.innovative.logics.wms.entity.ProductAvailability;
import com.innovative.logics.wms.entity.StockMovement;
import com.innovative.logics.wms.entity.StockMovementItem;
import com.innovative.logics.wms.entity.User;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.repository.InventoryItemRepository;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.repository.StockMovementItemRepository;
import com.innovative.logics.wms.repository.StockMovementRepository;
import com.innovative.logics.wms.repository.UserRepository;
import com.innovative.logics.wms.service.ProductAvailabilityService;
import com.innovative.logics.wms.service.StockMovementReceiveService;
import com.innovative.logics.wms.service.StockMovementService;
import com.innovative.logics.wms.util.Constants;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StockMovementReceiveServiceImpl implements StockMovementReceiveService {

	@Autowired
	private StockMovementRepository stockMovementRepository;

	@Autowired
	private StockMovementItemRepository stockMovementItemRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	InventoryItemRepository inventoryItemRepository;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;
	
	@Autowired
	private StockMovementService stockMovementService;
	
	@Autowired
	ProductAvailabilityService productAvailabilityService;
	
	@Autowired
	ProductRepository productRepository;
	
	private static final String ORDER_NOT_FOUND = "stock.movement.fetch.error.message";
	private static final String SUCCESS_RESPONSE = "stock.movement.fetch.success.message";

	@Override
	public ApiResponse<StockMovementResponseDto> receiveStockMovement(StockMovementDeliveryDto stockMovementDeliveryDto, 
			 Principal principal){	
		ApiResponse<StockMovementResponseDto> response = new ApiResponse<>();	
		
		try {			
		
		StockMovement order = stockMovementService.getStockMovement(stockMovementDeliveryDto.getStockMovementName());
		
		if(order.getStatus().equals(Constants.VERIFYING) || order.getStatus().equals(Constants.PENDING)) {
			
			return utility.errorResponse(response, HttpStatus.NOT_FOUND, "stock.movement.not.shipped");
		}
		
		if(Objects.equals(order.getStatus(), Constants.SHIPPED) || Objects.equals(order.getStatus(), Constants.PARTIALLY_SHIPPED)
				|| Objects.equals(order.getStatus(), Constants.PARTIALLY_RECEIVED)) {
			
			Collection<StockMovementItemDto> items = stockMovementDeliveryDto.getItems().values();
			
			//check order items cannot be null to process stock.movement
			stockMovementService.productListCannotBeNull(items);
			
			User currentUser = getPresentUser(principal);

			List<StockMovementItem> orderItems = stockMovementItemRepository.findStockMovementItemByStockMovementId(order.getId());

			List<StockMovementItem> list = new ArrayList<>();

			items.stream().forEach(p -> {
				
				String productName = p.getProduct();
				
				StockMovementItem stockMovementItem = checkProductReceiveStatus(productName, orderItems);
				
				Long receivedQty = p.getQuantity();
				
				Long shippedQty = stockMovementItem.getShippedQuantity();
				
				Long balanceQty = shippedQty - receivedQty;
				
				if(balanceQty > 0) {
					stockMovementItem.setSplitItem(true);
				}
				
				stockMovementItem.setRemainingQuantity(balanceQty);				
				stockMovementItem.setReceivedQuantity(receivedQty);
				stockMovementItem.setReceivedDate(LocalDate.now());
				stockMovementItem.setReceivedBy(currentUser);
				stockMovementItem.setStatus(Constants.RECEIVED);
				
				list.add(stockMovementItem);
				
				addProductQuantity(stockMovementItem);
			});
			
			 stockMovementItemRepository.saveAll(list);
			 
			 List<StockMovementItem> saveditems = stockMovementItemRepository.findStockMovementItemByStockMovementId(order.getId());
				
				int numberOfItems = (int) saveditems.stream().filter(i->i.getStatus().equals(Constants.RECEIVED)).count();

				if(saveditems.size() == numberOfItems) {
					order.setStatus(Constants.RECEIVED);
				} else {
					order.setStatus(Constants.PARTIALLY_RECEIVED);
				}
		
		StockMovement savedOrder = stockMovementRepository.save(order);
		
		StockMovementResponseDto result = stockMovementService.entityToDto(savedOrder);

		response.setData(result);
		response.setMessage(env.getProperty("stock.movement.receive.success.message"));
		response.setResult(true);
		response.setStatus(HttpStatus.CREATED.value());
		return response;
		
		}
		
		return utility.errorResponse(response, HttpStatus.CONFLICT, "stock.movement.received.error.message");
		
		} catch (Exception exp) {
			log.error(
					"Exception Occurred in receivestockMovement Method present in StockMovementReceiveServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());

			return response;
		}
	}
	
	@Override
	public ApiResponse<StockMovementResponseDto> uploadStockMovementDocuments(String stockMId,
			MultipartFile file, String documentDto, String shipmentNumber){
		
		ApiResponse<StockMovementResponseDto> response = new ApiResponse<>();
		try {
			
			Optional<StockMovement> optionalOrder = stockMovementRepository.findById(stockMId);

			if (optionalOrder.isEmpty()) {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND, ORDER_NOT_FOUND);
			}

			StockMovement order = optionalOrder.get();
			
			if (order.getStatus().equals(Constants.CANCEL)) {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "stock.movement.cancel.error.message");
			}
			
			List<StockMovementItem> orderItems = stockMovementItemRepository.findStockMovementItemByStockMovementId(order.getId());

			List<StockMovementItem> filteredList = orderItems.stream()
					.filter(i -> i.getShipmentNumber().equals(shipmentNumber)).toList();
			
			if(filteredList.isEmpty()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "stock.movement.shipment.fetch.error.message");
			}
			
			 Long count = filteredList.stream().filter(p->(!p.getStatus().equals(Constants.RECEIVED))).count();	
			 
			 if(count>0) {
				 return utility.errorResponse(response, HttpStatus.BAD_REQUEST, "stock.movement.not.received.error.message");
			 }
			 
			 Document docs = utility.uploadDocument(file, documentDto);				
			 
			List<StockMovementItem> list = new ArrayList<>();

			filteredList.stream().forEach(p -> {

				p.getDocuments().add(docs);
				
				list.add(p);
				
			});
			
			stockMovementItemRepository.saveAll(list);
			
			StockMovementResponseDto result = stockMovementService.entityToDto(order);

			response.setData(result);
			response.setMessage("Document uploaded successfully");
			response.setResult(true);
			response.setStatus(HttpStatus.CREATED.value());
			return response;
		} catch (Exception exp) {
			log.error(
					"Exception Occurred in uploadStockMovementDocuments Method present in StockMovementReceiveServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
		
	}
	
	@Override
	public PageableResponse<StockMovementResponseDto> getAllStockMovementByOrigin(String originName,
			int pageNumber, int pageSize, String sortBy, String sortDir) {
		PageableResponse<StockMovementResponseDto> response = new PageableResponse<>();
		
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<StockMovement> page = stockMovementRepository.findStockMovementByOrigin(originName, pageable);

		List<StockMovementResponseDto> stockMovements = page.stream().map(i->stockMovementService.entityToDto(i))
				.toList();

		if (!stockMovements.isEmpty()) {
			long totalElements = page.getTotalElements();
			int totalPages = page.getTotalPages();
			
			response.setTotalElements(totalElements);
			response.setTotalPages(totalPages);
			response.setPageNumber(page.getNumber());
			response.setPageSize(page.getSize());
			response.setLastPage(page.isLast());
			response.setMessage(env.getProperty(SUCCESS_RESPONSE));
			response.setResult(true);
			response.setStatus(HttpStatus.OK.value());
			response.setData(stockMovements);
			return response;

		} else {

			return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, ORDER_NOT_FOUND);
		}
	}
	
	@Override
	public PageableResponse<StockMovementResponseDto> getAllStockMovementByDestination(String destinationName,
			int pageNumber, int pageSize, String sortBy, String sortDir) {
		
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<StockMovement> page = stockMovementRepository.findStockMovementByDestination(destinationName, pageable);

		PageableResponse<StockMovementResponseDto> response = new PageableResponse<>();

		List<StockMovementResponseDto> stockMovementResponseDtos = page.stream().map(i->stockMovementService.entityToDto(i))
				.toList();

		if (!stockMovementResponseDtos.isEmpty()) {
			
			long totalElements = page.getTotalElements();
			int totalPages = page.getTotalPages();
			
			response.setData(stockMovementResponseDtos);
			response.setPageNumber(page.getNumber());
			response.setPageSize(page.getSize());
			response.setTotalElements(totalElements);
			response.setTotalPages(totalPages);
			response.setLastPage(page.isLast());
			response.setMessage(env.getProperty(SUCCESS_RESPONSE));
			response.setResult(true);
			response.setStatus(HttpStatus.OK.value());
			return response;

		} else {

			return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, ORDER_NOT_FOUND);
		}
	}
	
	@Override
	public ApiResponse<StockMovementResponseDto> cancelStockMovement(String orderName, 
			 Principal principal){
		
				ApiResponse<StockMovementResponseDto> response = new ApiResponse<>();	
		
		try {			
		
		StockMovement order = stockMovementService.getStockMovement(orderName);
		
		//check order should not partially/shipped or partially/received
		
		if( Objects.equals(order.getStatus(), Constants.CANCEL)){
			
			return utility.errorResponse(response, HttpStatus.BAD_REQUEST, "stock.movement.cancel.error.message");
		}
		
		
		if(Objects.equals(order.getStatus(), Constants.SHIPPED) || Objects.equals(order.getStatus(), Constants.PARTIALLY_SHIPPED)
				|| Objects.equals(order.getStatus(), Constants.PARTIALLY_RECEIVED) || Objects.equals(order.getStatus(), Constants.RECEIVED)){
			
			return utility.errorResponse(response, HttpStatus.BAD_REQUEST, "stock.movement.not.cancel.error.message");
		}
			
			User currentUser = getPresentUser(principal);

			List<StockMovementItem> orderItems = stockMovementItemRepository.findStockMovementItemByStockMovementId(order.getId());
			
			orderItems.stream().forEach(i-> i.setStatus(Constants.CANCEL));
			
			order.setStatus(Constants.CANCEL);
			order.setCancelledBy(currentUser);
			order.setCancelledDate(LocalDate.now());
			
			  stockMovementItemRepository.saveAll(orderItems);
		
			 StockMovement savedOrder = stockMovementRepository.save(order);
		
			 StockMovementResponseDto result = stockMovementService.entityToDto(savedOrder);

		response.setData(result);
		response.setMessage(env.getProperty("stock.movement.calcelled"));
		response.setResult(true);
		response.setStatus(HttpStatus.CREATED.value());			
		return response;
		
		}
		catch(Exception exp) {
			
			log.error(
					"Exception Occurred in cancelStockMovement Method present in StockMovementReceiveServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
		
	}
	
	@Override
	public ApiResponse<StockMovementResponseDto> findById(String orderId){
		
		ApiResponse<StockMovementResponseDto> response = new ApiResponse<>();

		Optional<StockMovement> optionalOrder = stockMovementRepository.findById(orderId);
		
		if(optionalOrder.isPresent()) {
			
			StockMovement order= optionalOrder.get();
			
			StockMovementResponseDto result = stockMovementService.entityToDto(order);
			
			response.setData(result);
			response.setMessage(SUCCESS_RESPONSE);
			response.setResult(true);
			response.setStatus(HttpStatus.CREATED.value());
			return response;		
			
		} else {
			return utility.errorResponse(response, HttpStatus.NOT_FOUND, ORDER_NOT_FOUND);
		}				
	}
	
	
	private void addProductQuantity(StockMovementItem stockMovementItem) {
		StockMovement order = stockMovementItem.getStockMovement();

		ProductAvailability productAvailability = new ProductAvailability();
		productAvailability.setProduct(stockMovementItem.getProduct());

		Long receivedQuantity = stockMovementItem.getReceivedQuantity();

		InventoryItem item = new InventoryItem();
	
			//check
			String lotNumber = checkDuplicateLotNumber();
		
		item.setLotNumber(lotNumber);
		item.setQuantityOnHand(receivedQuantity);
		
		//we can add if required any by taking at the the of receving product
		item.setComment(null);

		Set<InventoryItem> setItem = new HashSet<>();

		setItem.add(item);

		productAvailability.setInventoryItem(setItem);
		productAvailability.setLocation(order.getDestination());

		ProductAvailabilityDto productAvailabilityDto = modelMapper.map(productAvailability,
				ProductAvailabilityDto.class);
		productAvailabilityService.createProductAvailability(productAvailabilityDto);
	}
	
	
	private String checkDuplicateLotNumber(){		

		 String lotNumber = utility.generateUniqueNumber();
		 
		 boolean result = inventoryItemRepository.existsByLotNumber(lotNumber);
					
			if(result) {		
					checkDuplicateLotNumber();			
			}			
				return lotNumber;
	}
	
	private User getPresentUser(Principal principal) {

		Optional<User> optionalUser = userRepository.findByUsername(principal.getName());

		if (optionalUser.isEmpty()) {

			throw new BadApiRequestException(env.getProperty("userdetails.fetch.error.message"));
		}

		return optionalUser.get();
	}
	

	public StockMovementItem checkProductReceiveStatus(String productName, List<StockMovementItem> orderItems) {

		Optional<Product> optionalProduct = productRepository.findByName(productName);
		
		 StockMovementItem result = new StockMovementItem();

		if (optionalProduct.isPresent()) {
			Product product = optionalProduct.get();
			
			List<StockMovementItem> optionalP = orderItems.stream().filter(i -> i.getProduct().equals(product))
					.toList();
			
			optionalP.stream().forEach(p -> {
				
				String status = p.getStatus();
							
				if(status.equals(Constants.RECEIVED)) {
					
					throw new BadApiRequestException(env.getProperty("stock.movement.item.receive.error.message"));					
				}
				
				if(status.equals(Constants.VERIFYING) || status.equals(Constants.PENDING)) {
					
					throw new BadApiRequestException(env.getProperty("stock.movement.not.shipped"));					
				}								
			});
			
			result = optionalP.get(0);
		}

		return result;
	}

}
