package com.innovative.logics.wms.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.InventoryItemDto;
import com.innovative.logics.wms.dto.InventorySummary;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductAvailabilityDto;
import com.innovative.logics.wms.dto.response.InStockReportResponseDto;
import com.innovative.logics.wms.dto.response.ProductAvailabilityResponseDto;
import com.innovative.logics.wms.entity.InventoryItem;
import com.innovative.logics.wms.entity.Location;
import com.innovative.logics.wms.entity.Product;
import com.innovative.logics.wms.entity.ProductAvailability;
import com.innovative.logics.wms.repository.InventoryItemRepository;
import com.innovative.logics.wms.repository.LocationRepository;
import com.innovative.logics.wms.repository.ProductAvailabilityRepository;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.service.ProductAvailabilityService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProductAvailabilityServiceImpl implements ProductAvailabilityService {

	@Autowired
	private ProductAvailabilityRepository productAvailabilityRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Environment env;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private LocationRepository locationRepository;

	@Autowired
	private InventoryItemRepository inventoryItemRepository;

	@Autowired
	private Utility utility;

	@Override
	public ApiResponse<ProductAvailabilityResponseDto> createProductAvailability(
			ProductAvailabilityDto productAvailabilityDto) {
		ApiResponse<ProductAvailabilityResponseDto> response = new ApiResponse<>();
		try {
			Optional<Product> existingProduct = productRepository
					.findByName(productAvailabilityDto.getProduct().getName());

			Optional<Location> existingLocation = locationRepository
					.findByName(productAvailabilityDto.getLocation().getName());

			if (!existingProduct.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "product.fetch.error.message");
			}

			if (!existingLocation.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "location.fetch.error.message");
			}

			boolean isDuplicateLotNumber = checkForDuplicateLotNumber(productAvailabilityDto);

			if (isDuplicateLotNumber) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "lot.number.same.error.message");
			}

			Boolean findByLotNumberIn = inventoryItemRepository.existsByLotNumberIn(
					productAvailabilityDto.getInventoryItem().stream().map(InventoryItemDto::getLotNumber).toList());

			if (Boolean.TRUE.equals(findByLotNumberIn)) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "lot.number.error.message");
			}

			Optional<ProductAvailability> existingProductAvailability = productAvailabilityRepository
					.findByProductAndLocation(existingProduct.get(), existingLocation.get());

			ProductAvailability savedProductAvailability;

			if (existingProductAvailability.isPresent()) {

				ProductAvailability productAvailability = existingProductAvailability.get();
				Set<InventoryItemDto> inventoryItemsDto = productAvailabilityDto.getInventoryItem();

				Set<InventoryItem> inventoryItems = inventoryItemsDto.stream()
						.map(dto -> modelMapper.map(dto, InventoryItem.class)).collect(Collectors.toSet());

				Set<InventoryItem> allInventoryItems = new HashSet<>(productAvailability.getInventoryItem());
				allInventoryItems.addAll(inventoryItems);

				productAvailability.setInventoryItem(allInventoryItems);

				savedProductAvailability = productAvailabilityRepository.save(productAvailability);
			} else {

				ProductAvailability productAvailability = modelMapper.map(productAvailabilityDto,
						ProductAvailability.class);
				productAvailability.setProduct(existingProduct.get());
				productAvailability.setLocation(existingLocation.get());
				Set<InventoryItem> inventoryItems = productAvailabilityDto.getInventoryItem().stream()
						.map(dto -> modelMapper.map(dto, InventoryItem.class)).collect(Collectors.toSet());

				productAvailability.setInventoryItem(inventoryItems);

				savedProductAvailability = productAvailabilityRepository.save(productAvailability);
			}

			response.setResult(true);
			response.setMessage(env.getProperty("product.availability.create.success.message"));
			response.setStatus(HttpStatus.CREATED.value());

			ProductAvailabilityResponseDto productAvailabilityResponseDto = entityToDto(savedProductAvailability);
			response.setData(productAvailabilityResponseDto);
		} catch (Exception exp) {
			log.error(
					"Exception Occurred in createProductAvailability Method present in ProductAvailabilityServiceImpl class: {}",
					exp.getMessage());
			response.setMessage("Failed to create ProductAvailability: " + exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
		}
		return response;
	}

	private boolean checkForDuplicateLotNumber(ProductAvailabilityDto productAvailabilityDto) {
		Set<String> lotNumbers = new HashSet<>();
		for (InventoryItemDto inventoryItemDto : productAvailabilityDto.getInventoryItem()) {
			if (!lotNumbers.add(inventoryItemDto.getLotNumber())) {
				return true;
			}
		}
		return false;
	}

	@Override
	public ApiResponse<List<ProductAvailabilityResponseDto>> getproductAvailabilityByLocationAndProduct(
			String locationName, String productName) {

		ApiResponse<List<ProductAvailabilityResponseDto>> response = new ApiResponse<>();

		try {

			List<ProductAvailability> existingProductAvailability = productAvailabilityRepository
					.getProductAvailablityByProductAndLocation(locationName, productName);

			if (!existingProductAvailability.isEmpty()) {

				List<ProductAvailabilityResponseDto> productAvailabilityResponseDtos = existingProductAvailability
						.stream().map(this::entityToDto).toList();
				response.setMessage(env.getProperty("product.package.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(productAvailabilityResponseDtos);
				return response;

			} else {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "product.package.fetch.error.message");
			}
		} catch (Exception exp) {
			log.error(
					"Exception Occurred in getproductAvailabilityByLocationAndProduct Method present in ProductPackageService class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public PageableResponse<InventorySummary> getProductSummariesByLocation(String locationName, int pageNumber,
			int pageSize, String sortBy, String sortDir) {

		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<InventorySummary> page = productAvailabilityRepository.getProductSummaries(locationName, pageable);

		PageableResponse<InventorySummary> response = utility.getPageableResponse(page, InventorySummary.class);

		try {

			if (!response.getData().isEmpty()) {

				return response;

			} else {

				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, "inventory.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occured in getProductSummaries Method present in ProductAvailabilityServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public PageableResponse<ProductAvailabilityResponseDto> getAllProductAvailablityByLocationAndLot(
			String locationName, int pageNumber, int pageSize, String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<ProductAvailability> page = productAvailabilityRepository.findAllByLocation(locationName, pageable);

		PageableResponse<ProductAvailabilityResponseDto> response = new PageableResponse<>();

		try {

			if (!page.isEmpty()) {

				List<ProductAvailabilityResponseDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {

				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, "inventory.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occured in getAllProductAvailablityByLocationAndLot Method present in ProductAvailabilityServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<List<InStockReportResponseDto>> getInStockReport(String locationName) {
		ApiResponse<List<InStockReportResponseDto>> response = new ApiResponse<>();
		List<InStockReportResponseDto> inStockReport = productAvailabilityRepository.getInStockReport(locationName);
		try {
			if (!inStockReport.isEmpty()) {

				response.setData(inStockReport);
				response.setMessage(env.getProperty("instock.report.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "instock.report.error.success.message");
			}
		} catch (Exception exp) {
			log.error(
					"Exception Occured in getAllProductInStock Method present in ProductAvailabilityServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private ProductAvailabilityResponseDto entityToDto(ProductAvailability productAvailability) {

		ProductAvailabilityResponseDto productAvailabilityResponseDto = new ProductAvailabilityResponseDto();

		productAvailabilityResponseDto.setId(productAvailability.getId());

		Product product = productAvailability.getProduct();

		productAvailabilityResponseDto.setProductName(product.getName());
		productAvailabilityResponseDto.setProductCode(product.getCode());

		productAvailabilityResponseDto.setLocation(productAvailability.getLocation().getName());

		List<InventoryItemDto> inventoryItemDtos = productAvailability.getInventoryItem().stream()
				.map(inventoryItem -> modelMapper.map(inventoryItem, InventoryItemDto.class)).toList();

		productAvailabilityResponseDto.setInventoryItem(inventoryItemDtos);

		productAvailabilityResponseDto.setCreatedDate(productAvailability.getCreatedDate());
		productAvailabilityResponseDto.setUpdatedDate(productAvailability.getUpdatedDate());

		return productAvailabilityResponseDto;
	}
}