package com.innovative.logics.wms.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class InStockReportResponseDto {

	private String status;

	private String productId;

	private String productCode;

	private String productName;

	private String location;

	private String abcClasses;

	private Long minimumQuantity;

	private Long reorderQuantity;

	private Long maximumQuantity;

	private Long currentQuantity;

	private Double averageUnitPrice;

	private Double totalValue;
}