package com.innovative.logics.wms.dto.response;

import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderItemResponseDto {

	private String id;

	private String description;

	private OrderResponseDto order;

	private String product;

	private Long quantity;
	
	private String lot;

	private String requestedBy;

	private Double unitPrice;

	private String productSource;

	private LocalDate shipmentDate;

	private LocalDate deliveryDate;
	
	private Double totalCost;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;
}
