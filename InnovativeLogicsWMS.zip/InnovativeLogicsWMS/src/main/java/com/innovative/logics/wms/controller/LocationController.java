package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.LocationDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.LocationResponseDto;
import com.innovative.logics.wms.dto.response.NumberOfQuantity;
import com.innovative.logics.wms.service.LocationService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/locations")
@Slf4j
public class LocationController {

	@Autowired
	private LocationService locationService;

	/**
	 * 
	 * The createLocation method is used to create the Location based on given
	 * details.
	 * 
	 * @author manus
	 * @date 08-May-2023
	 * @param locationDto
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@PostMapping
	public ResponseEntity<ApiResponse<LocationResponseDto>> createLocation(
			@Valid @RequestBody final LocationDto locationDto) {
		log.info("Enter in createLocation Method present in LocationController class");
		ApiResponse<LocationResponseDto> response = locationService.createLocation(locationDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getLocationById method is used to fetch the single location details from
	 * the location table based on id
	 * 
	 * @author manus
	 * @date 15-May-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<LocationResponseDto>> getLocationById(@PathVariable("id") final String id) {
		log.info("Enter in getLocationById Method present in LocationController class");
		ApiResponse<LocationResponseDto> response = locationService.getLocationById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The deleteLocationById method is used to delete the the location details from
	 * the location table based on id
	 * 
	 * @author manus
	 * @date 09-Jun-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<LocationResponseDto>> deleteLocationById(@PathVariable final String id) {
		log.info("Enter in deleteLocationById Method present in LocationController class");
		ApiResponse<LocationResponseDto> response = locationService.deleteLocationById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The findLocationByOrganizationName method is used to fetch all the location
	 * from the location table based on Organization Name
	 * 
	 * @author manus
	 * @date 17-May-2023
	 * @param organizationId
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/organization/{name}")
	public ResponseEntity<PageableResponse<LocationResponseDto>> findLocationByOrganizationName(
			@PathVariable String name,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {

		log.info("Enter in findLocationByOrganizationName Method present in LocationController class");
		PageableResponse<LocationResponseDto> response = locationService.findLocationByOrganizationName(name,
				pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAllLocation method is used to fetch all the location from the location
	 * table
	 * 
	 * @author manus
	 * @date 23-May-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<PageableResponse<LocationResponseDto>> getAllLocation(
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {

		log.info("Enter in getAllLocation Method present in LocationController class");
		PageableResponse<LocationResponseDto> response = locationService.getAllLocation(pageNumber, pageSize, sortBy,
				sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The searchLocation method is used to search the locations based on
	 * LocationName
	 * 
	 * @author manus
	 * @date 06-Jun-2023
	 * @param keyword
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/search/{keyword}")
	public ResponseEntity<PageableResponse<LocationResponseDto>> searchLocation(@PathVariable String keyword,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		PageableResponse<LocationResponseDto> response = locationService.searchLocation(keyword, pageNumber, pageSize,
				sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The updateLocation method is used to update the Location details based on id
	 * 
	 * @author manus
	 * @date 12-Jun-2023
	 * @param locationDto
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<LocationResponseDto>> updateLocation(
			@Valid @RequestBody final LocationDto locationDto, @PathVariable("id") final String id) {
		log.info("Enter in updateLocation Method present in LocationController class");
		ApiResponse<LocationResponseDto> response = locationService.updateLocation(locationDto, id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	/**
	 * 
	 * The getLocationsByRoleName method is used to get the locations based on
	 * RoleName
	 * 
	 * @author manus
	 * @date 04-Sep-2023
	 * @param roleName
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/role/{roleName}")
	public ResponseEntity<ApiResponse<List<LocationResponseDto>>> getLocationsByRoleName(
			@PathVariable("roleName") final String roleName) {
		log.info("Enter in getLocationsByRoleName Method present in LocationController class");
		ApiResponse<List<LocationResponseDto>> response = locationService.getLocationsByRole(roleName);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The getDepotLocationByOrganizationName method is used to get the Depot
	 * locations based on Organization Name Add method description here
	 * 
	 * @author manus
	 * @date 03-Oct-2023
	 * @param partyName
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/depot/organization/{partyName}")
	public ResponseEntity<ApiResponse<List<LocationResponseDto>>> getDepotLocationByOrganizationName(
			@PathVariable("partyName") final String partyName) {
		log.info("Enter in getLocationsByRoleName Method present in LocationController class");
		ApiResponse<List<LocationResponseDto>> response = locationService.getDepotLocationByOrganizationName(partyName);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getNumberOfSupplier method is used to count all the supplier
	 * 
	 * @author manus
	 * @date 04-Oct-2023
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/supplier")
	public ResponseEntity<ApiResponse<NumberOfQuantity>> getNumberOfSupplier(@RequestParam("org") String org) {
		log.info("Enter in getNumberOfSupplier Method present in LocationController class");
		ApiResponse<NumberOfQuantity> response = locationService.getNumberOfSupplier(org);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
