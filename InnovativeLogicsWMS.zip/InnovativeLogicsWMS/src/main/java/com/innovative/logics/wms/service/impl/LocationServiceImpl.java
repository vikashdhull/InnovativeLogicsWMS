package com.innovative.logics.wms.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.innovative.logics.wms.dto.AddressDto;
import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.LocationDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.RoleDto;
import com.innovative.logics.wms.dto.response.LocationResponseDto;
import com.innovative.logics.wms.dto.response.NumberOfQuantity;
import com.innovative.logics.wms.entity.Address;
import com.innovative.logics.wms.entity.Location;
import com.innovative.logics.wms.entity.LocationGroup;
import com.innovative.logics.wms.entity.Party;
import com.innovative.logics.wms.entity.Role;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.exception.ResourceNotFoundException;
import com.innovative.logics.wms.repository.InventoryLevelRepository;
import com.innovative.logics.wms.repository.LocationGroupRepository;
import com.innovative.logics.wms.repository.LocationRepository;
import com.innovative.logics.wms.repository.PartyRepository;
import com.innovative.logics.wms.repository.ProductAvailabilityRepository;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.repository.ProductSourceRepository;
import com.innovative.logics.wms.repository.RoleRepository;
import com.innovative.logics.wms.repository.StockListRepository;
import com.innovative.logics.wms.service.LocationService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LocationServiceImpl implements LocationService {

	@Autowired
	private LocationRepository locationRepository;

	@Autowired
	private PartyRepository partyRepository;

	@Autowired
	private LocationGroupRepository locationGroupRepository;

	@Autowired
	private InventoryLevelRepository inventoryLevelRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ProductAvailabilityRepository productAvailabilityRepository;

	@Autowired
	private ProductSourceRepository productSourceRepository;

	@Autowired
	private StockListRepository stockListRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;

	private String locationFetchErrorMessage = "location.fetch.error.message";

	private String locationFetchSuccessMessage = "location.fetch.success.message";
	
	private String recordFetchSuccessMessage = "record.fetch.success.message";

	@Override
	public ApiResponse<LocationResponseDto> createLocation(LocationDto locationDto) {
		Optional<Location> existLocationByName = locationRepository.findByName(locationDto.getName());

		Optional<Location> existLocationByLocationNumber = locationRepository
				.findByLocationNumber(locationDto.getLocationNumber());

		ApiResponse<LocationResponseDto> response = new ApiResponse<>();

		try {
			if (existLocationByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "location.name.error.message");
			}

			if (existLocationByLocationNumber.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "location.number.error.message");
			}

			Optional<Party> findPartyByName = partyRepository.findByName(locationDto.getParty().getName());
			Optional<LocationGroup> findLocationGroupByName = locationGroupRepository
					.findByName(locationDto.getLocationGroup().getName());
			Optional<Location> findParentLocationByName = locationRepository
					.findByName(locationDto.getParentLocation().getName());

			modelMapper.getConfiguration().setAmbiguityIgnored(true);

			Location location = modelMapper.map(locationDto, Location.class);

			setLocationGroup(location, findLocationGroupByName);
			setParty(location, findPartyByName);
			setParentLocation(location, findParentLocationByName);

			checkAndUpdateRoles(locationDto, location);

			Location savedLocation = locationRepository.save(location);

			LocationResponseDto newDto = entityToDto(savedLocation);

			response.setData(newDto);
			response.setResult(true);
			response.setMessage(env.getProperty("location.create.success.message"));
			response.setStatus(HttpStatus.CREATED.value());

			return response;
		} catch (Exception exp) {
			log.error("Exception Occured in createLocation Method present in LocationServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Transactional
	@Override
	public ApiResponse<LocationResponseDto> updateLocation(LocationDto locationDto, String locationId) {
		ApiResponse<LocationResponseDto> response = new ApiResponse<>();
		try {
			Optional<Location> locationDetails = locationRepository.findById(locationId);
			Optional<Location> existByName = locationRepository.findByName(locationDto.getName());
			Optional<Location> existByLocationNumber = locationRepository
					.findByLocationNumber(locationDto.getLocationNumber());
			if (locationDetails.isPresent()) {
				Location locationData = locationDetails.get();

				if (existByName.isPresent() && !Objects.equals(locationData.getName(), locationDto.getName())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "location.name.error.message");

				}
				locationData.setName(locationDto.getName());

				if (existByLocationNumber.isPresent()
						&& !Objects.equals(locationData.getLocationNumber(), locationDto.getLocationNumber())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "location.number.error.message");
				}
				locationData.setLocationNumber(locationDto.getLocationNumber());
				locationData.setDescription(locationDto.getDescription());
				Optional<Party> findPartyByName = partyRepository.findByName(locationDto.getParty().getName());
				Optional<LocationGroup> findLocationGroupByName = locationGroupRepository
						.findByName(locationDto.getLocationGroup().getName());
				Optional<Location> findParentLocationByName = locationRepository
						.findByName(locationDto.getParentLocation().getName());

				setLocationGroup(locationData, findLocationGroupByName);
				setParty(locationData, findPartyByName);
				setParentLocation(locationData, findParentLocationByName);

				checkAndUpdateRoles(locationDto, locationData);
				modelMapper.getConfiguration().setAmbiguityIgnored(true);
				Address address = modelMapper.map(locationDto.getAddress(), Address.class);
				locationData.setAddress(address);
				Location updatedLocation = locationRepository.save(locationData);

				LocationResponseDto updatedLocationDto = entityToDto(updatedLocation);

				response.setData(updatedLocationDto);
				response.setResult(true);
				response.setMessage(env.getProperty("location.update.success.message"));
				response.setStatus(HttpStatus.OK.value());

				return response;
			} else {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND, locationFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in updateLocation Method present in LocationServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<LocationResponseDto> deleteLocationById(String locationId) {
		ApiResponse<LocationResponseDto> response = new ApiResponse<>();
		try {

			Optional<Location> locationDetails = locationRepository.findById(locationId);

			if (locationDetails.isPresent()) {

				boolean locationInUse = checkIfLocationInUse(locationId);
				if (locationInUse) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "location.use.error.message");
				}
				locationRepository.deleteById(locationId);
				response.setMessage(env.getProperty("location.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, locationFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteLocationById Method present in LocationServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private boolean checkIfLocationInUse(String locationId) {

		boolean existByParentLocation = locationRepository.existByParentLocation(locationId);
		boolean existOriginLocationInInbound = locationRepository.existOriginLocationInInbound(locationId);
		boolean existOriginLocationInOutbound = locationRepository.existOriginLocationInOutbound(locationId);
		boolean existDestinationLocationInInbound = locationRepository.existDestinationLocationInInbound(locationId);
		boolean existDestinationLocationInOutbound = locationRepository.existDestinationLocationInOutbound(locationId);
		boolean existByLocations = inventoryLevelRepository.existsByLocationId(locationId);
		boolean existsByReplenishmentSourceId = inventoryLevelRepository.existsByReplenishmentSourceId(locationId);
		boolean existsByPutawayLocationId = inventoryLevelRepository.existsByPutawayLocationId(locationId);
		boolean existManufacturerInProduct = productRepository.existManufacturerInProduct(locationId);
		boolean existVendorInProduct = productRepository.existVendorInProduct(locationId);
		boolean existSuplierInProductAvailablity = productAvailabilityRepository
				.existSuplierInProductAvailablity(locationId);
		boolean existSuplierInProductSource = productSourceRepository.existSuplierInProductSource(locationId);
		boolean existOriginInStockList = stockListRepository.existOriginInStockList(locationId);
		boolean existDestinationInStockList = stockListRepository.existDestinationInStockList(locationId);

		return existByParentLocation || existOriginLocationInInbound || existOriginLocationInOutbound
				|| existDestinationLocationInInbound || existDestinationLocationInOutbound || existByLocations
				|| existsByReplenishmentSourceId || existsByPutawayLocationId || existManufacturerInProduct
				|| existVendorInProduct || existSuplierInProductAvailablity || existSuplierInProductSource
				|| existOriginInStockList || existDestinationInStockList;
	}

	@Override
	public ApiResponse<LocationResponseDto> getLocationById(String locationId) {
		ApiResponse<LocationResponseDto> response = new ApiResponse<>();
		try {
			Optional<Location> location = locationRepository.findById(locationId);

			if (location.isPresent()) {
				LocationResponseDto entityToDto = entityToDto(location.get());
				response.setMessage(env.getProperty(locationFetchSuccessMessage));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(entityToDto);
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, locationFetchErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getLocationById Method present in LocationServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public PageableResponse<LocationResponseDto> getAllLocation(int pageNumber, int pageSize, String sortBy,
			String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<Location> page = locationRepository.findAll(pageable);

		PageableResponse<LocationResponseDto> response = new PageableResponse<>();
		try {
			if (!page.isEmpty()) {

				List<LocationResponseDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty(recordFetchSuccessMessage));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, locationFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getAllLocation Method present in LocationServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public PageableResponse<LocationResponseDto> searchLocation(String keyword, int pageNumber, int pageSize,
			String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<Location> page = locationRepository.findByNameContaining(keyword, pageable);

		PageableResponse<LocationResponseDto> response = new PageableResponse<>();
		try {
			if (!page.isEmpty()) {

				List<LocationResponseDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty(recordFetchSuccessMessage));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, locationFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in searchLocation Method present in LocationServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	@Transactional
	@Override
	public PageableResponse<LocationResponseDto> findLocationByOrganizationName(String name, int pageNumber,
			int pageSize, String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<Location> page = locationRepository.findLocationByOrganization(name, pageable);

		PageableResponse<LocationResponseDto> response = new PageableResponse<>();
		try {
			if (!page.isEmpty()) {

				List<LocationResponseDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty(recordFetchSuccessMessage));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {

				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, locationFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in findLocationByOrganizationId Method present in LocationServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private void setLocationGroup(Location locationData, Optional<LocationGroup> findLocationGroupByName) {
		if (findLocationGroupByName.isPresent()) {
			locationData.setLocationGroup(findLocationGroupByName.get());
		} else {
			throw new BadApiRequestException(env.getProperty("location.group.fetch.error.message"));
		}
	}

	private void setParty(Location locationData, Optional<Party> findPartyByName) {
		if (findPartyByName.isPresent()) {
			locationData.setParty(findPartyByName.get());
		} else {
			throw new BadApiRequestException(env.getProperty("party.fetch.error.message"));
		}
	}

	private void setParentLocation(Location locationData, Optional<Location> findParentLocationByName) {
		if (findParentLocationByName.isPresent()) {
			Location parentLocation = findParentLocationByName.get();

			if (isCircularParentChildRelationship(parentLocation, locationData)) {
				throw new BadApiRequestException(env.getProperty("circular.parent.child.error.message"));
			} else {
				locationData.setParentLocation(parentLocation);
			}
		} else {
			locationData.setParentLocation(null);
		}
	}

	private void checkAndUpdateRoles(LocationDto locationDto, Location locationData) {
		List<Role> roles = roleRepository
				.findByRoleNameIn(locationDto.getRole().stream().map(RoleDto::getRoleName).toList());
		if (roles.size() != locationDto.getRole().size()) {
			throw new ResourceNotFoundException(env.getProperty("role.fetch.error.message"));
		} else {
			locationData.setRole(new HashSet<>(roles));
		}
	}

	private boolean isCircularParentChildRelationship(Location parentLocation, Location location) {
		while (parentLocation != null) {
			if (parentLocation.getId().equals(location.getId())) {
				return true;
			}
			parentLocation = parentLocation.getParentLocation();
		}
		return false;
	}

	@Override
	public ApiResponse<List<LocationResponseDto>> getLocationsByRole(String roleName) {
		ApiResponse<List<LocationResponseDto>> response = new ApiResponse<>();

		try {
			List<Location> locations = locationRepository.findLocationByRoleAndName(roleName);
			List<LocationResponseDto> locationDtos = locations.stream().map(this::entityToDto).toList();

			if (!locations.isEmpty()) {
				response.setData(locationDtos);
				response.setResult(true);
				response.setMessage(env.getProperty(locationFetchSuccessMessage));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, locationFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getLocationsByRoleAndName Method present in LocationServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<List<LocationResponseDto>> getDepotLocationByOrganizationName(String partyName) {
		ApiResponse<List<LocationResponseDto>> response = new ApiResponse<>();

		try {
			List<Location> locations = locationRepository.findDepotLocationByOrganization(partyName);

			if (!locations.isEmpty()) {

				List<LocationResponseDto> locationDtos = locations.stream().map(this::entityToDto).toList();
				response.setData(locationDtos);
				response.setResult(true);
				response.setMessage(env.getProperty(locationFetchSuccessMessage));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, locationFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occured in getDepotLocationByOrganizationName Method present in LocationServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<NumberOfQuantity> getNumberOfSupplier(String org) {
		ApiResponse<NumberOfQuantity> response = new ApiResponse<>();
		try {
			NumberOfQuantity supplierCount = locationRepository.getSupplierCount(org);

			if (supplierCount != null) {

				response.setMessage(env.getProperty("supplier.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(supplierCount);
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "supplier.fetch.error.message");
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in getNumberOfSupplier Method present in LocationServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private LocationResponseDto entityToDto(Location location) {
		LocationResponseDto locationResponseDto = new LocationResponseDto();
		locationResponseDto.setId(location.getId());
		locationResponseDto.setName(location.getName());
		locationResponseDto.setLocationNumber(location.getLocationNumber());
		locationResponseDto.setDescription(location.getDescription());

		LocationGroup locationGroup = location.getLocationGroup();
		locationResponseDto.setLocationGroup(locationGroup.getName());

		Party party = location.getParty();
		locationResponseDto.setParty(party.getName());

		Location parentLocation = location.getParentLocation();
		if (parentLocation == null) {
			locationResponseDto.setParentLocation(null);
		} else {
			locationResponseDto.setParentLocation(parentLocation.getName());
		}
		Address address = location.getAddress();
		AddressDto addressDto = new AddressDto(address);
		locationResponseDto.setAddress(addressDto);

		Set<Role> roles = location.getRole();
		Set<RoleDto> collect = roles.stream().map(role -> modelMapper.map(role, RoleDto.class))
				.collect(Collectors.toSet());

		locationResponseDto.setRole(collect);

		locationResponseDto.setCreatedDate(location.getCreatedDate());
		locationResponseDto.setUpdatedDate(location.getUpdatedDate());

		return locationResponseDto;
	}

}
