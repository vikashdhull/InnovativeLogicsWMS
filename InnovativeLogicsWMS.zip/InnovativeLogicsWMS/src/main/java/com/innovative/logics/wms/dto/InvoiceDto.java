package com.innovative.logics.wms.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InvoiceDto {
	
	private String order;

}
