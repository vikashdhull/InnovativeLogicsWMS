package com.innovative.logics.wms.service.impl;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.ChangePasswordDto;
import com.innovative.logics.wms.dto.PasswordDto;
import com.innovative.logics.wms.dto.ResetPasswordRequestDto;
import com.innovative.logics.wms.entity.PasswordResetOtp;
import com.innovative.logics.wms.entity.Person;
import com.innovative.logics.wms.entity.User;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.repository.PasswordResetOtpRepository;
import com.innovative.logics.wms.repository.PersonRepository;
import com.innovative.logics.wms.repository.UserRepository;
import com.innovative.logics.wms.service.PasswordService;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import jakarta.servlet.http.HttpServletRequest;

@Service
//@Slf4j
public class PasswordServiceImpl implements PasswordService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PersonRepository personRepository;

	@Autowired
	private PasswordResetOtpRepository passwordResetOtpRepository;

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private Environment env;

	private String emailSubject = "Forgot password OTP";

	@Value("${from.email.address}")
	private String email;

	private Random random;

	@Override
	public ApiResponse<PasswordDto> forgotPassword(PasswordDto forgotPasswordDto, HttpServletRequest request) {
		
		ApiResponse<PasswordDto> response = new ApiResponse<>();
		Person person = personRepository.findByEmail(forgotPasswordDto.getEmail());
		try {
		if (person == null) {
			throw new UsernameNotFoundException(env.getProperty("user.email.found.error.message"));
			
		}

		User user = userRepository.findById(person.getId())
				.orElseThrow(() -> new UsernameNotFoundException(env.getProperty("user.email.found.error.message")));

		String userEmail = user.getPerson().getEmail();

		String name = user.getPerson().getFirstName() + " " + user.getPerson().getLastName();
		
		String otp = generateOtp();
		PasswordResetOtp passwordResetOtp = new PasswordResetOtp(otp, user);
		Optional<PasswordResetOtp> findByUser = passwordResetOtpRepository.findByUserId(person.getId());
		if (findByUser.isPresent()) {
			passwordResetOtpRepository.delete(findByUser.get());
		}
		passwordResetOtpRepository.save(passwordResetOtp);

		String body = renderEmailTemplate(otp, request, name);

		sendEmail(userEmail, emailSubject, body);

		
		response.setMessage("OTP send successfully to " + userEmail);
		response.setResult(true);
		response.setStatus(HttpStatus.OK.value());
		return response;
		} catch(UsernameNotFoundException ex) {

			response.setMessage(ex.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private String generateOtp() {
		try {
			random = SecureRandom.getInstanceStrong();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		int otp = 100000 + random.nextInt(900000);
		return String.valueOf(otp);

	}

	private void sendEmail(String toEmail, String subject, String body) {
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper;
		try {
			helper = new MimeMessageHelper(message, true);
			helper.setFrom(email);
			helper.setTo(toEmail);
			helper.setSubject(subject);
			helper.setText(body, true);
			mailSender.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	private String renderEmailTemplate(String otp, HttpServletRequest request, String name) {
		Context context = new Context();
		context.setVariable("otp", otp);
		context.setVariable(otp, context);
		context.setVariable("name", name);
		String baseUrl = request.getRequestURL().toString().replace(request.getRequestURI(), "")
				+ request.getServletContext().getContextPath();
		context.setVariable("baseUrl", baseUrl);
		return templateEngine.process("resetemail.html", context);
	}

	@Override
	public ApiResponse<ResetPasswordRequestDto> resetPassword(ResetPasswordRequestDto resetPasswordRequestDto) {
		ApiResponse<ResetPasswordRequestDto> response = new ApiResponse<>();
		PasswordResetOtp resetOtp = passwordResetOtpRepository.findByOtp(resetPasswordRequestDto.getOtp());

		if (resetOtp == null) {
			throw new BadApiRequestException(env.getProperty("password.reset.invalid.otp.message"));
		}

		if (resetOtp.getExpiryDate().isBefore(LocalDateTime.now())) {
			passwordResetOtpRepository.delete(resetOtp);
			throw new BadApiRequestException(env.getProperty("password.reset.expire.otp.message"));

		} else {

			User user = resetOtp.getUser();
			user.setPassword(passwordEncoder.encode(resetPasswordRequestDto.getPassword()));
			userRepository.save(user);
			passwordResetOtpRepository.delete(resetOtp);

			response.setMessage(env.getProperty("password.reset.successful.message"));
			response.setResult(true);
			response.setStatus(HttpStatus.OK.value());
			return response;
		}
	}

	@Override
	public ApiResponse<ChangePasswordDto> changePassword(String username, ChangePasswordDto changePasswordDto) {
		ApiResponse<ChangePasswordDto> response = new ApiResponse<>();
		boolean checkPassword = isPasswordTrue(username, changePasswordDto.getOldPassword());
		Optional<User> findByUsername = userRepository.findByUsername(username);
		if (checkPassword && findByUsername.isPresent()) {
			User user = findByUsername.get();
			user.setPassword(passwordEncoder.encode(changePasswordDto.getNewPassword()));
			userRepository.save(user);
			response.setResult(true);
			response.setMessage(env.getProperty("password.reset.successful.message"));
			response.setStatus(HttpStatus.OK.value());
			return response;
		} else {
			response.setResult(false);
			response.setMessage(env.getProperty("password.reset.error.message"));
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public boolean isPasswordTrue(String username, String userPassword) {
		Optional<User> user = userRepository.findByUsername(username);
		if (user.isPresent()) {

			return passwordEncoder.matches(userPassword, user.get().getPassword());
		} else {
			return false;
		}
	}

}
