package com.innovative.logics.wms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.innovative.logics.wms.entity.Attribute;
import com.innovative.logics.wms.entity.AttributeOption;

public interface AttributeOptionRepository extends JpaRepository<AttributeOption, String> {

	final String DELETE_ATTRIBUTE_BY_ID = "DELETE FROM attributes_option ao WHERE ao.attribute_id =:attributeId";

	final String ATTRIBUTE_OPTION_BY_ATTRIBUTE = "SELECT ao.* FROM attributes a JOIN attributes_option ao ON a.id = ao.attribute_id WHERE a.name = :name AND ao.options IN (:options)";

	@Modifying
	@Query(value = DELETE_ATTRIBUTE_BY_ID, nativeQuery = true)
	void deleteByAttributeId(String attributeId);

	List<AttributeOption> findByAttribute(Attribute updatedAttribute);

	List<AttributeOption> findByOptionsIn(List<String> attributeOptionNames);

	@Query(value = ATTRIBUTE_OPTION_BY_ATTRIBUTE, nativeQuery = true)
	List<AttributeOption> findAttributeOptionsByAttributeNameAndOptions(@Param("name") String name,
			@Param("options") List<String> options);

}
