package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.LocationGroup;

public interface LocationGroupRepository extends JpaRepository<LocationGroup, String> {
	
	Optional<LocationGroup> findByName(String name);
	
	Page<LocationGroup> findByNameContaining(String keyword, Pageable pageable);
	
	@Query(value = "SELECT lg FROM LocationGroup lg WHERE lg.party.name =:name")
	Page<LocationGroup> findLocationGroupsByParty(String name, Pageable pageable);
	
	List<LocationGroup> findByPartyName(String name);

}
