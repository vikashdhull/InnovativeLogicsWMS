package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductTypeDto;
import com.innovative.logics.wms.service.ProductTypeService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/product-type")
@Slf4j
public class ProductTypeController {

	@Autowired
	private ProductTypeService productTypeService;

	/**
	 * 
	 * The createProductType method is used to create the Product Type and save the
	 * data in product_type table based on given details
	 * 
	 * @author manus
	 * @date 18-Jul-2023
	 * @param productTypeDto
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<ProductTypeDto>> createProductType(
			@Valid @RequestBody final ProductTypeDto productTypeDto) {
		log.info("Enter in createProductType Method present in ProductTypeController class");
		ApiResponse<ProductTypeDto> response = productTypeService.createProductType(productTypeDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getProductTypeById method is used to fetch the single Product Type
	 * details from the product_type table based on id
	 * 
	 * @author manus
	 * @date 21-Jul-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<ProductTypeDto>> getProductTypeById(@PathVariable("id") final String id) {
		log.info("Enter in getProductTypeById Method present in ProductTypeController class");
		ApiResponse<ProductTypeDto> response = productTypeService.getProductTypeById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The updateProductType method is used to update the Product Type details based
	 * on id
	 * 
	 * @author manus
	 * @date 24-Jul-2023
	 * @param productTypeDto
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<ProductTypeDto>> updateProductType(
			@Valid @RequestBody final ProductTypeDto productTypeDto, @PathVariable("id") final String id) {
		log.info("Enter in updateProductType Method present in ProductTypeController class");
		ApiResponse<ProductTypeDto> response = productTypeService.updateProductType(productTypeDto, id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	/**
	 * 
	 * The getAllProductType method is used to fetch all the Product Type from the
	 * product_type table with Pagination and Sorting
	 * 
	 * @author manus
	 * @date 26-Jul-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<PageableResponse<ProductTypeDto>> getAllProductType(
			@RequestParam(value = "org", required = true) String name,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllProductType Method present in ProductTypeController class");

		PageableResponse<ProductTypeDto> response = productTypeService.getAllProductType(name, pageNumber, pageSize,
				sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<ProductTypeDto>> deleteProductTypeById(@PathVariable final String id) {
		log.info("Enter in deleteProductTypeById Method present in ProductTypeController class");
		ApiResponse<ProductTypeDto> response = productTypeService.deleteProductTypeById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('MANAGER') or hasRole('ADMIN') or hasRole('BROWSER')")
	@GetMapping("org")
	public ResponseEntity<ApiResponse<List<ProductTypeDto>>> getAllProductTypesByOrganization(
			@RequestParam("name") String name) {
		log.info("Enter in getAllProductTypesByOrganization Method present in ProductTypeController class");

		ApiResponse<List<ProductTypeDto>> response = productTypeService.getAllProductTypesByOrganization(name);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
