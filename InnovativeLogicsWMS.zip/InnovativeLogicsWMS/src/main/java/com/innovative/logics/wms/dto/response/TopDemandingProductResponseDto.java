package com.innovative.logics.wms.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TopDemandingProductResponseDto {

	String productName;
	String locationName;
	String organizationName;
	Long quantity;

}
