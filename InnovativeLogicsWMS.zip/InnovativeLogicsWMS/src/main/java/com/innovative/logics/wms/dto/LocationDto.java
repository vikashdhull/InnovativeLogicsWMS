package com.innovative.logics.wms.dto;

import java.time.LocalDateTime;
import java.util.Set;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LocationDto {

	private String id;

	@NotNull(message = "Name should not be null")
	private String name;

	@NotNull(message = "Location Number should not be null")
	private String locationNumber;

	private String description;

	private LocationGroupDto locationGroup;

	private PartyDto party;

	private LocationDto parentLocation;
	
	private AddressDto address;
	
	private Set<RoleDto> role;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
