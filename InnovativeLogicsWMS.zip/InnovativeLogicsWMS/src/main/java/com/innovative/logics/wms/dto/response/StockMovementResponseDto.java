package com.innovative.logics.wms.dto.response;

import java.time.LocalDate;

import java.time.LocalDateTime;
import java.util.List;

import com.innovative.logics.wms.dto.AddressDto;
import com.innovative.logics.wms.entity.StockMovement;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class StockMovementResponseDto {
	
	private String id;
	
	private String name;

	private String origin;
	
	private AddressDto originAddress;

	private String destination;
	
	private AddressDto destinationAddress;

	private String requestedBy;
	
	private LocalDate requestedDate;
	
	private String description;
	
	private String status;

	private String recipient;
	
	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;
	
	private List<StockMovementItemResponseDto> stockMovementItems;
	
	private String approvedBy;
	
	private LocalDate approvedDate;
	
	private String cancelledBy;
	
	private LocalDate cancelledDate;
	
	
	public StockMovementResponseDto(StockMovement stockMovement, List<StockMovementItemResponseDto> stockMovementItems) {
		
		AddressDto originAddressDto = new  AddressDto(stockMovement.getOrigin().getAddress());
		AddressDto destinationAddressDto = new  AddressDto(stockMovement.getDestination().getAddress());
		
		String destinationName = stockMovement.getDestination() != null ? stockMovement.getDestination().getName() : null;
		String requestedUser = stockMovement.getRequestedBy() != null ? stockMovement.getRequestedBy().getUsername(): null;
		String receivedUser = stockMovement.getRecipient() != null ? stockMovement.getRecipient().getUsername(): null;		
		String approvedUser = stockMovement.getApprovedBy() != null ? stockMovement.getApprovedBy().getUsername(): null;
		String cancelledUser = stockMovement.getCancelledBy() != null ? stockMovement.getCancelledBy().getUsername(): null;
		
	
		this.id = stockMovement.getId();
		this.name = stockMovement.getName();
		this.status = stockMovement.getStatus();
		this.description = stockMovement.getDescription();
		this.origin = stockMovement.getOrigin().getName();
		this.destination = destinationName;
		this.destinationAddress = destinationAddressDto;
		this.originAddress = originAddressDto;
		this.requestedBy = requestedUser;
		this.requestedDate = stockMovement.getRequestedDate();
		this.recipient = receivedUser;
		this.createdDate = stockMovement.getCreatedDate();
		this.updatedDate = stockMovement.getUpdatedDate();
		this.approvedBy = approvedUser;
		this.approvedDate = stockMovement.getApprovedDate();
		this.cancelledBy = cancelledUser;
		this.cancelledDate = stockMovement.getCancelledDate();
		this.stockMovementItems = stockMovementItems;
		

	}
}
