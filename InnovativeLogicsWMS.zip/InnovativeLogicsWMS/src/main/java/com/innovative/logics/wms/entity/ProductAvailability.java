package com.innovative.logics.wms.entity;

import java.time.LocalDateTime;
import java.util.Set;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.NamedNativeQuery;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.UuidGenerator;

import com.innovative.logics.wms.dto.response.InStockReportResponseDto;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.ColumnResult;
import jakarta.persistence.ConstructorResult;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SqlResultSetMapping;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "product_availability")
@Getter
@Setter
@NamedNativeQuery(name = "getInStockReport", query = "SELECT" + "(CASE "
		+ "WHEN Sum(ii.quantity_on_hand) < inv.minimum_quantity THEN 'Low Stock' "
		+ "WHEN Sum(ii.quantity_on_hand) > inv.maximum_quantity THEN 'Overstock' "
		+ "WHEN Sum(ii.quantity_on_hand) = 0 THEN 'Out Of Stock'" + "ELSE 'In Stock' "
		+ "END) AS status,p.id AS productId,p.code AS productCode,p.NAME AS productName,l.NAME AS location,p.abc_class AS abcClasses,inv.minimum_quantity AS minimumQuantity,inv.reorder_quantity AS reorderQuantity,inv.maximum_quantity AS maximumQuantity,Sum(ii.quantity_on_hand) AS currentQuantity,"
		+ "p.average_unit_price AS averageUnitPrice," + "(p.average_unit_price*Sum(ii.quantity_on_hand)) AS totalValue "
		+ "FROM product_availability pa " + "INNER JOIN inventory_item ii ON pa.id = ii.product_availability_id "
		+ "INNER JOIN product p ON pa.product_id = p.id " + "INNER JOIN location l ON pa.supplier_id = l.id "
		+ "INNER JOIN inventory_level inv ON inv.product_id = p.id " + "WHERE l.name =:locationName " + " AND inv.default_location_id = l.`id`"
		+ "GROUP BY pa.product_id, p.name,pa.supplier_id,l.name", resultSetMapping = "inStockReportDto")
@SqlResultSetMapping(name = "inStockReportDto", classes = @ConstructorResult(targetClass = InStockReportResponseDto.class, columns = {
		@ColumnResult(name = "status", type = String.class), 
		@ColumnResult(name = "productId", type = String.class),
		@ColumnResult(name = "productCode", type = String.class),
		@ColumnResult(name = "productName", type = String.class), 
		@ColumnResult(name = "location", type = String.class),
		@ColumnResult(name = "abcClasses", type = String.class),
		@ColumnResult(name = "minimumQuantity", type = Long.class),
		@ColumnResult(name = "reorderQuantity", type = Long.class),
		@ColumnResult(name = "maximumQuantity", type = Long.class),
		@ColumnResult(name = "currentQuantity", type = Long.class),
		@ColumnResult(name = "averageUnitPrice", type = Double.class),
		@ColumnResult(name = "totalValue", type = Double.class) }))
public class ProductAvailability {

	@Column(name = "id") 
	@Id 
	@UuidGenerator
	private String id; 
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id", referencedColumnName = "id")
    private Product product;
	
	@ManyToOne(fetch = FetchType.EAGER) 
	@JoinColumn(name = "supplier_id", referencedColumnName = "id") 
	private Location location; 
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL) 
	@JoinColumn(name = "product_availability_id", referencedColumnName = "id") 
	private Set<InventoryItem> inventoryItem; 
	
	@Column(name = "created_date", nullable = false, updatable = false) 
	@CreationTimestamp 
	private LocalDateTime createdDate; 
	
	@Column(name = "updated_date") 
	@UpdateTimestamp 
	private LocalDateTime updatedDate; 

}