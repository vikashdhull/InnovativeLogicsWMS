package com.innovative.logics.wms.dto.response;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class StockListResponseDto {

	private String id;

	private String name;

	private String origin;

	private String destination;

	private int replenishmentPeriodDays;

	private String replenishmentType;

	private String description;

	private int requisitionItems;

	private boolean published;
	
	private String party;

	private String createdBy;

	private String updatedBy;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
