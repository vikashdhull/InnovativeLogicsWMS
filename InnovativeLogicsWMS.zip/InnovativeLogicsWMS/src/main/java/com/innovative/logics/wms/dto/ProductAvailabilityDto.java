package com.innovative.logics.wms.dto;

import java.time.LocalDateTime;
import java.util.Set;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductAvailabilityDto {
	
	private String id;

	private ProductDto product;

	private LocationDto location;
	
	private Set<InventoryItemDto> inventoryItem;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
