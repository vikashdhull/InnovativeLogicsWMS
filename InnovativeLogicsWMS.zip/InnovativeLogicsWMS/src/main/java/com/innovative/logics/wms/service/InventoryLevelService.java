package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.InventoryLevelDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.InventoryLevelResponseDto;

public interface InventoryLevelService {

	/**
	 * This method is used to create the Inventory level based on given details
	 * 
	 * @author abhineets
	 * @date 24-Aug-2023
	 * @param inventoryLevelDto
	 * @return
	 */
	ApiResponse<InventoryLevelResponseDto> createInventorylevel(InventoryLevelDto inventoryLevelDto);

	/**
	 * 
	 * This method is used to get the Inventory level based on id
	 * 
	 * @author abhineets
	 * @param inventoryId
	 * @return
	 */
	ApiResponse<InventoryLevelResponseDto> getInventoryLevelById(String inventoryId);

	/**
	 * 
	 * This method is used to get the Inventory level based on product id
	 * 
	 * @author abhineets
	 * @date 28-Aug-2023
	 * @param productId
	 * @return
	 */
	ApiResponse<List<InventoryLevelResponseDto>> getInventoryLevelByProductId(String productId);
	
	
	ApiResponse<List<InventoryLevelResponseDto>> getInventoryLevelByLocationName(String name);

	/**
	 * 
	 * This method is used to get all the Inventory level based on given details
	 * 
	 * @author abhineets
	 * @date 31-Aug-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */

	PageableResponse<InventoryLevelResponseDto> getAllInventoryLevels(String org, int pageNumber, int pageSize, String sortBy,
			String sortDir);

	/**
	 * 
	 * This method is used to update the Inventory level based on given details
	 * 
	 * @author abhineets
	 * @param inventoryLevelDto
	 * @param id
	 * @return
	 */
	ApiResponse<InventoryLevelResponseDto> updateInventorylevel(InventoryLevelDto inventoryLevelDto, String id);

	/**
	 * 
	 * This method is used to delete the Inventory level based on id
	 * 
	 * @author abhineets
	 * @param inventoryId
	 * @return
	 */
	ApiResponse<InventoryLevelResponseDto> deleteInventoryLevelById(String inventoryId);
}
