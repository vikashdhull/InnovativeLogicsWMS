package com.innovative.logics.wms.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PartyTypeDto {

	private String id;

	@NotBlank(message = "Code should not be blank")
	private String code;
	
	@NotBlank(message = "Name should not be blank")
	private String name;

	@NotBlank(message = "Party Type Code should not be blank")
	private String partyTypeCode;
	
	private String description;

}
