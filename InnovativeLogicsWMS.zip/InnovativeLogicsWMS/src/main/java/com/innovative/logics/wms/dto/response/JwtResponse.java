package com.innovative.logics.wms.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class JwtResponse {
	private String jwtToken;
	private String username;
	private String firstName;
	private String lastName;
	private String organization;
	private String role;

}