package com.innovative.logics.wms.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderItemDto {

	private String description;

	private String product;

	private Long quantity;

	private Double unitPrice;

	private String productSource;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate shipmentDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate deliveryDate;

}
