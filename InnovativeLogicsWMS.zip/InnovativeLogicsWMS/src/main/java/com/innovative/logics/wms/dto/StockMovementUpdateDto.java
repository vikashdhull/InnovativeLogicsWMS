package com.innovative.logics.wms.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StockMovementUpdateDto {
	
	private String productName;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate expectedShippingdate;
	
	private String comment;


}
