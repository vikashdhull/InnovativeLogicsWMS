package com.innovative.logics.wms.dto.response;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductPackageResponseDto {
	
	private String id;

	private String descriptiveName;

	private String gtin;

	private Integer quantity;

	private String description;
	
	private Double price;

	private String productSource;

	private String product;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
