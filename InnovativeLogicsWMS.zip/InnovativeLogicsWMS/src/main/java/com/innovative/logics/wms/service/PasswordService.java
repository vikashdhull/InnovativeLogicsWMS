package com.innovative.logics.wms.service;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.ChangePasswordDto;
import com.innovative.logics.wms.dto.PasswordDto;
import com.innovative.logics.wms.dto.ResetPasswordRequestDto;

import jakarta.servlet.http.HttpServletRequest;

public interface PasswordService {

	/**
	 * 
	 * This method is used to send the OTP
	 * 
	 * @author manus
	 * @date 19-Apr-2023
	 * @param passwordDto
	 * @param request
	 * @return
	 */
	ApiResponse<PasswordDto> forgotPassword(PasswordDto passwordDto, HttpServletRequest request);

	/**
	 * 
	 * This method is used to reset the password using OTP
	 * 
	 * @author manus
	 * @date 21-Apr-2023
	 * @param resetPasswordRequestDto
	 * @return
	 */
	ApiResponse<ResetPasswordRequestDto> resetPassword(ResetPasswordRequestDto resetPasswordRequestDto);

	/**
	 * 
	 * This method is used to update the password using Old password
	 * 
	 * @author manus 
	 * @date 11-May-2023 
	 * @param username
	 * @param changePasswordDto
	 * @return
	 */
	ApiResponse<ChangePasswordDto> changePassword(String username, ChangePasswordDto changePasswordDto);

	/**
	 * 
	 * This method is used to check the old password is valid or not
	 * 
	 * @author manus
	 * @date 10-Jun-2023
	 * @param username
	 * @param userPassword
	 * @return
	 */
	boolean isPasswordTrue(String username, String userPassword);

}
