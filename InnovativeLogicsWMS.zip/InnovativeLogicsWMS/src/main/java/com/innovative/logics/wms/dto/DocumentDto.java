package com.innovative.logics.wms.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DocumentDto {

	private String id;

	private String name;

	private String fileName;
	
	private String documentType;

	private String description;

	private String url;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
