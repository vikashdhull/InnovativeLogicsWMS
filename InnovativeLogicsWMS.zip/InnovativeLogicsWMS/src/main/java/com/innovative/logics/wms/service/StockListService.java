package com.innovative.logics.wms.service;

import java.security.Principal;
import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.StockListDto;
import com.innovative.logics.wms.dto.response.StockListResponseDto;

public interface StockListService {

	/**
	 * This method is used to create the StockList based on given details
	 * 
	 * @author abhineets
	 * @date 08-Sep-2023
	 * @param stockListDto
	 * @return
	 */
	ApiResponse<StockListResponseDto> createStockList(StockListDto stockListDto, Principal principal);

	/**
	 * 
	 * This method is used to fetch all StockList details
	 * 
	 * @author abhineets
	 * @date 12-Sep-2023
	 * @return
	 */
	ApiResponse<List<StockListResponseDto>> getAllStockList(String orgnization);
	
	PageableResponse<StockListResponseDto> getAllStockListPage(String org, int pageNumber, int pageSize, String sortBy, String sortDir);
	
	ApiResponse<List<StockListResponseDto>> getAllStockListByOriginAndDestination(String originName, String destinationName);

	/**
	 * This method is used to update the StockList based on given details
	 * 
	 * @author abhineets
	 * @date 11-Sep-2023
	 * @param stockListDto
	 * @param id
	 * @return
	 */
	ApiResponse<StockListResponseDto> updateStockListById(StockListDto stockListDto, String id, Principal principal);

	/**
	 * This method is used to delete the StockList based on id
	 * 
	 * @param stockListDto
	 * @author abhineets
	 * @date 15-Sep-2023
	 * @param id
	 * @return
	 */
	ApiResponse<StockListResponseDto> deleteStockListById(String id);

}
