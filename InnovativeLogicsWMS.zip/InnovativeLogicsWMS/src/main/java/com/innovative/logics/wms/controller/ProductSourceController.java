package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductSourceDto;
import com.innovative.logics.wms.dto.response.ProductSourceResponseDto;
import com.innovative.logics.wms.service.ProductSourceService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/product-source")
@Slf4j
public class ProductSourceController {

	@Autowired
	private ProductSourceService productSourceService;

	/**
	 * 
	 * The createProductSource method is used to create the ProductSource and save
	 * the data in product_source table based on given details
	 * 
	 * @author manus
	 * @date 05-Sep-2023
	 * @param productSourceDto
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<ProductSourceResponseDto>> createProductSource(
			@Valid @RequestBody final ProductSourceDto productSourceDto) {
		log.info("Enter in createProductSource Method present in ProductSourceController class");
		ApiResponse<ProductSourceResponseDto> response = productSourceService.createProductSource(productSourceDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<ProductSourceResponseDto>> getProductSourceById(
			@PathVariable("id") final String id) {
		log.info("Enter in getProductSourceById Method present in ProductSourceController class");
		ApiResponse<ProductSourceResponseDto> response = productSourceService.getProductSourceById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * Add method description here
	 * 
	 * @author manus
	 * @date 11-Sep-2023
	 * @param productSourceDto
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<ProductSourceResponseDto>> updateProductSource(
			@Valid @RequestBody final ProductSourceDto productSourceDto, @PathVariable("id") final String id) {
		log.info("Enter in updateProductSource Method present in ProductSourceController class");
		ApiResponse<ProductSourceResponseDto> response = productSourceService.updateProductSource(productSourceDto, id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<PageableResponse<ProductSourceResponseDto>> getAllProductSource(
			@RequestParam(value = "org", required = true) String name,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllProductSource Method present in ProductSourceController class");

		PageableResponse<ProductSourceResponseDto> response = productSourceService.getAllProductSource(name, pageNumber,
				pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getProductSourcesByProductname method is used to fetch all the
	 * ProductSource by product name from the product_source table
	 * 
	 * @author manus
	 * @date 08-Sep-2023
	 * @param productName
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/product/{productName}")
	public ResponseEntity<ApiResponse<List<ProductSourceResponseDto>>> getProductSourcesByProductname(
			@PathVariable("productName") final String productName) {
		log.info("Enter in getProductSourcesByProductname Method present in ProductSourceController class");

		ApiResponse<List<ProductSourceResponseDto>> response = productSourceService
				.getProductSourcesByProductname(productName);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * Add method description here
	 * @author manus 
	 * @date 24-Oct-2023 
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<ProductSourceResponseDto>> deleteProductSourceById(
			@PathVariable final String id) {
		log.info("Enter in deleteProductSourceById Method present in ProductSourceController class");
		ApiResponse<ProductSourceResponseDto> response = productSourceService.deleteProductSourceById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
