package com.innovative.logics.wms.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "inventory_item", uniqueConstraints = {@UniqueConstraint(columnNames = {"lot_number"})})
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class InventoryItem {
	
	@Column(name = "id")
	@Id
	@UuidGenerator
	private String id;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.DETACH)
	@JoinColumn(name = "product_availability_id", referencedColumnName = "id") 
	private ProductAvailability productAvailability;
	
	@Column(name = "lot_number", length = 30)
	private String lotNumber;
	
	@Column(name = "quantity_on_hand")
	private Long quantityOnHand;
	
	@Column(name = "comment")
	private String comment;
	
	@Column(name = "created_date", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createdDate;

	@Column(name = "updated_date")
	@UpdateTimestamp
	private LocalDateTime updatedDate;

}
