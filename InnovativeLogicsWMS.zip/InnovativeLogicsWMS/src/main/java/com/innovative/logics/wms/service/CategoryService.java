package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.CategoryDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.NumberOfQuantity;

public interface CategoryService {

	/**
	 * 
	 * This method is used to create the Category based on given details
	 * 
	 * @author manus
	 * @date 31-Jul-2023
	 * @param categoryDto
	 * @return
	 */
	ApiResponse<CategoryDto> createCategory(CategoryDto categoryDto);

	/**
	 * 
	 * This method is used to update the Category details based on id
	 * 
	 * @author manus
	 * @date 04-Aug-2023
	 * @param categoryDto
	 * @param categoryId
	 * @return
	 */
	ApiResponse<CategoryDto> updateCategory(CategoryDto categoryDto, String categoryId);

	/**
	 * 
	 * This method is used to delete the Category based on id
	 * 
	 * @author manus
	 * @date 01-Sep-2023
	 * @param categoryId
	 * @return
	 */
	ApiResponse<CategoryDto> deleteCategoryById(String categoryId);

	/**
	 * 
	 * This method is used to fetch the single Category details based on id
	 * 
	 * @author manus
	 * @date 03-Aug-2023
	 * @param categoryId
	 * @return
	 */
	ApiResponse<CategoryDto> getCategoryById(String categoryId);

	/**
	 * 
	 * This method is used to fetch all the Category with Pagination and Sorting
	 * 
	 * @author manus
	 * @date 07-Aug-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<CategoryDto> getAllCategory(String org, int pageNumber, int pageSize, String sortBy, String sortDir);
	
	ApiResponse<List<CategoryDto>> getAllCategoriesByOrganization(String orgnization);
	
	ApiResponse<NumberOfQuantity> getNumberOfCategories(String org);

}
