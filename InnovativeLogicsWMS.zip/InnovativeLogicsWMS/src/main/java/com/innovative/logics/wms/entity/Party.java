package com.innovative.logics.wms.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Set;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "party", uniqueConstraints = { @UniqueConstraint(columnNames = { "name" }) })
@Getter
@Setter
public class Party implements Serializable{

	/** long Short Description */
	private static final long serialVersionUID = 1L;

	@Column(name = "id")
	@Id
	@UuidGenerator
	private String id;

	@Column(name = "name", length = 50)
	@NotNull(message = "Name should not be null")
	private String name;
	
	@Column(name = "code", length = 50)
	private String code;
	
	@Column(name = "description", length = 150)
	private String description;
	
	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "party_type_id", referencedColumnName="id")
	private PartyType partyType;
	
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinTable(name = "party_role", joinColumns = @JoinColumn(name = "party", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "role", referencedColumnName = "id"))
	private Set<Role> role;
	
	@Column(name = "org_logo")
	private String orgLogo;
	
	@Column(name = "created_date", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createdDate;

	@Column(name = "updated_date")
	@UpdateTimestamp
	private LocalDateTime updatedDate;

}
