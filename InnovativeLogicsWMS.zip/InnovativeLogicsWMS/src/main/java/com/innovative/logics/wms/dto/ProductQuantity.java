package com.innovative.logics.wms.dto;

public interface ProductQuantity {
	
	String getProductName();

	Integer getTotalQuantity();


}
