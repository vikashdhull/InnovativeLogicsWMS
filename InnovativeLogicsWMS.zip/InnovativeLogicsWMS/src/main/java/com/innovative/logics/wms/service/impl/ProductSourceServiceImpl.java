package com.innovative.logics.wms.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductSourceDto;
import com.innovative.logics.wms.dto.response.ProductSourceResponseDto;
import com.innovative.logics.wms.entity.Location;
import com.innovative.logics.wms.entity.Party;
import com.innovative.logics.wms.entity.Product;
import com.innovative.logics.wms.entity.ProductSource;
import com.innovative.logics.wms.repository.LocationRepository;
import com.innovative.logics.wms.repository.PartyRepository;
import com.innovative.logics.wms.repository.ProductPackageRepository;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.repository.ProductSourceRepository;
import com.innovative.logics.wms.service.ProductSourceService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProductSourceServiceImpl implements ProductSourceService {

	@Autowired
	private ProductSourceRepository productSourceRepository;

	@Autowired
	private ProductPackageRepository productPackageRepository;

	@Autowired
	private LocationRepository locationRepository;

	@Autowired
	private PartyRepository partyRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private Environment env;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Utility utility;

	private String productSourceFetchErrorMessage = "product.source.fetch.error.message";

	@Override
	public ApiResponse<ProductSourceResponseDto> createProductSource(ProductSourceDto productSourceDto) {
		ApiResponse<ProductSourceResponseDto> response = new ApiResponse<>();

		Optional<ProductSource> existProductSourceByName = productSourceRepository
				.findByName(productSourceDto.getName());
		Optional<ProductSource> existProductSourceByCode = productSourceRepository
				.findByCode(productSourceDto.getCode());

		Optional<Party> findOrgByName = partyRepository.findByName(productSourceDto.getOrg());

		try {
			if (existProductSourceByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "product.source.name.error.message");
			}

			if (existProductSourceByCode.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "product.source.code.error.message");
			}

			Optional<Location> findLocationByName = locationRepository
					.findByName(productSourceDto.getLocation().getName());
			Optional<Product> findProductByName = productRepository.findByName(productSourceDto.getProduct().getName());
			Optional<Party> findPartyByName = partyRepository.findByName(productSourceDto.getParty().getName());

			ProductSource productSource = modelMapper.map(productSourceDto, ProductSource.class);

			if (!findLocationByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "location.fetch.error.message");
			}

			if (!findProductByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "product.fetch.error.message");
			}

			if (!findPartyByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "party.fetch.error.message");
			}

			Product product = findProductByName.get();
			if (!product.isStatus()) {
				return utility.errorResponse(response, HttpStatus.BAD_REQUEST, "product.active.error.message");
			}

			productSource.setLocation(findLocationByName.get());
			productSource.setProduct(product);
			productSource.setParty(findPartyByName.get());
			if (findOrgByName.isPresent()) {
				productSource.setOrg(findOrgByName.get());
			}
			ProductSource savedProductSource = productSourceRepository.save(productSource);

			ProductSourceResponseDto newDto = entityToDto(savedProductSource);

			response.setData(newDto);
			response.setResult(true);
			response.setMessage(env.getProperty("product.source.create.success.message"));
			response.setStatus(HttpStatus.CREATED.value());
			return response;

		} catch (Exception exp) {
			log.error("Exception Occurred in createProductSource Method present in ProductSourceServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<ProductSourceResponseDto> updateProductSource(ProductSourceDto productSourceDto,
			String productSourceId) {
		ApiResponse<ProductSourceResponseDto> response = new ApiResponse<>();

		try {
			Optional<ProductSource> productSourceOptional = productSourceRepository.findById(productSourceId);
			if (!productSourceOptional.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productSourceFetchErrorMessage);
			}

			ProductSource existingProductSource = productSourceOptional.get();

			ApiResponse<ProductSourceResponseDto> nameConflictResponse = checkAndUpdateNameConflict(
					existingProductSource, productSourceDto, response);
			if (nameConflictResponse != null) {
				return nameConflictResponse;
			}

			ApiResponse<ProductSourceResponseDto> codeConflictResponse = checkAndUpdateCodeConflict(
					existingProductSource, productSourceDto, response);
			if (codeConflictResponse != null) {
				return codeConflictResponse;
			}

			existingProductSource.setDescription(productSourceDto.getDescription());
			existingProductSource.setPreferenceType(productSourceDto.getPreferenceType());
			existingProductSource.setRatingType(productSourceDto.getRatingType());
			existingProductSource.setMinOrderQuantity(productSourceDto.getMinOrderQuantity());
			existingProductSource.setContractPrice(productSourceDto.getContractPrice());
			existingProductSource.setContractValidUntil(productSourceDto.getContractValidUntil());

			Optional<Location> findLocationByName = locationRepository
					.findByName(productSourceDto.getLocation().getName());
			if (!findLocationByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "location.fetch.error.message");
			}
			existingProductSource.setLocation(findLocationByName.get());

			Optional<Product> findProductByName = productRepository.findByName(productSourceDto.getProduct().getName());
			if (!findProductByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "product.fetch.error.message");
			}
			existingProductSource.setProduct(findProductByName.get());

			Optional<Party> findPartyByName = partyRepository.findByName(productSourceDto.getParty().getName());
			if (!findPartyByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "party.fetch.error.message");
			}
			existingProductSource.setParty(findPartyByName.get());

			ProductSource updatedProductSource = productSourceRepository.save(existingProductSource);

			ProductSourceResponseDto updatedDto = entityToDto(updatedProductSource);

			response.setData(updatedDto);
			response.setResult(true);
			response.setMessage(env.getProperty("product.source.update.success.message"));
			response.setStatus(HttpStatus.OK.value());
			return response;
		} catch (Exception exp) {
			log.error("Exception Occurred in updateProductSource Method present in ProductSourceServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private ApiResponse<ProductSourceResponseDto> checkAndUpdateNameConflict(ProductSource existingProductSource,
			ProductSourceDto productSourceDto, ApiResponse<ProductSourceResponseDto> response) {
		Optional<ProductSource> existProductSourceByName = productSourceRepository
				.findByName(productSourceDto.getName());
		if (existProductSourceByName.isPresent()
				&& !Objects.equals(existingProductSource.getName(), productSourceDto.getName())) {
			return utility.errorResponse(response, HttpStatus.CONFLICT, "product.source.name.error.message");
		}
		existingProductSource.setName(productSourceDto.getName());
		return null;
	}

	private ApiResponse<ProductSourceResponseDto> checkAndUpdateCodeConflict(ProductSource existingProductSource,
			ProductSourceDto productSourceDto, ApiResponse<ProductSourceResponseDto> response) {
		Optional<ProductSource> existProductSourceByCode = productSourceRepository
				.findByCode(productSourceDto.getCode());
		if (existProductSourceByCode.isPresent()
				&& !Objects.equals(existingProductSource.getCode(), productSourceDto.getCode())) {
			return utility.errorResponse(response, HttpStatus.CONFLICT, "product.source.code.error.message");
		}
		existingProductSource.setCode(productSourceDto.getCode());
		return null;
	}

	@Override
	public ApiResponse<ProductSourceResponseDto> getProductSourceById(String productSourceId) {
		ApiResponse<ProductSourceResponseDto> response = new ApiResponse<>();
		try {
			Optional<ProductSource> productSourceOptional = productSourceRepository.findById(productSourceId);

			if (productSourceOptional.isPresent()) {
				modelMapper.getConfiguration().setAmbiguityIgnored(true);
				ProductSource productSource = productSourceOptional.get();
				ProductSourceResponseDto productSourceResponseDto = entityToDto(productSource);

				response.setMessage(env.getProperty("product.source.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(productSourceResponseDto);
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productSourceFetchErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in getProductSourceById Method present in ProductSourceServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public ApiResponse<List<ProductSourceResponseDto>> getProductSourcesByProductname(String productName) {

		ApiResponse<List<ProductSourceResponseDto>> response = new ApiResponse<>();
		List<ProductSource> findProductSourcsByProductName = productSourceRepository
				.findProductSourcsByProductName(productName);
		try {
			if (!findProductSourcsByProductName.isEmpty()) {
				List<ProductSourceResponseDto> productSourceResponseDtos = findProductSourcsByProductName.stream()
						.map(this::entityToDto).toList();
				response.setData(productSourceResponseDtos);
				response.setMessage(env.getProperty("product.source.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productSourceFetchErrorMessage);
			}
		} catch (Exception exp) {
			log.error(
					"Exception Occurred in getProductSourcesByProductname Method present in ProductSourceServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<ProductSourceResponseDto> deleteProductSourceById(String productSourceId) {
		ApiResponse<ProductSourceResponseDto> response = new ApiResponse<>();
		try {

			Optional<ProductSource> productSourceDetails = productSourceRepository.findById(productSourceId);

			if (productSourceDetails.isPresent()) {

				boolean productSourceInUse = checkIfProductSourceInUse(productSourceId);

				if (productSourceInUse) {

					return utility.errorResponse(response, HttpStatus.CONFLICT, "product.source.use.error.message");
				}

				productSourceRepository.deleteById(productSourceId);
				response.setMessage(env.getProperty("product.source.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productSourceFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteProductSourceById Method present in ProductSourceServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private boolean checkIfProductSourceInUse(String productSourceId) {
		return productPackageRepository.existProductSourceInProductPackage(productSourceId);
	}

	@Override
	@Transactional
	public PageableResponse<ProductSourceResponseDto> getAllProductSource(String org, int pageNumber, int pageSize,
			String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
		Page<ProductSource> page = productSourceRepository.findProductSourceByOrganization(org, pageable);

		PageableResponse<ProductSourceResponseDto> response = new PageableResponse<>();

		try {
			if (!page.isEmpty()) {
				List<ProductSourceResponseDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, productSourceFetchErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in getAllProductSource Method present in ProductSourceServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private ProductSourceResponseDto entityToDto(ProductSource productSource) {

		ProductSourceResponseDto productSourceResponseDto = new ProductSourceResponseDto();

		productSourceResponseDto.setId(productSource.getId());
		productSourceResponseDto.setName(productSource.getName());
		productSourceResponseDto.setCode(productSource.getCode());

		Product product = productSource.getProduct();

		productSourceResponseDto.setProductName(product.getName());
		productSourceResponseDto.setProductCode(product.getCode());

		Location location = productSource.getLocation();

		productSourceResponseDto.setSupplierName(location.getName());
		productSourceResponseDto.setSupplierCode(location.getLocationNumber());

		Party party = productSource.getParty();

		productSourceResponseDto.setManufacturerName(party.getName());
		productSourceResponseDto.setManufacturerCode(party.getCode());

		productSourceResponseDto.setContractPrice(productSource.getContractPrice());

		productSourceResponseDto.setContractValidUntil(productSource.getContractValidUntil());

		productSourceResponseDto.setMinOrderQuantity(productSource.getMinOrderQuantity());

		productSourceResponseDto.setRatingType(productSource.getRatingType());

		productSourceResponseDto.setPreferenceType(productSource.getPreferenceType());

		productSourceResponseDto.setDescription(productSource.getDescription());
		productSourceResponseDto.setOrg(productSource.getOrg().getName());
		productSourceResponseDto.setCreatedDate(productSource.getCreatedDate());
		productSourceResponseDto.setUpdatedDate(productSource.getUpdatedDate());

		return productSourceResponseDto;
	}

}
