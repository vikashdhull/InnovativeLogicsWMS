package com.innovative.logics.wms.dto;

import java.util.Locale;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import jakarta.validation.Valid;
import lombok.Getter;
import lombok.Setter;
@JsonInclude(Include.NON_NULL)
@Getter
@Setter
public class UserDto {

	private String id;

	private String username;

	@JsonProperty(access = Access.WRITE_ONLY)
	private String password;

	private Boolean status= false;
	
	private String notes;
	
	private Locale locale;
	
	private Boolean isUser = false;

	private Set<RoleDto> role;
	
	@Valid
	private PersonDto person;
	
	private String party;

}