package com.innovative.logics.wms.service;

import java.security.Principal;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PaymentDetailsDto;
import com.innovative.logics.wms.dto.response.PaymentDetailsResponseDto;

public interface PaymentDetailsService {

	ApiResponse<PaymentDetailsResponseDto> createPaymentDetails(PaymentDetailsDto paymentDetailsDto, Principal principal);

	ApiResponse<PaymentDetailsResponseDto> updatePaymentDetails(PaymentDetailsDto paymentDetailsDto,
			String paymentDetailsId, Principal principal);

	ApiResponse<PaymentDetailsResponseDto> deletePaymentDetailsById(String paymentDetailsId);

	ApiResponse<PaymentDetailsResponseDto> getPaymentDetailsById(String paymentDetailsId);

	PageableResponse<PaymentDetailsResponseDto> getAllPaymentDetails(String org, int pageNumber, int pageSize,
			String sortBy, String sortDir);

}
