package com.innovative.logics.wms.util;

public final class Constants {

	private Constants() {
		super();
	}

	public static final String HEADER = "Authorization";
	public static final String PREFIX = "Bearer";
	
	public static final String RECEIVED = "RECEIVED";
	public static final String SHIPPED = "SHIPPED";
	public static final String PENDING = "PENDING";
	public static final String VERIFYING = "VERIFYING";
	public static final String PARTIALLY_SHIPPED = "PARTIALLY_SHIPPED";
	public static final String PARTIALLY_RECEIVED = "PARTIALLY_RECEIVED";
	public static final String CANCEL = "CANCEL";
	
	public static final String STATUS = "status";
	public static final String ERROR = "error";
	public static final String MESSAGE = "message";
	public static final String PATH = "path";
	public static final String PURCHASING_ORDER = "PURCHASING_ORDER";
	
	public static final int MAX_SIZE = 10000000;
	
	public static final String ORG_LOGO_PATH = "src/main/resources/static/logo/";

}
