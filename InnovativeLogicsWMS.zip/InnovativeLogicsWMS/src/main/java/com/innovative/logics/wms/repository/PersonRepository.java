package com.innovative.logics.wms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.innovative.logics.wms.entity.Person;

public interface PersonRepository extends JpaRepository<Person, String> {
	
	Person findByEmail(String email);
	
	Person findByPhoneNumber(String phone);
	
	List<Person> findByFirstNameContaining(String keyword);

}