package com.innovative.logics.wms.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PartyTypeDto;
import com.innovative.logics.wms.entity.PartyType;
import com.innovative.logics.wms.repository.PartyRepository;
import com.innovative.logics.wms.repository.PartyTypeRepository;
import com.innovative.logics.wms.service.PartyTypeService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PartyTypeServiceImpl implements PartyTypeService {

	@Autowired
	private Environment env;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private PartyTypeRepository partyTypeRepository;

	@Autowired
	private PartyRepository partyRepository;

	@Autowired
	private Utility utility;

	private String partyTypeFetchError = "party.type.fetch.error.message";

	@Override
	public ApiResponse<PartyTypeDto> createPartyType(PartyTypeDto partyTypeDto) {

		Optional<PartyType> existPartyTypeByName = partyTypeRepository.findByName(partyTypeDto.getName());

		Optional<PartyType> existByCode = partyTypeRepository.findByCode(partyTypeDto.getCode());

		ApiResponse<PartyTypeDto> response = new ApiResponse<>();

		try {
			if (existPartyTypeByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "party.type.name.error.message");
			}

			if (existByCode.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "party.type.code.error.message");
			}

			PartyType partyType = modelMapper.map(partyTypeDto, PartyType.class);
			PartyType savedPartyType = partyTypeRepository.save(partyType);
			PartyTypeDto newDto = modelMapper.map(savedPartyType, PartyTypeDto.class);

			response.setData(newDto);
			response.setResult(true);
			response.setMessage(env.getProperty("party.type.create.success.message"));
			response.setStatus(HttpStatus.CREATED.value());
			return response;

		} catch (Exception e) {
			log.error("Exception in create partyType operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<PartyTypeDto> updatePartyType(PartyTypeDto partyTypeDto, String partyId) {
		ApiResponse<PartyTypeDto> response = new ApiResponse<>();

		Optional<PartyType> partyType = partyTypeRepository.findById(partyId);
		Optional<PartyType> existByName = partyTypeRepository.findByName(partyTypeDto.getName());
		Optional<PartyType> existByCode = partyTypeRepository.findByCode(partyTypeDto.getCode());

		try {
			if (partyType.isPresent()) {
				PartyType partyTypeData = partyType.get();

				if (existByName.isPresent() && !Objects.equals(partyTypeData.getName(), partyTypeDto.getName())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "party.type.name.error.message");

				} else {
					partyTypeData.setName(partyTypeDto.getName());
				}
				if (existByCode.isPresent() && !Objects.equals(partyTypeData.getCode(), partyTypeDto.getCode())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "party.type.code.error.message");
				} else {

					partyTypeData.setCode(partyTypeDto.getCode());
				}

				partyTypeData.setDescription(partyTypeDto.getDescription());

				PartyType updatedPartyType = partyTypeRepository.save(partyTypeData);
				PartyTypeDto updatedDto = modelMapper.map(updatedPartyType, PartyTypeDto.class);

				response.setData(updatedDto);
				response.setResult(true);
				response.setMessage(env.getProperty("party.type.update.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "party.type.not.found.message");
			}
		} catch (Exception e) {
			log.error("Exception in update PartyType operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<PartyTypeDto> deletePartyTypeById(String partyTypeId) {
		ApiResponse<PartyTypeDto> response = new ApiResponse<>();
		try {

			Optional<PartyType> partyTypeDetails = partyTypeRepository.findById(partyTypeId);

			if (partyTypeDetails.isPresent()) {
				boolean partyTypeInUse = checkIfPartyTypeInUse(partyTypeId);
				if (partyTypeInUse) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "party.type.use.error.message");
				}
				partyTypeRepository.deleteById(partyTypeId);
				response.setMessage(env.getProperty("party.type.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "party.type.not.found.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deletePartyType Method present in PartyTypeServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private boolean checkIfPartyTypeInUse(String partyTypeId) {
		return partyRepository.existByPartyType(partyTypeId);
	}

	@Override
	public ApiResponse<PartyTypeDto> getPartyTypeById(String partyTypeId) {
		ApiResponse<PartyTypeDto> response = new ApiResponse<>();
		try {
			Optional<PartyType> partyType = partyTypeRepository.findById(partyTypeId);

			if (partyType.isPresent()) {
				response.setMessage(env.getProperty("party.type.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(modelMapper.map(partyType.get(), PartyTypeDto.class));
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, partyTypeFetchError);
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getPartyTypeById Method present in PartyTypeServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public PageableResponse<PartyTypeDto> getAllPartyType(int pageNumber, int pageSize, String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<PartyType> page = partyTypeRepository.findAll(pageable);

		PageableResponse<PartyTypeDto> response = utility.getPageableResponse(page, PartyTypeDto.class);
		try {
			if (!response.getData().isEmpty()) {

				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, partyTypeFetchError);
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getAllPartyType Method present in PartyTypeServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public PageableResponse<PartyTypeDto> searchPartyType(String keyword, int pageNumber, int pageSize, String sortBy,
			String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<PartyType> partyType = partyTypeRepository.findByNameContaining(keyword, pageable);

		PageableResponse<PartyTypeDto> response = utility.getPageableResponse(partyType, PartyTypeDto.class);
		try {
			if (!response.getData().isEmpty()) {

				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, partyTypeFetchError);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in searchPartyType Method present in PartyTypeServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<List<PartyTypeDto>> getPartyTypes() {
		ApiResponse<List<PartyTypeDto>> response = new ApiResponse<>();

		try {
			List<PartyType> partyTypes = partyTypeRepository.findAll();
			List<PartyTypeDto> partyTypeDtos = partyTypes.stream()
					.map(party -> modelMapper.map(party, PartyTypeDto.class)).toList();

			if (!partyTypes.isEmpty()) {
				response.setMessage(env.getProperty("party.type.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(partyTypeDtos);
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, partyTypeFetchError);
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getPartyTypes Method present in PartyTypeServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

}
