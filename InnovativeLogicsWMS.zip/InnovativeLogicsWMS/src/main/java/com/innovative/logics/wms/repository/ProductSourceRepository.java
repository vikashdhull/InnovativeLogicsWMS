package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.innovative.logics.wms.entity.ProductSource;

public interface ProductSourceRepository extends JpaRepository<ProductSource, String> {

	final String PRODUCT_SOURCE_BY_PRODUCT_NAME = "SELECT ps.* FROM product_source ps JOIN product p ON ps.product_id = p.id WHERE p.name = :productName";

	final String EXIST_LOCATION_IN_PRODUCT_SOURCE = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product_source ps WHERE ps.supplier_id = :supplierId";

	final String EXIST_PRODUCT_IN_PRODUCT_SOURCE = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product_source ps WHERE ps.product_id = :productId";

	final String EXIST_PARTY_IN_PRODUCT_SOURCE = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product_source ps WHERE ps.manufacturer_id = :manufacturerId";
	
	final String PRODUCTS_SOURCE_BY_ORGANIZATION = "SELECT ps.* FROM product_source ps JOIN party p ON p.id = ps.organization_id WHERE p.name =:name";

	Optional<ProductSource> findByName(String name);

	Optional<ProductSource> findByCode(String code);

	@Query(value = PRODUCT_SOURCE_BY_PRODUCT_NAME, nativeQuery = true)
	List<ProductSource> findProductSourcsByProductName(String productName);

	@Query(value = EXIST_PRODUCT_IN_PRODUCT_SOURCE, nativeQuery = true)
	boolean existProductInProductSource(String productId);

	@Query(value = EXIST_LOCATION_IN_PRODUCT_SOURCE, nativeQuery = true)
	boolean existSuplierInProductSource(String supplierId);

	@Query(value = EXIST_PARTY_IN_PRODUCT_SOURCE, nativeQuery = true)
	boolean existPartyInProductSource(String manufacturerId);

	@Query(value = PRODUCTS_SOURCE_BY_ORGANIZATION, nativeQuery = true)
	Page<ProductSource> findProductSourceByOrganization(@Param("name") String name, Pageable pageable);
}
