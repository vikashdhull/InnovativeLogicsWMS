package com.innovative.logics.wms.service.impl;

import java.security.Principal;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PaymentDetailsDto;
import com.innovative.logics.wms.dto.response.PaymentDetailsResponseDto;
import com.innovative.logics.wms.entity.Party;
import com.innovative.logics.wms.entity.PaymentDetails;
import com.innovative.logics.wms.entity.User;
import com.innovative.logics.wms.repository.PartyRepository;
import com.innovative.logics.wms.repository.PaymentDetailsRepository;
import com.innovative.logics.wms.repository.UserRepository;
import com.innovative.logics.wms.service.PaymentDetailsService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PaymentDetailsServiceImpl implements PaymentDetailsService {

	@Autowired
	private PaymentDetailsRepository paymentDetailsRepository;

	@Autowired
	private Environment env;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Utility utility;

	@Autowired
	private PartyRepository partyRepository;

	@Autowired
	private UserRepository userRepository;
	
	private String paymentDetailsErrorMessage = "payment.details.fetch.error.message";

	@Override
	@Transactional(propagation = Propagation.SUPPORTS)
	public ApiResponse<PaymentDetailsResponseDto> createPaymentDetails(PaymentDetailsDto paymentDetailsDto,
			Principal principal) {
		ApiResponse<PaymentDetailsResponseDto> response = new ApiResponse<>();

		try {
			Optional<PaymentDetails> findPaymentDetailsByAccountNumber = paymentDetailsRepository
					.findByAccountNumber(paymentDetailsDto.getAccountNumber());

			Optional<PaymentDetails> findByPhoneNumber = paymentDetailsRepository
					.findByPhoneNumber(paymentDetailsDto.getPhoneNumber());
			Optional<PaymentDetails> findByEmail = paymentDetailsRepository.findByEmail(paymentDetailsDto.getEmail());

			Optional<Party> findOrgByName = partyRepository.findByName(paymentDetailsDto.getParty());

			if (findPaymentDetailsByAccountNumber.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "account.number.error.message");
			}
			if (findByPhoneNumber.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "user.phone.create.error.message");
			}

			if (findByEmail.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "user.email.create.error.message");
			}

			Optional<User> findByUsername = userRepository.findByUsername(principal.getName());

			PaymentDetails paymentDetails = modelMapper.map(paymentDetailsDto, PaymentDetails.class);

			if (findByUsername.isEmpty()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "userdetails.delete.error.message");
			}

			paymentDetails.setCreatedBy(findByUsername.get());

			if (findOrgByName.isPresent()) {
				paymentDetails.setParty(findOrgByName.get());
			}

			PaymentDetails savedPaymentDetails = paymentDetailsRepository.save(paymentDetails);

			PaymentDetailsResponseDto paymentDetailsResponseDto = entityToDto(savedPaymentDetails);

			response.setData(paymentDetailsResponseDto);
			response.setResult(true);
			response.setMessage(env.getProperty("payment.save.success.message"));
			response.setStatus(HttpStatus.OK.value());
			return response;
		} catch (Exception exp) {
			log.error(
					"Exception Occurred in createPaymentDetails Method present in PaymentDetailsServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<PaymentDetailsResponseDto> updatePaymentDetails(PaymentDetailsDto paymentDetailsDto,
			String paymentDetailsId, Principal principal) {
		ApiResponse<PaymentDetailsResponseDto> response = new ApiResponse<>();
		try {

			Optional<PaymentDetails> findById = paymentDetailsRepository.findById(paymentDetailsId);
			if (findById.isPresent()) {
				PaymentDetails paymentDetails = findById.get();

				paymentDetails.setFirstName(paymentDetailsDto.getFirstName());
				paymentDetails.setLastName(paymentDetailsDto.getLastName());
				paymentDetails.setDescription(paymentDetailsDto.getDescription());

				Optional<PaymentDetails> findByAccountNumber = paymentDetailsRepository
						.findByAccountNumber(paymentDetailsDto.getAccountNumber());

				Optional<PaymentDetails> findByPhoneNumber = paymentDetailsRepository
						.findByPhoneNumber(paymentDetailsDto.getPhoneNumber());
				Optional<PaymentDetails> findByEmail = paymentDetailsRepository
						.findByEmail(paymentDetailsDto.getEmail());

				Optional<User> findByUsername = userRepository.findByUsername(principal.getName());

				if (findByAccountNumber.isPresent()
						&& !Objects.equals(paymentDetails.getAccountNumber(), paymentDetailsDto.getAccountNumber())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "account.number.error.message");

				}
				paymentDetails.setAccountNumber(paymentDetailsDto.getAccountNumber());

				if (findByEmail.isPresent()
						&& !Objects.equals(paymentDetails.getEmail(), paymentDetailsDto.getEmail())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "user.email.create.error.message");
				}

				paymentDetails.setEmail(paymentDetailsDto.getEmail());

				if (findByPhoneNumber.isPresent()
						&& !Objects.equals(paymentDetails.getPhoneNumber(), paymentDetailsDto.getPhoneNumber())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "user.phone.create.error.message");
				}
				paymentDetails.setPhoneNumber(paymentDetailsDto.getPhoneNumber());

				if (findByUsername.isEmpty()) {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, "userdetails.delete.error.message");
				}

				paymentDetails.setUpdatedBy(findByUsername.get());
				PaymentDetails savedPaymentDetails = paymentDetailsRepository.save(paymentDetails);

				PaymentDetailsResponseDto updatedDto = entityToDto(savedPaymentDetails);
				response.setData(updatedDto);
				response.setResult(true);
				response.setMessage(env.getProperty("payment.details.update.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, paymentDetailsErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception in updatePaymentDetails Method present in PaymentDetailsServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<PaymentDetailsResponseDto> deletePaymentDetailsById(String paymentDetailsId) {
		ApiResponse<PaymentDetailsResponseDto> response = new ApiResponse<>();
		try {

			Optional<PaymentDetails> findById = paymentDetailsRepository.findById(paymentDetailsId);

			if (findById.isPresent()) {
				paymentDetailsRepository.deleteById(paymentDetailsId);
				response.setMessage(env.getProperty("payment.details.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, paymentDetailsErrorMessage);
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occured in deletePaymentDetailsById Method present in PaymentDetailsServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<PaymentDetailsResponseDto> getPaymentDetailsById(String paymentDetailsId) {
		ApiResponse<PaymentDetailsResponseDto> response = new ApiResponse<>();
		try {
			Optional<PaymentDetails> findById = paymentDetailsRepository.findById(paymentDetailsId);

			if (findById.isPresent()) {
				modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE);
				PaymentDetailsResponseDto paymentDetailsResponseDto = entityToDto(findById.get());
				response.setMessage(env.getProperty("payment.details.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(paymentDetailsResponseDto);
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, paymentDetailsErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getPaymentDetailsById Method present in PaymentDetailsServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public PageableResponse<PaymentDetailsResponseDto> getAllPaymentDetails(String org, int pageNumber, int pageSize,
			String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
		Page<PaymentDetails> page = paymentDetailsRepository.findPaymentDetailsByParty(org, pageable);

		PageableResponse<PaymentDetailsResponseDto> response = new PageableResponse<>();

		try {
			if (!page.isEmpty()) {

				List<PaymentDetailsResponseDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND,
						paymentDetailsErrorMessage);
			}
		} catch (Exception exp) {
			log.error(
					"Exception Occurred in getAllPaymentDetails Method present in PaymentDetailsServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private PaymentDetailsResponseDto entityToDto(PaymentDetails paymentDetails) {

		PaymentDetailsResponseDto paymentDetailsResponseDto = new PaymentDetailsResponseDto();
		paymentDetailsResponseDto.setId(paymentDetails.getId());
		paymentDetailsResponseDto.setFirstName(paymentDetails.getFirstName());
		paymentDetailsResponseDto.setLastName(paymentDetails.getLastName());
		paymentDetailsResponseDto.setEmail(paymentDetails.getEmail());
		paymentDetailsResponseDto.setPhoneNumber(paymentDetails.getPhoneNumber());
		paymentDetailsResponseDto.setAccountNumber(paymentDetails.getAccountNumber());
		paymentDetailsResponseDto.setDescription(paymentDetails.getDescription());
		paymentDetailsResponseDto.setParty(paymentDetails.getParty().getName());
		paymentDetailsResponseDto.setCreatedBy(paymentDetails.getCreatedBy().getUsername());

		User updatedBy = paymentDetails.getUpdatedBy();

		if (updatedBy == null) {
			paymentDetailsResponseDto.setUpdatedBy(null);
		} else {
			paymentDetailsResponseDto.setUpdatedBy(updatedBy.getUsername());
		}

		paymentDetailsResponseDto.setCreatedDate(paymentDetails.getCreatedDate());
		paymentDetailsResponseDto.setUpdatedDate(paymentDetails.getUpdatedDate());

		return paymentDetailsResponseDto;
	}

}
