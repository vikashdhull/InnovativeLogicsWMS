package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductSourceDto;
import com.innovative.logics.wms.dto.response.ProductSourceResponseDto;

public interface ProductSourceService {

	/**
	 * 
	 * This method is used to create the ProductSource based on given details
	 * 
	 * @author manus
	 * @date 05-Sep-2023
	 * @param productSourceDto
	 * @return
	 */
	ApiResponse<ProductSourceResponseDto> createProductSource(ProductSourceDto productSourceDto);

	ApiResponse<ProductSourceResponseDto> updateProductSource(ProductSourceDto productSourceDto, String productSourceId);

	ApiResponse<ProductSourceResponseDto> getProductSourceById(String productSourceId);

	/**
	 * 
	 * This method is used to fetch all the ProductSource by product name with
	 * Pagination and Sorting
	 * 
	 * @author manus
	 * @date 08-Sep-2023
	 * @param productName
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	ApiResponse<List<ProductSourceResponseDto>> getProductSourcesByProductname(String productName);

	ApiResponse<ProductSourceResponseDto> deleteProductSourceById(String productSourceId);

	PageableResponse<ProductSourceResponseDto> getAllProductSource(String org, int pageNumber, int pageSize, String sortBy, String sortDir);

}
