package com.innovative.logics.wms.dto;

public class PaginationData {

	int pageNumber;
	int pageSize;
	String sortBy;
	String sortDir;

}
