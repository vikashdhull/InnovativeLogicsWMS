package com.innovative.logics.wms.entity;

import java.io.Serializable;

import org.hibernate.annotations.UuidGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "role", uniqueConstraints = { @UniqueConstraint(columnNames = { "role_name" }) })
public class Role implements Serializable {

	/** long Short Description */
	private static final long serialVersionUID = 1L;
	
	@Column(name = "id")
	@Id
	@UuidGenerator
	private String id;
	
	@Column(name = "role_name", length = 100)
	@NotNull(message = "Role name should not be null")
	private String roleName;
	
	@Column(name = "description", length = 150)
	private String description;
	
	@JsonIgnore
	@Column(name = "role_code", length = 50)
	private String roleCode;

}
