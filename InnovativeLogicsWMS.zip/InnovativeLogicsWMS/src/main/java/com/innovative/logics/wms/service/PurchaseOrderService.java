package com.innovative.logics.wms.service;

import java.security.Principal;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.OrderDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.PurchaseOrderResponseDto;

public interface PurchaseOrderService {

	/**
	 * 
	 * The createPurchaseOrder method is used to create the purchase order based on
	 * given details.
	 * 
	 * @author manus
	 * @date 05-Dec-2023
	 * @param orderDto
	 * @return ResponseEntity containing an ApiResponse with the
	 *         PurchaseIOrderResponseDto
	 */
	ApiResponse<PurchaseOrderResponseDto> createPurchaseOrder(OrderDto orderDto, Principal principal);

	/**
	 * 
	 * The getPurchaseOrderById method is used to get the purchase order based on
	 * given orderId.
	 * 
	 * @author manus
	 * @date 07-Dec-2023
	 * @param id
	 * @return ResponseEntity containing an ApiResponse with the
	 *         PurchaseOrderResponseDto
	 */
	ApiResponse<PurchaseOrderResponseDto> getPurchaseOrderById(String orderId);

	/**
	 * 
	 * The getAllPurchaseOrderByDestination method is used to get the all purchase
	 * order page wise based on given destination and page.
	 * 
	 * @author manus
	 * @date 09-Dec-2023
	 * @param destination
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return ResponseEntity containing an PageableResponse with the
	 *         PurchaseOrderResponseDto
	 */
	PageableResponse<PurchaseOrderResponseDto> getAllPurchaseOrderByDestination(String destinationName, int pageNumber,
			int pageSize, String sortBy, String sortDir);

	/**
	 * 
	 * The getAllReceivedPurchaseOrderByDestination method is used to get the all
	 * purchase order page wise based on given destination and page.
	 * 
	 * @author manus
	 * @date 12-Dec-2023
	 * @param destination
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return ResponseEntity containing an PageableResponse with the
	 *         PurchaseOrderResponseDto
	 */
	PageableResponse<PurchaseOrderResponseDto> getAllReceivedPurchaseOrderByDestination(String destinationName,
			int pageNumber, int pageSize, String sortBy, String sortDir);

}
