package com.innovative.logics.wms.entity;

import java.time.LocalDate;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "orders")
@Getter
@Setter
public class Order {
	
	@Column(name = "id")
	@Id
	@UuidGenerator
	private String id;
	
	@Column(name = "order_type")
	private String orderType;

	@Column(name = "name", length = 100)
	private String name;

	@Column(name = "description", length = 150)
	private String description;

	@Column(name = "order_number")
	private String orderNumber;
	
	@Column(name = "status")
	private String status;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "origin", referencedColumnName = "id")
	private Location origin;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "origin_party", referencedColumnName = "id")
	private Party originParty;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "destination", referencedColumnName = "id")
	private Location destination;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "destination_party", referencedColumnName = "id")
	private Party destinationParty;

	//CascadeType.ALL should be useful
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "approved_by", referencedColumnName = "id")
	private User approvedBy;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "ordered_by", referencedColumnName = "id")
	private User orderedBy;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "completed_by", referencedColumnName = "id")
	private User completedBy;

	@Column(name = "date_approved")
	private LocalDate dateApproved;

	@CreationTimestamp
	@Column(name = "date_ordered", nullable = false, updatable = false)
	private LocalDate dateOrdered;

	@Column(name = "date_completed")
	private LocalDate dateCompleted;

	@Column(name = "payment_method_type")
	private String paymentMethodType;

	@Column(name = "payment_term")
	private String paymentTerm;

}
