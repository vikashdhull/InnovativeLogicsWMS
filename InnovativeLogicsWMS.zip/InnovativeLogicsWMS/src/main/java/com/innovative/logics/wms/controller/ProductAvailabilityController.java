package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.InventorySummary;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductAvailabilityDto;
import com.innovative.logics.wms.dto.response.InStockReportResponseDto;
import com.innovative.logics.wms.dto.response.ProductAvailabilityResponseDto;
import com.innovative.logics.wms.service.ProductAvailabilityService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/products-availability")
@Slf4j
public class ProductAvailabilityController {

	@Autowired
	private ProductAvailabilityService productAvailabilityService;

	/**
	 * 
	 * Add method description here
	 * 
	 * @author manus
	 * @date 12-Sep-2023
	 * @param productAvailabilityDto
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<ProductAvailabilityResponseDto>> createProductAvailability(
			@Valid @RequestBody final ProductAvailabilityDto productAvailabilityDto) {
		log.info("Enter in createProductAvailability Method present in ProductAvailabilityController class");
		ApiResponse<ProductAvailabilityResponseDto> response = productAvailabilityService
				.createProductAvailability(productAvailabilityDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * Add method description here
	 * 
	 * @author manus
	 * @date 14-Sep-2023
	 * @param locationName
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/location/{locationName}")
	public ResponseEntity<PageableResponse<InventorySummary>> getProductSummariesByLocation(
			@PathVariable("locationName") final String locationName,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "productName", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getProductSummariesByLocation Method present in ProductAvailabilityController class");

		PageableResponse<InventorySummary> response = productAvailabilityService
				.getProductSummariesByLocation(locationName, pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/lot/location/{locationName}")
	public ResponseEntity<PageableResponse<ProductAvailabilityResponseDto>> getAllProductAvailablityByLocationAndLot(
			@PathVariable("locationName") final String locationName,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "product", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info(
				"Enter in getAllProductAvailablityByLocationAndLot Method present in ProductAvailabilityController class");

		PageableResponse<ProductAvailabilityResponseDto> response = productAvailabilityService
				.getAllProductAvailablityByLocationAndLot(locationName, pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The getproductAvailabilityByLocationAndProduct method is used to get all the
	 * lot of Product by Location and Product Name
	 * 
	 * @author manus
	 * @date 25-Sep-2023
	 * @param location
	 * @param product
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<ApiResponse<List<ProductAvailabilityResponseDto>>> getproductAvailabilityByLocationAndProduct(
			@RequestParam(value = "location", required = true) String location,
			@RequestParam(value = "product", required = true) String product) {
		log.info("Enter in getproductAvailabilityByLocationAndProduct Method present in ProductSourceController class");

		ApiResponse<List<ProductAvailabilityResponseDto>> response = productAvailabilityService
				.getproductAvailabilityByLocationAndProduct(location, product);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@GetMapping("/in-stock-report")
	public ResponseEntity<ApiResponse<List<InStockReportResponseDto>>> getStockReport(
			@RequestParam(value = "locationName", required = true) String locationName) {
		ApiResponse<List<InStockReportResponseDto>> response = productAvailabilityService
				.getInStockReport(locationName);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
