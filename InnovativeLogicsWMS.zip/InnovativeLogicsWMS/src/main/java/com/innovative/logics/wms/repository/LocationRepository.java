package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.innovative.logics.wms.dto.response.NumberOfQuantity;
import com.innovative.logics.wms.entity.Location;

public interface LocationRepository extends JpaRepository<Location, String> {

	final String DEPOT_LOCATION_BY_ORGANIZATION = "SELECT l.* FROM location l INNER JOIN party p ON p.id = l.organization_id INNER JOIN location_role lr ON l.id = lr.location INNER JOIN role r ON lr.role = r.id WHERE  r.role_name = 'ROLE_DEPOT' AND p.NAME =:name";

	final String EXIST_ROLE = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM location_role lr WHERE lr.role = :roleId";

	final String EXIST_LOCATION = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM location l WHERE l.parent_location_id = :parentLocationId";

	final String EXIST_PARTY = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM location l WHERE l.organization_id = :organizationId";

	final String EXIST_LOCATION_GROUP = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM location l WHERE l.location_group_id = :locationGroupId";

	final String EXIST_LOCATION_BY_NAME = "SELECT CASE WHEN EXISTS (SELECT 1 FROM location l JOIN location_role lr ON l.id = lr.location JOIN role r ON lr.role = r.id WHERE r.role_name = 'ROLE_SUPPLIER' AND l.name = :locationName) THEN 'true' ELSE 'false' END AS result";

	final String LOCATION_BY_ROLE = "SELECT l.* FROM location l JOIN location_role lr ON l.id = lr.location JOIN role r ON lr.role = r.id WHERE r.role_name = :roleName";

	final String NUMBER_OF_SUPPLIER = "SELECT COUNT(*) AS numberOfCount FROM location l JOIN location_role lr ON l.id = lr.location JOIN role r ON lr.role = r.id LEFT JOIN party p ON l.organization_id = p.id WHERE r.role_name = 'ROLE_SUPPLIER' AND p.name =:org";

	final String EXIST_ORIGIN_LOCATION_INBOUND = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM inbound i WHERE i.origin_id = :originId";

	final String EXIST_ORIGIN_LOCATION_OUTBOUND = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM outbound_delivery od WHERE od.origin_id = :originId";

	final String EXIST_DESTINATION_LOCATION_INBOUND = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM inbound i WHERE i.destination_id = :destinationId";

	final String EXIST_DESTINATION_LOCATION_OUTBOUND = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM outbound_delivery od WHERE od.destination_id = :destinationId";

	Optional<Location> findByName(String name);

	Optional<Location> findByLocationNumber(String locationNumber);

	@Query(value = "SELECT loc FROM Location loc WHERE loc.party.name =:name")
	Page<Location> findLocationByOrganization(String name, Pageable pageable);

	@Query(value = DEPOT_LOCATION_BY_ORGANIZATION, nativeQuery = true)
	List<Location> findDepotLocationByOrganization(@Param("name") String name);

	Page<Location> findByNameContaining(String keywords, Pageable pageable);

	@Query(value = EXIST_ROLE, nativeQuery = true)
	boolean existByRoleId(String roleId);

	@Query(value = EXIST_LOCATION, nativeQuery = true)
	boolean existByParentLocation(String parentLocationId);

	@Query(value = EXIST_PARTY, nativeQuery = true)
	boolean existByOrganizationId(String organizationId);

	@Query(value = EXIST_LOCATION_GROUP, nativeQuery = true)
	boolean existByLocationGroup(String locationGroupId);

	@Query(value = EXIST_LOCATION_BY_NAME, nativeQuery = true)
	boolean existLocationByName(String locationName);

	@Query(value = LOCATION_BY_ROLE, nativeQuery = true)
	List<Location> findLocationByRoleAndName(String roleName);

	@Query(value = NUMBER_OF_SUPPLIER, nativeQuery = true)
	NumberOfQuantity getSupplierCount(String org);

	@Query(value = EXIST_ORIGIN_LOCATION_INBOUND, nativeQuery = true)
	boolean existOriginLocationInInbound(String originId);

	@Query(value = EXIST_ORIGIN_LOCATION_OUTBOUND, nativeQuery = true)
	boolean existOriginLocationInOutbound(String originId);

	@Query(value = EXIST_DESTINATION_LOCATION_INBOUND, nativeQuery = true)
	boolean existDestinationLocationInInbound(String destinationId);

	@Query(value = EXIST_DESTINATION_LOCATION_OUTBOUND, nativeQuery = true)
	boolean existDestinationLocationInOutbound(String destinationId);

}
