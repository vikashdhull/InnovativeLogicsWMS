package com.innovative.logics.wms.dto;

import java.time.LocalDateTime;

import java.util.List;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AttributeDto {

	private String id;
	
	@NotNull(message = "Name should not be null")
	private String name;

	private String description;

	private List<AttributeOptionDto> option;
	
	private String party;
	
	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
