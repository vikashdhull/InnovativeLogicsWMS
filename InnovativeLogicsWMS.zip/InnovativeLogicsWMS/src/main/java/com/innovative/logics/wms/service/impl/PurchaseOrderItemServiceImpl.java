package com.innovative.logics.wms.service.impl;

import java.security.Principal;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.OrderItemDto;
import com.innovative.logics.wms.dto.ProductAvailabilityDto;
import com.innovative.logics.wms.dto.response.PurchaseOrderItemResponseDto;
import com.innovative.logics.wms.dto.response.PurchaseOrderResponseDto;
import com.innovative.logics.wms.entity.InventoryItem;
import com.innovative.logics.wms.entity.Order;
import com.innovative.logics.wms.entity.OrderItem;
import com.innovative.logics.wms.entity.Product;
import com.innovative.logics.wms.entity.ProductAvailability;
import com.innovative.logics.wms.entity.ProductSource;
import com.innovative.logics.wms.entity.User;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.repository.InventoryItemRepository;
import com.innovative.logics.wms.repository.OrderItemRepository;
import com.innovative.logics.wms.repository.OrderRepository;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.repository.ProductSourceRepository;
import com.innovative.logics.wms.repository.UserRepository;
import com.innovative.logics.wms.service.ProductAvailabilityService;
import com.innovative.logics.wms.service.PurchaseOrderItemService;
import com.innovative.logics.wms.util.Constants;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PurchaseOrderItemServiceImpl implements PurchaseOrderItemService {

	@Autowired
	private OrderItemRepository orderItemRepository;

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ProductSourceRepository productSourceRepository;

	@Autowired
	private InventoryItemRepository inventoryItemRepository;

	@Autowired
	private ProductAvailabilityService productAvailabilityService;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;
	
	private String orderFetchError = "order.fetch.error.message";

	// to save multiple items into order
	@Override
	public ApiResponse<PurchaseOrderResponseDto> createPurchaseOrderWithItems(String orderId,
			List<OrderItemDto> orderItemDtoList, Principal principal) {

		ApiResponse<PurchaseOrderResponseDto> response = new ApiResponse<>();

		List<String> productName = orderItemDtoList.stream().map(OrderItemDto::getProduct).toList();

		// check for duplicate products
		boolean result = productName.stream().map(String::toUpperCase).distinct().count() < productName.size();

		if (result) {
			return utility.errorResponse(response, HttpStatus.EXPECTATION_FAILED,
					"order.duplicate.product.error.message");
		}

		try {

			Optional<Order> findOrderById = orderRepository.findById(orderId);

			if (!findOrderById.isPresent()) {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND, orderFetchError);
			}

			Order order = findOrderById.get();

			if (Constants.SHIPPED.equals(order.getStatus())) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "purchase.order.shipment.error.message");
			}

			Optional<User> findRequestedByUsername = userRepository.findByUsername(principal.getName());

			List<OrderItem> orderItemList = new ArrayList<>();

			orderItemDtoList.stream().forEach(o -> {

				Optional<Product> findByProductName = productRepository.findByName(o.getProduct());

				checkShipmentAndDeliveyDates(o);

				OrderItem orderItem = modelMapper.map(o, OrderItem.class);

				orderItem.setOrder(order);

				if (!findByProductName.isPresent()) {

					throw new BadApiRequestException(env.getProperty("product.fetch.error.message"));

				}
				orderItem.setProduct(findByProductName.get());

				Optional<ProductSource> findProductSourceByName = o.getProductSource() != null
						? productSourceRepository.findByName(o.getProductSource())
						: null;
				ProductSource source = findProductSourceByName.isPresent() ? findProductSourceByName.get() : null;

				orderItem.setProductSource(source);

				if (findRequestedByUsername.isPresent()) {
					User user = findRequestedByUsername.get();
					orderItem.setRequestedBy(user);
					order.setApprovedBy(user);
				}

				orderItem.setLot(utility.generateUniqueNumber());
				orderItemList.add(orderItem);
				order.setDateApproved(orderItem.getShipmentDate());
			});

			List<OrderItem> savedList = orderItemRepository.saveAll(orderItemList);

			order.setStatus(Constants.SHIPPED);

			orderRepository.save(order);

			PurchaseOrderResponseDto orderItemResponseDto = entityToDto(savedList, order);

			response.setData(orderItemResponseDto);
			response.setMessage(env.getProperty("purchase.order.shipped.success.message"));
			response.setResult(true);
			response.setStatus(HttpStatus.CREATED.value());
			return response;
		} catch (Exception exp) {
			log.error(
					"Exception Occurred in createOrderItemWithMultipleItems Method present in OrderItemServiceImpl class :{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());

			return response;
		}
	}

	// to receive order
	@Override
	public ApiResponse<PurchaseOrderResponseDto> receivedPurchaseOrderItems(Principal principal, Order order) {
		ApiResponse<PurchaseOrderResponseDto> response = new ApiResponse<>();

		if (!Constants.SHIPPED.equals(order.getStatus()) && Constants.PENDING.equals(order.getStatus())) {
			return utility.errorResponse(response, HttpStatus.NOT_FOUND, "purchase.order.shipped.error.message");
		}

		if (Constants.RECEIVED.equals(order.getStatus())) {
			return utility.errorResponse(response, HttpStatus.NOT_FOUND, "purchase.order.receive.error.message");
		}

		List<OrderItem> orderItems = orderItemRepository.findPurchaseOrderByOrderId(order.getId());

		if (!orderItems.isEmpty()) {

			for (OrderItem orderItem : orderItems) {

				String lot = orderItem.getLot();

				Optional<InventoryItem> findByLotNumber = inventoryItemRepository.findByLotNumber(lot);

				if (findByLotNumber.isPresent()) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "lot.number.error.message");
				}
			}

			Optional<User> findCompletedByUsername = userRepository.findByUsername(principal.getName());

			if (findCompletedByUsername.isPresent()) {
				order.setCompletedBy(findCompletedByUsername.get());
				order.setDateCompleted(LocalDate.now());
				order.setStatus(Constants.RECEIVED);
				orderRepository.save(order);
			}

			List<OrderItem> savedOrderItem = orderItemRepository.saveAll(orderItems);

			savedOrderItem.forEach(this::addProductQuantity);

			PurchaseOrderResponseDto purchaseOrderResponseDto = entityToDto(savedOrderItem, order);

			response.setData(purchaseOrderResponseDto);
			response.setMessage(env.getProperty("purchase.order.receive.success.message"));
			response.setResult(true);
			response.setStatus(HttpStatus.CREATED.value());
			return response;
		}
		log.info("Order item not present into order item repository");
		return utility.errorResponse(response, HttpStatus.NOT_FOUND, "order.item.fetch.error.message");
	}

	// new to fetch list of orderlist
		@Override
		public ApiResponse<List<PurchaseOrderItemResponseDto>> getPurchaseOrderItemsByOrderId(String orderId) {
			ApiResponse<List<PurchaseOrderItemResponseDto>> response = new ApiResponse<>();

			try {
				List<OrderItem> findOrderItemsByOrder = orderItemRepository.findPurchaseOrderByOrderId(orderId);

				if (findOrderItemsByOrder.isEmpty()) {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, "purchase.order.fetch.error.message");
				}

				List<OrderItem> orderItems = findOrderItemsByOrder;

				List<PurchaseOrderItemResponseDto> result = entityToDto(orderItems);

				response.setMessage(env.getProperty("purchase.order.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(result);

				return response;

			} catch (Exception e) {
				log.error(
						"Exception Occurred in getPurchaseOrderItemByOrder Method present in OrderItemServiceImpl class: {}",
						e.getMessage());
				response.setMessage(e.getMessage());
				response.setResult(false);
				response.setStatus(HttpStatus.BAD_REQUEST.value());
				return response;
			}

		}

	
	public void checkShipmentAndDeliveyDates(OrderItemDto o) {

		if (o.getShipmentDate().isBefore(LocalDate.now())) {

			throw new BadApiRequestException(env.getProperty("shipping.date.error.message"));

		}

		if (o.getDeliveryDate().isBefore(LocalDate.now())) {

			throw new BadApiRequestException(env.getProperty("delivery.date.error.message"));

		}
	}

	private void addProductQuantity(OrderItem orderItem) {
		Order order = orderItem.getOrder();

		ProductAvailability productAvailability = new ProductAvailability();

		productAvailability.setProduct(orderItem.getProduct());

		String lot = orderItem.getLot();

		Long receivedQuantity = orderItem.getQuantity();

		InventoryItem item = new InventoryItem();

		item.setLotNumber(lot);
		item.setQuantityOnHand(receivedQuantity);
		item.setComment(null);

		Set<InventoryItem> setItem = new HashSet<>();

		setItem.add(item);

		productAvailability.setInventoryItem(setItem);

		productAvailability.setLocation(order.getDestination());

		ProductAvailabilityDto productAvailabilityDto = modelMapper.map(productAvailability,
				ProductAvailabilityDto.class);

		productAvailabilityService.createProductAvailability(productAvailabilityDto);
	}

	private PurchaseOrderResponseDto entityToDto(List<OrderItem> orderItemList, Order order) {

		List<PurchaseOrderItemResponseDto> product = orderItemList.stream().map(r ->

		new PurchaseOrderItemResponseDto(r.getProduct().getName(), r.getQuantity(), r.getLot(),
				r.getRequestedBy().getUsername(), r.getUnitPrice(),
				r.getProductSource() == null ? null : r.getProductSource().getName(), r.getShipmentDate(),
				r.getDeliveryDate(), (r.getQuantity() * r.getUnitPrice()), r.getCreatedDate(), r.getUpdatedDate()))
				.toList();

		return new PurchaseOrderResponseDto(order, product);

	}

	private List<PurchaseOrderItemResponseDto> entityToDto(List<OrderItem> orderItemList) {

		return orderItemList.stream()
				.map(r -> new PurchaseOrderItemResponseDto(r.getProduct().getName(), r.getQuantity(), r.getLot(),
						r.getRequestedBy().getUsername(), r.getUnitPrice(),
						r.getProductSource() == null ? null : r.getProductSource().getName(), r.getShipmentDate(),
						r.getDeliveryDate(), (r.getQuantity() * r.getUnitPrice()), r.getCreatedDate(),
						r.getUpdatedDate()))
				.toList();
	}

}
