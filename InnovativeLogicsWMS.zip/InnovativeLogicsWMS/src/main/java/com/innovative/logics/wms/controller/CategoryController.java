package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.CategoryDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.NumberOfQuantity;
import com.innovative.logics.wms.service.CategoryService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/categories")
@Slf4j
public class CategoryController {

	@Autowired
	private CategoryService categoryService;

	/**
	 * 
	 * The createCategory method is used to create the Category and save the data in
	 * category table based on given details
	 * 
	 * @author manus
	 * @date 31-Jul-2023
	 * @param categoryDto
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<CategoryDto>> createCategory(@Valid @RequestBody final CategoryDto categoryDto) {
		log.info("Enter in createCategory Method present in CategoryController class");
		ApiResponse<CategoryDto> response = categoryService.createCategory(categoryDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getCategoryById method is used to fetch the single Category details from
	 * the category table based on id
	 * 
	 * @author manus
	 * @date 03-Aug-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<CategoryDto>> getCategoryById(@PathVariable("id") final String id) {
		log.info("Enter in getCategoryById Method present in CategoryController class");
		ApiResponse<CategoryDto> response = categoryService.getCategoryById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAllCategory method is used to fetch all the Category based on
	 * organization from the category table with Pagination and Sorting
	 * 
	 * @author manus
	 * @date 07-Aug-2023
	 * @param name
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<PageableResponse<CategoryDto>> getAllCategory(
			@RequestParam(value = "org", required = true) String name,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllCategory Method present in CategoryController class");

		PageableResponse<CategoryDto> response = categoryService.getAllCategory(name, pageNumber, pageSize, sortBy,
				sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The updateCategory method is used to update the Category details based on id
	 * 
	 * @author manus
	 * @date 04-Aug-2023
	 * @param categoryDto
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<CategoryDto>> updateCategory(@Valid @RequestBody final CategoryDto categoryDto,
			@PathVariable("id") final String id) {
		log.info("Enter in updateCategory Method present in CategoryController class");
		ApiResponse<CategoryDto> response = categoryService.updateCategory(categoryDto, id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The deleteCategoryById method is used to delete the Category from category
	 * table based on id
	 * 
	 * @author manus
	 * @date 01-Sep-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<CategoryDto>> deleteCategoryById(@PathVariable final String id) {
		log.info("Enter in deleteCategoryById Method present in CategoryController class");
		ApiResponse<CategoryDto> response = categoryService.deleteCategoryById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getNumberOfCategories method is used to fetch the number of all Category
	 * based on organization
	 * 
	 * @author manus
	 * @date 17-Jan-2024
	 * @param org
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/counts")
	public ResponseEntity<ApiResponse<NumberOfQuantity>> getNumberOfCategories(@RequestParam("org") String org) {
		log.info("Enter in getNumberOfCategories Method present in CategoryController class");
		ApiResponse<NumberOfQuantity> response = categoryService.getNumberOfCategories(org);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAllCategoriesByOrganization method is used to fetch all the Category
	 * based on organization from the category table
	 * 
	 * @author manus
	 * @date 11-Jan-2024
	 * @param name
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('MANAGER') or hasRole('ADMIN') or hasRole('BROWSER')")
	@GetMapping("org")
	public ResponseEntity<ApiResponse<List<CategoryDto>>> getAllCategoriesByOrganization(
			@RequestParam("name") String name) {
		log.info("Enter in getAllCategoriesByOrganization Method present in CategoryController class");

		ApiResponse<List<CategoryDto>> response = categoryService.getAllCategoriesByOrganization(name);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
