package com.innovative.logics.wms.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PartyDto;
import com.innovative.logics.wms.service.PartyService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * The PartyController class defines the REST endpoints for creating,
 * retrieving, updating, and deleting Party entities.Endpoints are secured with
 * Spring Security's @PreAuthorize annotation to ensure that only authorized
 * users can perform CRUD operations on parties.
 * 
 * @author manus
 * @date 15-Apr-2023
 */

@RestController
@RequestMapping("/party")
@Slf4j
public class PartyController {

	@Autowired
	private PartyService partyService;

	/**
	 * 
	 * The createParty method is used to create the party based on given details.
	 * 
	 * @author manus
	 * @date 07-Apr-2023
	 * @param partyDto
	 * @return ResponseEntity containing an ApiResponse with the PartyDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN')")
	@PostMapping
	public ResponseEntity<ApiResponse<PartyDto>> createParty(@Valid @ModelAttribute PartyDto partyDto,
			@RequestParam(name = "logo", required = true) MultipartFile logo) {
		log.info("Enter in createParty Method present in PartyController class");
		ApiResponse<PartyDto> response = partyService.createParty(partyDto, logo);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getPartyById method is used to fetch the single party details from the
	 * party table based on id
	 * 
	 * @author manus
	 * @date 27-Mar-2023
	 * @param id
	 * @return ResponseEntity containing an ApiResponse with the PartyDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<PartyDto>> getPartyById(@PathVariable("id") final String id) {
		log.info("Enter in getPartyById Method present in PartyController class");
		ApiResponse<PartyDto> response = partyService.getPartyById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The updatePartyInformtion method is used to update the Party details based on
	 * id
	 * 
	 * @author manus
	 * @date 31-May-2023
	 * @param partyDetails
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<PartyDto>> updatePartyInformtion(@Valid @ModelAttribute PartyDto partyDto,
			@RequestParam(name = "logo", required = false) MultipartFile logo,
			@PathVariable("id") final String id) throws IOException {
		log.info("Enter in updatePartyInformtion Method present in PartyController class");
		ApiResponse<PartyDto> response = partyService.updateParty(partyDto, id, logo);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	/**
	 * 
	 * The deletePartyById method is used to delete the the Party details from the
	 * party table based on id
	 * 
	 * @author manus
	 * @date 19-Apr-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<PartyDto>> deletePartyById(@PathVariable final String id) {
		log.info("Enter in deleteParty Method present in PartyController class");
		ApiResponse<PartyDto> response = partyService.deletePartyById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAllParty method is used to fetch all the party from the party table
	 * with pagination and sorting
	 * 
	 * @author manus
	 * @date 12-Apr-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return ResponseEntity containing an PageableResponse with the PartyDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN')")
	@GetMapping
	public ResponseEntity<PageableResponse<PartyDto>> getAllParty(
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllParty Method present in PartyController class");

		PageableResponse<PartyDto> response = partyService.getAllParty(pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	/**
	 * 
	 * The searchParty method is used to search the parties based on PartyName
	 * 
	 * @author manus
	 * @date 18-Apr-2023
	 * @param keyword
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN')")
	@GetMapping("/search/{keyword}")
	public ResponseEntity<PageableResponse<PartyDto>> searchParty(@PathVariable String keyword,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in searchParty Method present in PartyController class");
		PageableResponse<PartyDto> response = partyService.searchParty(keyword, pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getpartiesByRoleName method is used to get the parties based on RoleName
	 * 
	 * @author manus
	 * @date 04-Sep-2023
	 * @param roleName
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN')")
	@GetMapping("/role/{roleName}")
	public ResponseEntity<ApiResponse<List<PartyDto>>> getPartiesByRoleName(
			@PathVariable("roleName") final String roleName) {
		log.info("Enter in getLocationsByRoleName Method present in PartyController class");
		ApiResponse<List<PartyDto>> response = partyService.getPartyByRole(roleName);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The getAllParties method is used to fetch all the party from the party table
	 * 
	 * Add method description here
	 * 
	 * @author manus
	 * @date 13-Nov-2023
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/org")
	public ResponseEntity<ApiResponse<List<PartyDto>>> getAllParties() {
		log.info("Enter in getAllParties Method present in PartyController class");
		ApiResponse<List<PartyDto>> response = partyService.getAllParties();

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/logo")
	public ResponseEntity<ByteArrayResource> getOrgLogo(@RequestParam("partyName") String partyName)
			throws IOException {

		ByteArrayResource orgLogo = partyService.getOrgLogo(partyName);
		return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).contentType(MediaType.IMAGE_PNG).body(orgLogo);
	}

}
