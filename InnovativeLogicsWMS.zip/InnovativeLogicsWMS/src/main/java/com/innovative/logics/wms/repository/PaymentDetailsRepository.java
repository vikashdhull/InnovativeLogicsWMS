package com.innovative.logics.wms.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.PaymentDetails;

public interface PaymentDetailsRepository extends JpaRepository<PaymentDetails, String>{

	Optional<PaymentDetails> findByAccountNumber(String accountNumber);

	Optional<PaymentDetails> findByPhoneNumber(String phoneNumber);

	Optional<PaymentDetails> findByEmail(String email);
	
	@Query(value = "SELECT pa FROM PaymentDetails pa WHERE pa.party.name =:name")
	Page<PaymentDetails> findPaymentDetailsByParty(String name, Pageable pageable);

}
