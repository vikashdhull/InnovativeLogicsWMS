package com.innovative.logics.wms.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "product", uniqueConstraints = { @UniqueConstraint(columnNames = { "name", "code" }) })
@Getter
@Setter
public class Product {

	@Column(name = "id")
	@Id
	@UuidGenerator
	private String id;

	@Column(name = "name", length = 40)
	@NotNull(message = "Name should not be null")
	private String name;

	@Column(name = "active")
	private boolean status;

	@Column(name = "code", length = 20)
	private String code;

	@Column(name = "description", columnDefinition = "MEDIUMTEXT")
	private String description;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "product_type_id", referencedColumnName = "id")
	private ProductType productType;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "product_catalog_id", referencedColumnName = "id")
	private ProductCatalog productCatalog;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<ProductAttributeOption> attributeOptions = new ArrayList<>();

	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinTable(name = "product_category", joinColumns = @JoinColumn(name = "product_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "category_id", referencedColumnName = "id"))
	private Set<Category> category = new HashSet<>();

	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinTable(name = "product_tag", joinColumns = @JoinColumn(name = "product_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "tag_id", referencedColumnName = "id"))
	private Set<Tag> tag = new HashSet<>();

	@Column(name = "average_unit_price")
	private Double averageUnitPrice;

	@Column(name = "abc_class")
	private String abcClass;

	@Column(name = "cold_chain")
	private boolean coldChain;

	@Column(name = "controlled_substance")
	private boolean controlledSubstance;

	@Column(name = "reconditioned")
	private boolean reconditioned;

	@Column(name = "hazardous_material")
	private boolean hazardousMaterial;

	@Column(name = "lot_and_expiry_control")
	private boolean lotAndExpiryControl;

	@Column(name = "brand_name")
	private String brandName;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "manufacturer_id", referencedColumnName = "id")
	private Party manufacturer;

	@Column(name = "model_number")
	private String modelNumber;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "vendor_id", referencedColumnName = "id")
	private Location vendor;

	@Column(name = "ndc")
	private String ndc;

	@Column(name = "upc")
	private String upc;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	@JoinTable(name = "product_document", joinColumns = @JoinColumn(name = "product_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "document_id", referencedColumnName = "id"))
	private Set<Document> documents = new HashSet<>();

	@Column(name = "created_date", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createdDate;

	@Column(name = "updated_date")
	@UpdateTimestamp
	private LocalDateTime updatedDate;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "organization_id", referencedColumnName="id")
	private Party party;
	
	@Transient
	private Integer totalQuantity;
}