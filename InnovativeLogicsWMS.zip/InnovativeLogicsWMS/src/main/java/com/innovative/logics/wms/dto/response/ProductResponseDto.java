package com.innovative.logics.wms.dto.response;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.innovative.logics.wms.dto.AttributeOptionDto;
import com.innovative.logics.wms.entity.Category;
import com.innovative.logics.wms.entity.Document;
import com.innovative.logics.wms.entity.Location;
import com.innovative.logics.wms.entity.Party;
import com.innovative.logics.wms.entity.Product;
import com.innovative.logics.wms.entity.ProductCatalog;
import com.innovative.logics.wms.entity.ProductType;
import com.innovative.logics.wms.entity.Tag;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProductResponseDto {

	private String id;
	private String name;
	private boolean status;
	private String code;
	private String description;
	private String productsType;
	private String productsCatalog;
	private Set<String> category;
	private Map<String, List<AttributeOptionDto>> attributeOptionsMap;
	private Set<String> tag;
	private Double averageUnitPrice;
	private String abcClass;
	private boolean coldChain;
	private boolean controlledSubstance;
	private boolean reconditioned;
	private boolean hazardousMaterial;
	private boolean lotAndExpiryControl;
	private String brandName;
	private String manufacturer;
	private String modelNumber;
	private String vendor;
	private String ndc;
	private String upc;
	private Set<Document> documents;
	private String organization;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;

	public ProductResponseDto(Product product) {

		this.id = product.getId();
		this.name = product.getName();
		this.status = product.isStatus();
		this.code = product.getCode();
		ProductType productTypes = product.getProductType();

		if (productTypes == null) {
			this.productsType = null;
		} else {
			this.productsType = productTypes.getName();
		}

		ProductCatalog productCatalogs = product.getProductCatalog();
		if (productCatalogs == null) {
			this.productsCatalog = null;
		} else {
			this.productsCatalog = productCatalogs.getName();
		}

		this.category = product.getCategory().stream().map(Category::getName).collect(Collectors.toSet());
		this.tag = product.getTag().stream().map(Tag::getName).collect(Collectors.toSet());
		this.averageUnitPrice = product.getAverageUnitPrice();
		this.abcClass = product.getAbcClass();
		this.coldChain = product.isColdChain();
		this.controlledSubstance = product.isControlledSubstance();
		this.reconditioned = product.isReconditioned();
		this.hazardousMaterial = product.isHazardousMaterial();
		this.lotAndExpiryControl = product.isLotAndExpiryControl();
		this.brandName = product.getBrandName();
		this.description = product.getDescription();

		Party manufacturers = product.getManufacturer();
		if (manufacturers == null) {
			this.manufacturer = null;
		} else {
			this.manufacturer = manufacturers.getName();
		}

		this.modelNumber = product.getModelNumber();

		Location vendors = product.getVendor();
		if (vendors == null) {
			this.vendor = null;
		} else {
			this.vendor = vendors.getName();
		}

		this.ndc = product.getNdc();
		this.upc = product.getUpc();
		this.documents = product.getDocuments();
		Party party = product.getParty();
		this.organization=party.getName();
		this.createdDate = product.getCreatedDate();
		this.updatedDate = product.getUpdatedDate();
	}
}