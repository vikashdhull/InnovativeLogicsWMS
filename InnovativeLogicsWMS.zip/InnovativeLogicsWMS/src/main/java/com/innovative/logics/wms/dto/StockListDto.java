package com.innovative.logics.wms.dto;

import java.util.List;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class StockListDto {

	private String id;

	@NotEmpty(message = "Name should not be Empty")
	private String name;

	private LocationDto origin;

	private LocationDto destination;

	@Min(value = 0, message = "must be equal or greater then 0")
	private int replenishmentPeriodDays;

	private String replenishmentType;

	@Length(message = "maxmimum description lenth", max = 50)
	private String description;

	private int requisitionItems;

	@JsonIgnore
	private List<StockListItemDto> stockListItem;

	private String party;

	private boolean published;

}
