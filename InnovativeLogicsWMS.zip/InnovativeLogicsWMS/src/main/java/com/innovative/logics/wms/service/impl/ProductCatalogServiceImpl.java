package com.innovative.logics.wms.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductCatalogDto;
import com.innovative.logics.wms.entity.Party;
import com.innovative.logics.wms.entity.ProductCatalog;
import com.innovative.logics.wms.repository.PartyRepository;
import com.innovative.logics.wms.repository.ProductCatalogRepository;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.service.ProductCatalogService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProductCatalogServiceImpl implements ProductCatalogService {

	@Autowired
	private ProductCatalogRepository productCatalogRepository;

	@Autowired
	private Environment env;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private PartyRepository partyRepository;

	@Autowired
	private Utility utility;

	private String productCatalogFetchErrorMessage = "product.catalog.fetch.error.message";

	@Override
	public ApiResponse<ProductCatalogDto> createProductCatalog(ProductCatalogDto productCatalogDto) {

		ApiResponse<ProductCatalogDto> response = new ApiResponse<>();

		Optional<ProductCatalog> existProductCatalogByName = productCatalogRepository
				.findByName(productCatalogDto.getName());
		Optional<ProductCatalog> existProductCatalogByCode = productCatalogRepository
				.findByCode(productCatalogDto.getCode());
		Optional<Party> findOrgByName = partyRepository.findByName(productCatalogDto.getParty());

		try {

			if (existProductCatalogByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "product.catalog.name.error.message");
			}

			if (existProductCatalogByCode.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "product.catalog.code.error.message");
			}

			ProductCatalog productCatalog = modelMapper.map(productCatalogDto, ProductCatalog.class);

			if (findOrgByName.isPresent()) {
				productCatalog.setParty(findOrgByName.get());
			}
			ProductCatalog savedProductCatalog = productCatalogRepository.save(productCatalog);
			ProductCatalogDto newDto = entityToDto(savedProductCatalog);

			response.setData(newDto);
			response.setResult(true);
			response.setMessage(env.getProperty("product.catalog.create.success.message"));
			response.setStatus(HttpStatus.CREATED.value());
			return response;

		} catch (Exception exp) {
			log.error("Exception Occured in createProductCatalog Method present in ProductCatalogServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<ProductCatalogDto> updateProductCatalog(ProductCatalogDto productCatalogDto,
			String productCatalogId) {
		ApiResponse<ProductCatalogDto> response = new ApiResponse<>();
		Optional<ProductCatalog> productCatalogDetails = productCatalogRepository.findById(productCatalogId);
		Optional<ProductCatalog> existByName = productCatalogRepository.findByName(productCatalogDto.getName());
		Optional<ProductCatalog> existByCode = productCatalogRepository.findByCode(productCatalogDto.getCode());
		try {

			if (productCatalogDetails.isPresent()) {
				ProductCatalog productCatalogData = productCatalogDetails.get();

				if (existByName.isPresent()
						&& !Objects.equals(productCatalogData.getName(), productCatalogDto.getName())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "product.catalog.name.error.message");
				}
				productCatalogData.setName(productCatalogDto.getName());
				if (existByCode.isPresent()
						&& !Objects.equals(productCatalogData.getCode(), productCatalogDto.getCode())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "product.catalog.code.error.message");
				}
				productCatalogData.setCode(productCatalogDto.getCode());
				productCatalogData.setStatus(productCatalogDto.getStatus());
				productCatalogData.setDescription(productCatalogDto.getDescription());
				productCatalogData.setColor(productCatalogDto.getColor());

				ProductCatalog updatedProductCatalog = productCatalogRepository.save(productCatalogData);
				ProductCatalogDto updatedProductCatalogDto = entityToDto(updatedProductCatalog);
				response.setData(updatedProductCatalogDto);
				response.setResult(true);
				response.setMessage(env.getProperty("product.catalog.update.success.message"));
				response.setStatus(HttpStatus.OK.value());

				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productCatalogFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in updateProductCatalog Method present in ProductCatalogServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<ProductCatalogDto> deleteProductCatalogById(String productCatalogId) {
		ApiResponse<ProductCatalogDto> response = new ApiResponse<>();
		try {

			Optional<ProductCatalog> productCatalogDetails = productCatalogRepository.findById(productCatalogId);

			if (productCatalogDetails.isPresent()) {

				boolean productCatalogInUse = checkIfProductCatalogInUse(productCatalogId);

				if (productCatalogInUse) {
					response.setMessage(env.getProperty("product.catalog.use.error.message"));
					response.setResult(false);
					response.setStatus(HttpStatus.CONFLICT.value());
					return response;
				}

				productCatalogRepository.deleteById(productCatalogId);
				response.setMessage(env.getProperty("product.catalog.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productCatalogFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occured in deleteProductCatalogById Method present in ProductCatalogServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<ProductCatalogDto> getProductCatalogById(String productCatalogId) {
		ApiResponse<ProductCatalogDto> response = new ApiResponse<>();
		try {
			Optional<ProductCatalog> productCatalog = productCatalogRepository.findById(productCatalogId);

			if (productCatalog.isPresent()) {
				ProductCatalogDto productCatalogDto = entityToDto(productCatalog.get());
				response.setMessage(env.getProperty("product.catalog.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(productCatalogDto);
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productCatalogFetchErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getProductCatalogById Method present in ProductCatalogServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public PageableResponse<ProductCatalogDto> getAllProductCatalog(String org, int pageNumber, int pageSize,
			String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<ProductCatalog> page = productCatalogRepository.findCategoriesByParty(org, pageable);

		PageableResponse<ProductCatalogDto> response = new PageableResponse<>();
		try {
			if (!page.isEmpty()) {

				List<ProductCatalogDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, productCatalogFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getAllProductCatalog Method present in ProductCatalogServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	private boolean checkIfProductCatalogInUse(String productCatalogId) {
		return productRepository.existProductCatalogInProduct(productCatalogId);
	}

	@Override
	@Transactional
	public ApiResponse<List<ProductCatalogDto>> getAllActiveProductCatalogs(String organization) {
		ApiResponse<List<ProductCatalogDto>> response = new ApiResponse<>();

		try {
			List<ProductCatalog> findAllProductCatalog = productCatalogRepository
					.getAllActiveProductCatalogsByOrg(organization);
			if (!findAllProductCatalog.isEmpty()) {

				List<ProductCatalogDto> productCatalogDtos = findAllProductCatalog.stream().map(this::entityToDto)
						.toList();

				response.setData(productCatalogDtos);
				response.setMessage(env.getProperty("product.catalog.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productCatalogFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getAllProducts Method present in ProductServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private ProductCatalogDto entityToDto(ProductCatalog productCatalog) {
		ProductCatalogDto productCatalogDto = modelMapper.map(productCatalog, ProductCatalogDto.class);

		productCatalogDto.setId(productCatalog.getId());

		productCatalogDto.setParty(productCatalog.getParty().getName());

		return productCatalogDto;
	}

}
