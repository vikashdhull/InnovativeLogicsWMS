package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.Order;

public interface OrderRepository extends JpaRepository<Order, String> {

	final String EXIST_ORIGIN_PARTY_IN_ORDER = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM orders o WHERE o.origin_party = :originPartyId";

	final String EXIST_DESTINATION_PARTY_IN_ORDER = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM orders o WHERE o.destination_party = :destinationPartyId";

	final String FIND_ORDERS_BY_DESTINATION_NAME = "SELECT o.* FROM orders o LEFT JOIN location l ON l.id = o.destination WHERE l.name = :destinationName";
	
	final String FIND_ORDERS_BY_STATUS_AND_DESTINATION = "SELECT o.* FROM orders o LEFT JOIN location l ON l.id = o.destination WHERE o.status = 'RECEIVED' and l.name = :destinationName";

	@Query(value = EXIST_ORIGIN_PARTY_IN_ORDER, nativeQuery = true)
	boolean existOriginPartyInOrder(String originPartyId);

	@Query(value = EXIST_DESTINATION_PARTY_IN_ORDER, nativeQuery = true)
	boolean existDestinationPartyInOrder(String destinationPartyId);

	Optional<Order> findByName(String name);

	@Query(value = FIND_ORDERS_BY_DESTINATION_NAME, nativeQuery = true)
	List<Order> findOrdersByDestination(String destinationName);
	
	@Query(value = FIND_ORDERS_BY_STATUS_AND_DESTINATION, nativeQuery = true)
	List<Order> findOrderByStatus(String destinationName);
	
	@Query(value = "SELECT o FROM Order o LEFT JOIN Location l ON o.destination = l  WHERE o.status = 'RECEIVED' and l.name = :destinationName")
	Page<Order> findPurchaseOrderByStatus(String destinationName, Pageable pageable);

	@Query(value = "SELECT o FROM Order o LEFT JOIN Location l ON o.destination = l WHERE l.name = :destinationName")
	Page<Order> findPurchaseOrdersByDestination(String destinationName, Pageable pageable);
}
