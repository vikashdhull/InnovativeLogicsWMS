package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.InventoryLevelDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.InventoryLevelResponseDto;
import com.innovative.logics.wms.service.InventoryLevelService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;


@RestController
@RequestMapping("/inventory-levels")
@Slf4j
public class InventoryLevelController {

	@Autowired
	private InventoryLevelService inventoryLevelService;

	/**
	 * The createInventorylevel method is used to create the Inventory Level based
	 * on given details.
	 * 
	 * @author abhineets
	 * @date 24-Aug-2023
	 * @param inventoryLevelDto
	 * @return
	 */

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<InventoryLevelResponseDto>> createInventoryLevel(
			@Valid @RequestBody final InventoryLevelDto inventoryLevelDto) {
		log.info("Enter in createInventory Method present in InventoryLevelController class");
		ApiResponse<InventoryLevelResponseDto> response = inventoryLevelService.createInventorylevel(inventoryLevelDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The getInventoryLevelByProduct method is used to get all the Inventory Level
	 * based on productId
	 * 
	 * @author abhineets
	 * @date 28-Aug-2023
	 * @param productId
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/product/{productId}")
	public ResponseEntity<ApiResponse<List<InventoryLevelResponseDto>>> getInventoryLevelByProduct(
			@PathVariable("productId") final String productId) {
		log.info("Enter in getInventoryLevelByProductId Method present in InventoryLevelController class");
		ApiResponse<List<InventoryLevelResponseDto>> response = inventoryLevelService.getInventoryLevelByProductId(productId);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<InventoryLevelResponseDto>> getInventoryLevelById(@PathVariable("id") final String id) {
		log.info("Enter in getInventoryLevelByProductId Method present in InventoryLevelController class");
		ApiResponse<InventoryLevelResponseDto> response = inventoryLevelService.getInventoryLevelById(id);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/location/{name}")
	public ResponseEntity<ApiResponse<List<InventoryLevelResponseDto>>> getInventoryLevelByLocationName(@PathVariable("name") final String name) {
		log.info("Enter in getInventoryLevelByLocationName Method present in InventoryLevelController class");
		ApiResponse<List<InventoryLevelResponseDto>> response = inventoryLevelService.getInventoryLevelByLocationName(name);
		
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The getAllInventoryLevels method is used to get all the Inventory Level based
	 * on given details
	 * 
	 * @author abhineets
	 * @date 31-Aug-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<PageableResponse<InventoryLevelResponseDto>> getAllInventoryLevels(
			@RequestParam(value = "org", required = true) String name,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "status", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllInventoryLevels Method present in InventoryController class");
		PageableResponse<InventoryLevelResponseDto> response = inventoryLevelService.getAllInventoryLevels(name, pageNumber, pageSize,
				sortBy, sortDir);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The updateInventoryLevel method is used to update the Inventory Level based
	 * on given details
	 * @date 25-Oct-2023
	 * @author manus
	 * @param inventoryLevelDto
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<InventoryLevelResponseDto>> updateInventoryLevel(
			@Valid @RequestBody final InventoryLevelDto inventoryLevelDto, @PathVariable("id") final String id) {
		log.info("Enter in updateInventoryLevel Method present in InventoryLevelController class");
		ApiResponse<InventoryLevelResponseDto> response = inventoryLevelService.updateInventorylevel(inventoryLevelDto, id);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The deleteInventoryLevel method is used to delete the Inventory Level based
	 * on Inventory level Id
	 * 
	 * @author abhineets
	 * @param Id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<InventoryLevelResponseDto>> deleteInventoryLevel(@PathVariable("id") String id) {
		log.info("Enter in deleteInventoryLevel Method present in InventoryLevelController class");
		ApiResponse<InventoryLevelResponseDto> response = inventoryLevelService.deleteInventoryLevelById(id);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

}
