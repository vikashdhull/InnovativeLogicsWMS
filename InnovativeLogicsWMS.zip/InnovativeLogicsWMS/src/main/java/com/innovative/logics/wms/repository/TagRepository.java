package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.Tag;

public interface TagRepository extends JpaRepository<Tag, String> {
	
	Optional<Tag> findByName(String name);
	
	List<Tag> findByNameIn(List<String> tagNames);
	
	@Query(value = "SELECT t FROM Tag t WHERE t.party.name =:name")
	Page<Tag> findTagsByParty(String name, Pageable pageable);
	
	List<Tag> findByPartyName(String name);

}
