package com.innovative.logics.wms.dto;

public interface InventorySummary {

	String getProductId();

	String getProductName();

	String getProductCode();

	Integer getTotalQuantity();

	Double getAverageUnitPrice();

}
