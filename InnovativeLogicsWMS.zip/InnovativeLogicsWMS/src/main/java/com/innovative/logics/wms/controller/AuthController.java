package com.innovative.logics.wms.controller;

import java.security.Principal;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.JwtRequest;
import com.innovative.logics.wms.dto.UserDto;
import com.innovative.logics.wms.dto.response.JwtResponse;
import com.innovative.logics.wms.service.LoginService;

import lombok.extern.slf4j.Slf4j;

/**
 * This is the AuthController class, which handles authentication related API
 * endpoints. It contains methods for user login and getting the current
 * logged-in user.
 * 
 * @author manus
 * @date 15-Apr-2023
 */
@RestController
@RequestMapping("/auth")
@Slf4j
public class AuthController {

	@Autowired
	private UserDetailsService userDetailsService;

	@Autowired
	private LoginService loginService;

	@Autowired
	private ModelMapper modelMapper;

	/**
	 * 
	 * The login method is used to generate the token based on given details
	 * 
	 * @author manus
	 * @date 20-Mar-2023
	 * @param request
	 * @return ResponseEntity containing an JwtResponse
	 */
	@PostMapping("/login")
	public ResponseEntity<JwtResponse> login(@RequestBody JwtRequest request) {
		log.info("Enter in login Method present in AuthController class");
		JwtResponse response = loginService.login(request.getUsername(), request.getPassword());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/**
	 * 
	 * The getCurrentUser method is used to get the Current logged in User
	 * 
	 * @author manus
	 * @date 25-May-2023
	 * @param principal
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<UserDto> getCurrentUser(Principal principal) {
		log.info("Enter in getCurrentUser Method present in AuthController class");
		String name = principal.getName();
		UserDetails userDetails = userDetailsService.loadUserByUsername(name);

		return new ResponseEntity<>(modelMapper.map(userDetails, UserDto.class), HttpStatus.OK);
	}

}
