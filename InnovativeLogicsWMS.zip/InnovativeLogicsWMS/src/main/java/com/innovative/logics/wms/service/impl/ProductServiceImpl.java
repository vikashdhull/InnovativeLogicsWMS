package com.innovative.logics.wms.service.impl;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.AttributeOptionDto;
import com.innovative.logics.wms.dto.CategoryDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductDto;
import com.innovative.logics.wms.dto.TagDto;
import com.innovative.logics.wms.dto.response.NumberOfQuantity;
import com.innovative.logics.wms.dto.response.ProductResponseDto;
import com.innovative.logics.wms.entity.Attribute;
import com.innovative.logics.wms.entity.AttributeOption;
import com.innovative.logics.wms.entity.Category;
import com.innovative.logics.wms.entity.Document;
import com.innovative.logics.wms.entity.Location;
import com.innovative.logics.wms.entity.Party;
import com.innovative.logics.wms.entity.Product;
import com.innovative.logics.wms.entity.ProductAttributeOption;
import com.innovative.logics.wms.entity.ProductCatalog;
import com.innovative.logics.wms.entity.ProductType;
import com.innovative.logics.wms.entity.Tag;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.exception.ResourceNotFoundException;
import com.innovative.logics.wms.repository.AttributeOptionRepository;
import com.innovative.logics.wms.repository.AttributeRepository;
import com.innovative.logics.wms.repository.CategoryRepository;
import com.innovative.logics.wms.repository.DocumentRepository;
import com.innovative.logics.wms.repository.InventoryLevelRepository;
import com.innovative.logics.wms.repository.LocationRepository;
import com.innovative.logics.wms.repository.PartyRepository;
import com.innovative.logics.wms.repository.ProductAvailabilityRepository;
import com.innovative.logics.wms.repository.ProductCatalogRepository;
import com.innovative.logics.wms.repository.ProductPackageRepository;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.repository.ProductSourceRepository;
import com.innovative.logics.wms.repository.ProductTypeRepository;
import com.innovative.logics.wms.repository.StockListItemRepository;
import com.innovative.logics.wms.repository.TagRepository;
import com.innovative.logics.wms.service.ProductService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private TagRepository tagRepository;

	@Autowired
	private AttributeRepository attributeRepository;

	@Autowired
	private AttributeOptionRepository attributeOptionRepository;

	@Autowired
	private ProductTypeRepository productTypeRepository;

	@Autowired
	private ProductCatalogRepository productCatalogRepository;

	@Autowired
	private ProductSourceRepository productSourceRepository;

	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private PartyRepository partyRepository;

	@Autowired
	private LocationRepository locationRepository;

	@Autowired
	private DocumentRepository documentRepository;

	@Autowired
	private InventoryLevelRepository inventoryLevelRepository;

	@Autowired
	private ProductAvailabilityRepository productAvailabilityRepository;

	@Autowired
	private ProductPackageRepository productPackageRepository;

	@Autowired
	private StockListItemRepository stockListItemRepository;

	@Autowired
	private Environment env;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Utility utility;

	private String productFetchErrorMessage = "product.fetch.error.message";

	private String productVenderFetchErrorMessage = "product.vender.fetch.error.message";

	private String productManufacturerFetchErrorMessage = "product.manufacturer.fetch.error.message";

	private String productFetchSuccessMessage = "product.fetch.success.message";

	@Override
	@Transactional(propagation = Propagation.SUPPORTS)
	public ApiResponse<ProductResponseDto> createProduct(ProductDto productDto) {
		ApiResponse<ProductResponseDto> response = new ApiResponse<>();

		Optional<Product> existProductByName = productRepository.findByName(productDto.getName());
		Optional<Product> existProductByCode = productRepository.findByCode(productDto.getCode());
		
		Optional<Party> findOrgByName = partyRepository.findByName(productDto.getParty());

		try {
			if (existProductByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "product.name.error.message");
			}

			if (existProductByCode.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "product.code.error.message");
			}

			Optional<ProductType> findProductTypeByName = productTypeRepository
					.findByName(productDto.getProductType().getName());
			Optional<ProductCatalog> findProductCatalogByName = productCatalogRepository
					.findByName(productDto.getProductCatalog().getName());

			Optional<Party> findManufacturerByName = partyRepository.findByName(productDto.getManufacturer().getName());

			Optional<Location> findVenderByName = locationRepository.findByName(productDto.getVendor().getName());

			modelMapper.getConfiguration().setAmbiguityIgnored(true);

			Product product = modelMapper.map(productDto, Product.class);

			setProductType(product, findProductTypeByName);
			setProductCatalog(product, findProductCatalogByName);

			setCategory(productDto, product);
			setTags(productDto, product);
			setAttributeOptions(productDto, product);

			if (!findManufacturerByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productManufacturerFetchErrorMessage);
			}

			product.setManufacturer(findManufacturerByName.get());

			if (!findVenderByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productVenderFetchErrorMessage);
			}

			product.setVendor(findVenderByName.get());
			
			if (findOrgByName.isPresent()) {
				product.setParty(findOrgByName.get());
			}

			Product savedProduct = productRepository.save(product);

			ProductResponseDto productResponseDto = entityToDto(savedProduct);

			response.setData(productResponseDto);
			response.setResult(true);
			response.setMessage(env.getProperty("product.create.success.message"));
			response.setStatus(HttpStatus.CREATED.value());
			return response;

		} catch (Exception exp) {
			log.error("Exception Occurred in createProduct Method present in ProductServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public ApiResponse<ProductResponseDto> updateProduct(ProductDto productDto, String productId) {
		ApiResponse<ProductResponseDto> response = new ApiResponse<>();

		try {
			Optional<Product> productOptional = productRepository.findById(productId);

			Optional<Product> findByName = productRepository.findByName(productDto.getName());

			Optional<Product> findByCode = productRepository.findByCode(productDto.getCode());

			if (productOptional.isPresent()) {
				Product productToUpdate = productOptional.get();

				if (findByName.isPresent() && !Objects.equals(productToUpdate.getName(), productDto.getName())) {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, "product.name.error.message");

				}

				productToUpdate.setName(productDto.getName());

				if (findByCode.isPresent() && !Objects.equals(productToUpdate.getCode(), productDto.getCode())) {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, "product.code.error.message");

				}
				productToUpdate.setCode(productDto.getCode());
				productToUpdate.setDescription(productDto.getDescription());
				productToUpdate.setStatus(productDto.isStatus());
				productToUpdate.setAverageUnitPrice(productDto.getAverageUnitPrice());
				productToUpdate.setAbcClass(productDto.getAbcClass());
				productToUpdate.setColdChain(productDto.isColdChain());
				productToUpdate.setControlledSubstance(productDto.isControlledSubstance());
				productToUpdate.setReconditioned(productDto.isReconditioned());
				productToUpdate.setHazardousMaterial(productDto.isHazardousMaterial());
				productToUpdate.setLotAndExpiryControl(productDto.isLotAndExpiryControl());
				productToUpdate.setBrandName(productDto.getBrandName());
				productToUpdate.setModelNumber(productDto.getModelNumber());
				productToUpdate.setNdc(productDto.getNdc());
				productToUpdate.setUpc(productDto.getUpc());

				productToUpdate.getAttributeOptions().clear();

				Optional<ProductType> findProductTypeByName = productTypeRepository
						.findByName(productDto.getProductType().getName());
				Optional<ProductCatalog> findProductCatalogByName = productCatalogRepository
						.findByName(productDto.getProductCatalog().getName());

				Optional<Party> findManufacturerByName = partyRepository
						.findByName(productDto.getManufacturer().getName());

				Optional<Location> findVenderByName = locationRepository.findByName(productDto.getVendor().getName());

				if (!findManufacturerByName.isPresent()) {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, productManufacturerFetchErrorMessage);
				}

				productToUpdate.setManufacturer(findManufacturerByName.get());

				if (!findVenderByName.isPresent()) {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, productVenderFetchErrorMessage);
				}

				productToUpdate.setVendor(findVenderByName.get());

				setProductType(productToUpdate, findProductTypeByName);

				setProductCatalog(productToUpdate, findProductCatalogByName);

				setCategory(productDto, productToUpdate);

				setTags(productDto, productToUpdate);
				setAttributeOptions(productDto, productToUpdate);

				Product updatedProduct = productRepository.save(productToUpdate);

				ProductResponseDto productResponseDto = entityToDto(updatedProduct);

				response.setData(productResponseDto);
				response.setResult(true);
				response.setMessage(env.getProperty("product.update.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "product.update.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occurred in updateProduct Method present in ProductServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<ProductResponseDto> deleteProductById(String productId) {
		ApiResponse<ProductResponseDto> response = new ApiResponse<>();
		try {

			Optional<Product> productDetails = productRepository.findById(productId);

			if (productDetails.isPresent()) {

				boolean productInUse = checkIfProductInUse(productId);

				if (productInUse) {

					return utility.errorResponse(response, HttpStatus.CONFLICT, "product.use.error.message");
				}

				productRepository.deleteById(productId);
				response.setMessage(env.getProperty("product.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteProductById Method present in ProductServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public ApiResponse<ProductResponseDto> getProductById(String productId) {
		ApiResponse<ProductResponseDto> response = new ApiResponse<>();
		try {
			Optional<Product> productOptional = productRepository.findById(productId);

			if (productOptional.isPresent()) {
				Product product = productOptional.get();

				ProductResponseDto productResponseDto = entityToDto(product);

				response.setMessage(env.getProperty(productFetchSuccessMessage));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(productResponseDto);
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productFetchErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in getProductById Method present in ProductServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public PageableResponse<ProductResponseDto> getAllProduct(String org, int pageNumber, int pageSize, String sortBy,
			String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
		Page<Product> page = productRepository.findProductsByOrganization(org, pageable);

		PageableResponse<ProductResponseDto> response = new PageableResponse<>();

		try {
			if (!page.isEmpty()) {

				List<ProductResponseDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, productFetchErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in getAllProduct Method present in ProductServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public PageableResponse<ProductDto> searchProduct(String org, String keyword, int pageNumber, int pageSize, String sortBy,
			String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<Product> product = productRepository.findByNameContaining(keyword, pageable);

		try {
			if (!product.isEmpty()) {

				PageableResponse<ProductDto> response = utility.getPageableResponse(product, ProductDto.class);

				for (ProductDto productDto : response.getData()) {
					Product productEntity = productRepository.findById(productDto.getId()).orElseThrow(
							() -> new ResourceNotFoundException(env.getProperty(productFetchErrorMessage)));

					Map<String, List<AttributeOptionDto>> attributeOptionsMap = populateAttributeOptionsMap(
							productEntity.getAttributeOptions());
					productDto.setAttributeOptionsMap(attributeOptionsMap);
				}

				return response;
			} else {
				PageableResponse<ProductDto> response = new PageableResponse<>();
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, productFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in searchProduct Method present in ProductServiceImpl class{}",
					exp.getMessage());
			PageableResponse<ProductDto> response = new PageableResponse<>();
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private void setProductType(Product productData, Optional<ProductType> findProductTypeByName) {
		ProductType productType = findProductTypeByName
				.orElseThrow(() -> new BadApiRequestException(env.getProperty("product.type.fetch.error.message")));
		productData.setProductType(productType);
	}

	private void setProductCatalog(Product productData, Optional<ProductCatalog> findProductCatalogByName) {
		ProductCatalog productCatalog = findProductCatalogByName
				.orElseThrow(() -> new BadApiRequestException(env.getProperty("product.catalog.fetch.error.message")));
		productData.setProductCatalog(productCatalog);
	}

	private void setTags(ProductDto productDto, Product productData) {
		List<Tag> tags = tagRepository
				.findByNameIn(productDto.getTag().stream().map(TagDto::getName).toList());
		if (tags.size() != productDto.getTag().size()) {
			throw new ResourceNotFoundException(env.getProperty("tag.fetch.error.message"));
		} else {
			productData.setTag(new HashSet<>(tags));
		}
	}

	private void setCategory(ProductDto productDto, Product productData) {
		List<Category> categories = categoryRepository
				.findByNameIn(productDto.getCategory().stream().map(CategoryDto::getName).toList());
		if (categories.size() != productDto.getCategory().size()) {
			throw new ResourceNotFoundException(env.getProperty("category.fetch.error.message"));
		} else {
			productData.setCategory(new HashSet<>(categories));
		}
	}

	private void setAttributeOptions(ProductDto productDto, Product productData) {

		productDto.getAttributeOptionsMap().forEach((attributeName, attributeOptionDtoList) -> {

			Optional<Attribute> attributeOptional = attributeRepository.findByName(attributeName);
			if (!attributeOptional.isPresent()) {
				throw new ResourceNotFoundException("Attribute with name " + attributeName + " not found.");
			}

			List<AttributeOption> attributeOptions = attributeOptionRepository
					.findAttributeOptionsByAttributeNameAndOptions(attributeOptional.get().getName(),
							attributeOptionDtoList.stream().map(AttributeOptionDto::getOptions).toList());

			if (attributeOptions.size() != attributeOptionDtoList.size()) {
				throw new ResourceNotFoundException(
						"One or more AttributeOptions not found for Attribute: " + attributeName);
			}

			attributeOptions.forEach(attributeOption -> {
				ProductAttributeOption productAttributeOption = new ProductAttributeOption();
				productAttributeOption.setAttribute(attributeOptional.get());
				productAttributeOption.setAttributeOption(attributeOption);
				productAttributeOption.setProduct(productData);
				productData.getAttributeOptions().add(productAttributeOption);
			});
		});
	}

	private Map<String, List<AttributeOptionDto>> populateAttributeOptionsMap(
			List<ProductAttributeOption> attributeOptions) {
		Map<String, List<AttributeOptionDto>> attributeOptionsMap = new HashMap<>();

		attributeOptions.forEach(productAttributeOption -> {
			String attributeName = productAttributeOption.getAttribute().getName();
			AttributeOption attributeOption = productAttributeOption.getAttributeOption();

			attributeOptionsMap.computeIfAbsent(attributeName, k -> new ArrayList<>())
					.add(modelMapper.map(attributeOption, AttributeOptionDto.class));
		});

		return attributeOptionsMap;
	}

	@Override
	@Transactional
	public PageableResponse<ProductResponseDto> getProductByCatalog(String productCatalog, int pageNumber, int pageSize,
			String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
		Page<Product> page = productRepository.findByProductCatalog(productCatalog, pageable);

		PageableResponse<ProductResponseDto> response = new PageableResponse<>();

		try {
			if (!page.isEmpty()) {

				List<ProductResponseDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, productFetchErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in getAllProduct Method present in ProductServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private boolean checkIfProductInUse(String productId) {

		boolean existProductInProductSource = productSourceRepository.existProductInProductSource(productId);
		boolean existProductInInbound = productRepository.existProductInInbound(productId);
		boolean existProductInOutbound = productRepository.existProductInOutbound(productId);
		boolean existProductInInventoryLevel = inventoryLevelRepository.existProductInInventoryLevel(productId);
		boolean existProductInProductAvailablity = productAvailabilityRepository
				.existProductInProductAvailablity(productId);
		boolean existProductInProductPackage = productPackageRepository.existProductInProductPackage(productId);
		boolean existProductInStockListItem = stockListItemRepository.existProductInStockListItem(productId);

		return existProductInProductSource || existProductInInbound || existProductInOutbound
				|| existProductInInventoryLevel || existProductInProductAvailablity || existProductInProductPackage
				|| existProductInStockListItem;
	}

	@Override
	@Transactional
	public ApiResponse<ProductResponseDto> uploadDocumentInProduct(String productId, MultipartFile file,
			String documentDto) {

		ApiResponse<ProductResponseDto> response = new ApiResponse<>();
		try {
			if (productId.trim().isEmpty()) {
				return utility.errorResponse(response, HttpStatus.BAD_REQUEST,
						"product.request.id.notFound.error.message");
			}

			Optional<Product> productOptional = productRepository.findById(productId);
			if (!productOptional.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productFetchErrorMessage);
			}
			Product product = productOptional.get();

			Document docs = utility.uploadDocument(file, documentDto);

			product.getDocuments().add(docs);

			Product updatedProduct = productRepository.save(product);
			ProductResponseDto productResponseDto = entityToDto(updatedProduct);
			response.setData(productResponseDto);
			response.setMessage("Document uploaded successfully");
			response.setResult(true);
			response.setStatus(HttpStatus.CREATED.value());
			return response;
		} catch (Exception exp) {
			log.error("Exception Occurred in uploadDocumentInProduct Method present in ProductServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public ApiResponse<ProductResponseDto> deleteDocumentByIdFromProduct(String productId, String documentId) {
		if (productId.trim().isEmpty()) {
			throw new BadApiRequestException("Product id must not be empty to delete a document");
		}

		if (documentId.trim().isEmpty()) {
			throw new BadApiRequestException("Document id must not be empty to delete a document");
		}
		ApiResponse<ProductResponseDto> response = new ApiResponse<>();

		Optional<Document> documentOptional = documentRepository.findById(documentId);

		if (!documentOptional.isPresent()) {
			return utility.errorResponse(response, HttpStatus.NOT_FOUND, "document.fetch.error.message");
		}

		Optional<Product> productOptional = productRepository.findById(productId);

		if (!productOptional.isPresent()) {
			return utility.errorResponse(response, HttpStatus.NOT_FOUND, "product.notFound.error.message");
		}

		Product product = productOptional.get();

		Document existingDocument = documentOptional.get();

		Set<Document> documents = product.getDocuments();

		for (Document document : documents) {
			if (document.getId().equals(documentId)) {
				documents.remove(document);
				break;
			}
		}

		product.setDocuments(documents);

		// save product after removing document
		productRepository.save(product);
		try {
			File docFile = new File(existingDocument.getUrl());
			if (docFile.exists()) {
				Files.delete(docFile.toPath());
			} else {
				log.error("Unable to delete file:: Document file not found at: " + existingDocument.getUrl());
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "document.fetch.error.message");
			}
		} catch (Exception e) {
			log.error("Unable to delete file:: " + existingDocument.getUrl() + "===>>" + e.getMessage());
		}

		documentRepository.delete(existingDocument);
		response.setMessage(env.getProperty("document.delete.success.message"));
		response.setResult(true);
		response.setStatus(HttpStatus.OK.value());
		return response;
	}

	@Override
	public ApiResponse<NumberOfQuantity> getProductInHand(String org) {
		ApiResponse<NumberOfQuantity> response = new ApiResponse<>();
		try {
			NumberOfQuantity productInHand = productRepository.getProductInHand(org);

			if (productInHand != null) {

				response.setMessage(env.getProperty(productFetchSuccessMessage));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(productInHand);
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productFetchErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in getProductInHand Method present in ProductServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public ApiResponse<List<ProductResponseDto>> getAllActiveProducts() {
		ApiResponse<List<ProductResponseDto>> response = new ApiResponse<>();

		try {
			List<Product> findAllProduct = productRepository.getAllActiveProducts();
			if (!findAllProduct.isEmpty()) {

				List<ProductResponseDto> productResponseDtos = findAllProduct.stream().map(this::entityToDto).toList();
				response.setData(productResponseDtos);
				response.setMessage(env.getProperty(productFetchSuccessMessage));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getAllProducts Method present in ProductServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private ProductResponseDto entityToDto(Product product) {
		ProductResponseDto productResponseDto = new ProductResponseDto(product);

		Map<String, List<AttributeOptionDto>> attributeOptionsMap = populateAttributeOptionsMap(
				product.getAttributeOptions());
		productResponseDto.setAttributeOptionsMap(attributeOptionsMap);

		return productResponseDto;

	}

	@Override
	public ApiResponse<List<ProductResponseDto>> getAllProductsByOrganization(String orgnization) {
		ApiResponse<List<ProductResponseDto>> response = new ApiResponse<>();

		try {
			List<Product> allActiveProductsByOrg = productRepository.findByPartyName(orgnization);
			if (!allActiveProductsByOrg.isEmpty()) {

				List<ProductResponseDto> productResponseDtos = allActiveProductsByOrg.stream().map(this::entityToDto)
						.toList();
				response.setData(productResponseDtos);
				response.setMessage(env.getProperty(productFetchSuccessMessage));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occured in getAllActiveProductsByOrgznization Method present in ProductServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<List<ProductResponseDto>> getAllActiveProductsByOrganization(String orgnization) {
		ApiResponse<List<ProductResponseDto>> response = new ApiResponse<>();

		try {
			List<Product> allActiveProductsByOrg = productRepository.getAllActiveProductsByOrg(orgnization);
			if (!allActiveProductsByOrg.isEmpty()) {

				List<ProductResponseDto> productResponseDtos = allActiveProductsByOrg.stream().map(this::entityToDto)
						.toList();
				response.setData(productResponseDtos);
				response.setMessage(env.getProperty(productFetchSuccessMessage));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, productFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occured in getAllActiveProductsByOrgznization Method present in ProductServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}
}