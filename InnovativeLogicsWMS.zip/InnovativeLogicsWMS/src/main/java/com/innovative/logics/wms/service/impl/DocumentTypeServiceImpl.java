package com.innovative.logics.wms.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.DocumentTypeDto;
import com.innovative.logics.wms.entity.DocumentType;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.repository.DocumentTypeRepository;
import com.innovative.logics.wms.service.DocumentTypeService;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DocumentTypeServiceImpl implements DocumentTypeService {

	@Autowired
	private DocumentTypeRepository documentTypeRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Environment env;

	@Override
	public ApiResponse<DocumentTypeDto> createDocumentType(DocumentTypeDto documentTypeDto) {

		ApiResponse<DocumentTypeDto> response = new ApiResponse<>();
		Optional<DocumentType> existDocumentTypeByName = documentTypeRepository.findByName(documentTypeDto.getName());
		try {
			if (existDocumentTypeByName.isPresent()) {
				response.setMessage(env.getProperty("document.type.error.message"));
				response.setResult(false);
				response.setStatus(HttpStatus.CONFLICT.value());
				return response;
			}
			DocumentType documentType = this.modelMapper.map(documentTypeDto, DocumentType.class);
			DocumentType savedDocumentType = documentTypeRepository.save(documentType);
			DocumentTypeDto newDocumentTypeDto = this.modelMapper.map(savedDocumentType, DocumentTypeDto.class);
			response.setData(newDocumentTypeDto);
			response.setMessage(env.getProperty("document.type.success.message"));
			response.setResult(true);
			response.setStatus(HttpStatus.CREATED.value());
			return response;
		} catch (Exception exp) {
			log.error("Exception Occured in createDocumentType Method present in DocumentTypeService class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Transactional
	@Override
	public ApiResponse<List<DocumentTypeDto>> getAllDocumentType() {

		ApiResponse<List<DocumentTypeDto>> response = new ApiResponse<>();
		List<DocumentType> documentType = documentTypeRepository.findAll();
		try {
			if (!documentType.isEmpty()) {
				List<DocumentTypeDto> documentTypeDto = documentType.stream()
						.map(docType -> modelMapper.map(docType, DocumentTypeDto.class)).toList();

				response.setData(documentTypeDto);
				response.setMessage(env.getProperty("document.type.fetch.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				response.setMessage(env.getProperty("document.type.not.found.message"));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getAllDocumentType Method present in DocumentTypeService class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<DocumentTypeDto> updateDocumentType(DocumentTypeDto documentTypeDto, String documentId) {
		ApiResponse<DocumentTypeDto> response = new ApiResponse<>();

		Optional<DocumentType> documentType = documentTypeRepository.findById(documentId);

		Optional<DocumentType> existByName = documentTypeRepository.findByName(documentTypeDto.getName());

		try {
			if (documentType.isPresent()) {
				DocumentType docType = documentType.get();
				if (existByName.isPresent() && !Objects.equals(docType.getName(), documentTypeDto.getName())) {
					throw new BadApiRequestException(env.getProperty("document.type.name.error.message"));
				}
				docType.setName(documentTypeDto.getName());
				DocumentType updatedDocumentType = documentTypeRepository.save(docType);
				DocumentTypeDto updatedDocumentTypeDto = modelMapper.map(updatedDocumentType, DocumentTypeDto.class);
				response.setData(updatedDocumentTypeDto);
				response.setMessage(env.getProperty("document.type.update.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				throw new BadApiRequestException(env.getProperty("document.type.not.found.message"));
			}
		} catch (Exception exp) {
			log.error("Exception Occured in updateDocumentType Method present in DocumentTypeServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}
}
