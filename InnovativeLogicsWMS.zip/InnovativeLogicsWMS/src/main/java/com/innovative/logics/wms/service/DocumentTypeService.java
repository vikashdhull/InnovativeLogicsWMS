package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.DocumentTypeDto;

public interface DocumentTypeService {

	/**
	 * 
	 * This method is used to create the Document Type based on given details
	 * 
	 * @author abhineets
	 * @date 01-Sep-2023
	 * @param documentTypeDto
	 * @return
	 */
	ApiResponse<DocumentTypeDto> createDocumentType(DocumentTypeDto documentTypeDto);

	/**
	 * 
	 * This method is used to fetch all the Document Type.
	 * 
	 * @author manus
	 * @date 05-Sep-2023
	 * @return
	 */
	ApiResponse<List<DocumentTypeDto>> getAllDocumentType();
	
	ApiResponse<DocumentTypeDto> updateDocumentType(DocumentTypeDto documentTypeDto, String documentId);
}
