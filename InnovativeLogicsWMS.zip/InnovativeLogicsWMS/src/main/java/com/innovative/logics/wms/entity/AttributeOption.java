package com.innovative.logics.wms.entity;

import java.io.Serializable;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="attributes_option")
@Getter
@Setter
public class AttributeOption implements Serializable {
	
	/** long Short Description */
	private static final long serialVersionUID = 1L;
	@UuidGenerator
	@Column(name = "id", unique=true)
	@Id
	private String id;
	
	@Column(name = "options", length = 50)
	private String options;
	
	@ManyToOne
	private Attribute attribute;
	
}
