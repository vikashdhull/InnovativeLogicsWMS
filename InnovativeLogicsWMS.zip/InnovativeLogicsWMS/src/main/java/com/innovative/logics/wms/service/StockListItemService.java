package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.StockListItemDto;
import com.innovative.logics.wms.dto.response.StockListItemResponseDto;

public interface StockListItemService {
	
	/**
	 * This method is used to create the StockListItem based on given details
	 * 
	 * @author abhineets
	 * @date 08-Sep-2023
	 * @param stockListItemDto
	 * @return
	 */
	public ApiResponse<StockListItemResponseDto> createStockListItem(StockListItemDto stockListItemDto);

	/**
	 * This method is used to fetch all StockListItem based on StockList id
	 * 
	 * @author abhineets
	 * @date 08-Sep-2023
	 * @param id
	 * @return
	 */
	public ApiResponse<List<StockListItemResponseDto>> getAllStockListItemByStockListId(String id);
	
	/**
	 * This method is used to update the StockListItem based on given details
	 * @author abhineets
	 * @date 08-Sep-2023
	 * @param stockListItemDto
	 * @param id
	 * @return
	 */
	public ApiResponse<StockListItemResponseDto> updateStockListItemById(StockListItemDto stockListItemDto, String id);
	
	/**
	 * This method is used to delete the StockListItem based on id
	 * @author abhineets
	 * @date 08-Sep-2023
	 * @param id
	 * @return
	 */
	public ApiResponse<StockListItemResponseDto> deleteStockListItemById(String id);

}
