package com.innovative.logics.wms.util;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import javax.naming.SizeLimitExceededException;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.DocumentDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.entity.Document;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.service.DocumentService;

@Component
public class Utility {

	@Autowired
	public Environment env;

	@Autowired
	private DocumentService documentService;

	Random random = new Random();

	private static final String DATE_FORMATTER = "yyyy-MM-dd HH:mm:ss";

	public static LocalDateTime dateFormattor() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMATTER);
		String date = LocalDateTime.now().format(formatter);

		return LocalDateTime.parse(date, formatter);
	}

	/**
	 * 
	 * This method is used for pagination
	 * 
	 * @author manus
	 * @date 10-Jun-2023
	 * @param <U>
	 * @param <V>
	 * @param page
	 * @param type
	 * @return
	 */
	public <U, V> PageableResponse<V> getPageableResponse(Page<U> page, Class<V> type) {
		List<U> entity = page.getContent();
		ModelMapper mapper = new ModelMapper();
		mapper.getConfiguration().setAmbiguityIgnored(true);
		List<V> dtoList = entity.stream().map(object -> mapper.map(object, type)).toList();

		long totalElements = page.getTotalElements();
		int totalPages = page.getTotalPages();

		PageableResponse<V> response = new PageableResponse<>();
		response.setData(dtoList);
		response.setPageNumber(page.getNumber());
		response.setPageSize(page.getSize());
		response.setTotalElements(totalElements);
		response.setTotalPages(totalPages);
		response.setLastPage(page.isLast());
		response.setMessage(env.getProperty("record.fetch.success.message"));
		response.setResult(true);
		response.setStatus(HttpStatus.OK.value());
		return response;
	}

	public <U> ApiResponse<U> errorResponse(ApiResponse<U> response, HttpStatus status, String errorMessage) {
		response.setResult(false);
		response.setMessage(env.getProperty(errorMessage));
		response.setStatus(status.value());
		return response;
	}

	public <U> PageableResponse<U> pageableErrorResponse(PageableResponse<U> response, HttpStatus status,
			String errorMessage) {
		response.setResult(false);
		response.setMessage(env.getProperty(errorMessage));
		response.setStatus(status.value());
		return response;
	}

	public Document uploadDocument(MultipartFile file, String documentDtoJSON) {
		ObjectMapper objectMapper = new ObjectMapper();
		DocumentDto documentDto = null;
		Document uploadedDocument = null;
		try {
			documentDto = objectMapper.readValue(documentDtoJSON, DocumentDto.class);
			if (file == null) {
				throw new BadApiRequestException("File not found in the request");
			}
			if (documentDto.getName().isEmpty()) {
				throw new BadApiRequestException("Document name must not be empty");
			}
			uploadedDocument = documentService.uploadDocument(file, documentDto);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		} catch (SizeLimitExceededException e) {
			e.printStackTrace();
		}
		return uploadedDocument;
	}

	public String generateUniqueCode(String name) {

		String character = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

		StringBuilder code = new StringBuilder();

		if (name.length() >= 4) {
			String prefix = name.substring(0, 4);

			code.append(prefix);

			for (int i = 0; i < 8; i++) {

				int index = random.nextInt(character.length());

				code.append(character.charAt(index));
			}

			return code.toString();
		} else {
			return null;
		}
	}

	public String generateUniqueNumber() {

		String character = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

		String generateUUIDNo = String.format("%010d",
				new BigInteger(UUID.randomUUID().toString().replace("-", ""), 16));

		String uniqueNo = generateUUIDNo.substring(generateUUIDNo.length() - 10);

		StringBuilder code = new StringBuilder();

		for (int i = 0; i < 2; i++) {

			int index = random.nextInt(character.length());

			code.append(character.charAt(index));
		}

		code.append(uniqueNo);

		return code.toString();

	}

}
