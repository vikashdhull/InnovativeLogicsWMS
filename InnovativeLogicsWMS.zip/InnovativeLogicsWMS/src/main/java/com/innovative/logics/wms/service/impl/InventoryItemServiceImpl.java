package com.innovative.logics.wms.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.StockRecordDto;
import com.innovative.logics.wms.dto.response.StockRecordResponseDto;
import com.innovative.logics.wms.entity.InventoryItem;
import com.innovative.logics.wms.repository.InventoryItemRepository;
import com.innovative.logics.wms.repository.ProductAvailabilityRepository;
import com.innovative.logics.wms.service.InventoryItemService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class InventoryItemServiceImpl implements InventoryItemService {

	@Autowired
	private InventoryItemRepository inventoryItemRepository;

	@Autowired
	private ProductAvailabilityRepository productAvailabilityRepository;

	@Autowired
	private Utility utility;

	@Autowired
	private Environment env;

	@Override
	@Transactional
	public PageableResponse<StockRecordResponseDto> getAllInventoryItemByLocation(String locationName, int pageNumber,
			int pageSize, String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<InventoryItem> page = inventoryItemRepository.findAllByLocation(locationName, pageable);

		PageableResponse<StockRecordResponseDto> response = new PageableResponse<>();

		try {
			if (!page.isEmpty()) {
				List<StockRecordResponseDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, "inventory.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occured in getAllInventoryItemByLocation Method present in InventoryItemServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public ApiResponse<StockRecordResponseDto> updateInventoryItem(StockRecordDto inventoryItemDto, String id) {
		ApiResponse<StockRecordResponseDto> response = new ApiResponse<>();

		try {
			Optional<InventoryItem> findById = inventoryItemRepository.findById(id);
			if (findById.isPresent()) {
				InventoryItem inventoryItem = findById.get();

				boolean existsByLotNumber = inventoryItemRepository.existsByLotNumber(inventoryItemDto.getLotNumber());

				if (existsByLotNumber
						&& !Objects.equals(inventoryItem.getLotNumber(), inventoryItemDto.getLotNumber())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "lot.number.error.message");
				}

				inventoryItem.setLotNumber(inventoryItemDto.getLotNumber());
				inventoryItem.setQuantityOnHand(inventoryItemDto.getQuantityOnHand());
				inventoryItem.setComment(inventoryItemDto.getComment());

				InventoryItem updatedInventoryItem = inventoryItemRepository.save(inventoryItem);

				response.setData(entityToDto(updatedInventoryItem));
				response.setResult(true);
				response.setMessage(env.getProperty("inventory.item.update.success.message"));
				response.setStatus(HttpStatus.OK.value());
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "inventory.item.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occurred in updateInventoryItem Method present in InventoryItemServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

		return response;
	}

	private StockRecordResponseDto entityToDto(InventoryItem inventoryItem) {

		return new StockRecordResponseDto(inventoryItem);

	}

	@Override
	public ApiResponse<StockRecordResponseDto> deleteInventoryItemById(String inventoryItemId) {
		ApiResponse<StockRecordResponseDto> response = new ApiResponse<>();
		Optional<InventoryItem> findById = inventoryItemRepository.findById(inventoryItemId);
		try {
			if (findById.isPresent()) {

				String productAvailabilityId = findById.get().getProductAvailability().getId();
				int productAvailablityCount = inventoryItemRepository.productAvailablityCount(productAvailabilityId);
				if (productAvailablityCount == 1) {
					productAvailabilityRepository.deleteById(productAvailabilityId);
					response.setMessage(env.getProperty("inventory.item.delete.success.message"));
					response.setResult(true);
					response.setStatus(HttpStatus.OK.value());
					return response;
				} else {
					inventoryItemRepository.deleteById(inventoryItemId);
					response.setMessage(env.getProperty("inventory.item.delete.success.message"));
					response.setResult(true);
					response.setStatus(HttpStatus.OK.value());
					return response;
				}
			} else {
				response.setMessage(env.getProperty("inventory.item.fetch.error.message"));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occured in deleteInventoryLevelById Method present in InventoryLevelServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

}
