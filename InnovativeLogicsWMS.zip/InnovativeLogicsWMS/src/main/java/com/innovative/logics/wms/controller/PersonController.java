package com.innovative.logics.wms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PersonDto;
import com.innovative.logics.wms.service.PersonService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * The PersonController class contains REST endpoints for Person related
 * operations. Endpoints are secured with Spring Security's @PreAuthorize
 * annotation to ensure that only users authorized user can perform CRUD
 * operations on persons.
 * 
 * @author manus
 * @date 15-Apr-2023
 */

@RestController
@RequestMapping("/persons")
@Slf4j
public class PersonController {

	@Autowired
	private PersonService personService;

	/**
	 * 
	 * The createPerson method is used to create the person and save the data in
	 * person table based on given details
	 * 
	 * @author manus
	 * @date 31-Mar-2023
	 * @param personDto
	 * @return ResponseEntity containing an ApiResponse with the PersonDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@PostMapping
	public ResponseEntity<ApiResponse<PersonDto>> createPerson(@Valid @RequestBody final PersonDto personDto) {
		log.info("Enter in createPerson Method present in PersonController class");
		ApiResponse<PersonDto> response = personService.createPerson(personDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getPersonById method is used to fetch the single person details from the
	 * person table based on id
	 * 
	 * @author manus
	 * @date 03-Apr-2023
	 * @param id
	 * @return ResponseEntity containing an ApiResponse with the PersonDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<PersonDto>> getPersonById(@PathVariable("id") final String id) {
		log.info("Enter in getPersonById Method present in PersonController class");
		ApiResponse<PersonDto> response = personService.getPersonById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The deletePerson method is used to delete the person from the person table
	 * based on email
	 * 
	 * @author manus
	 * @date 03-Apr-2023
	 * @param email
	 * @return ResponseEntity containing an ApiResponse with the PersonDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{email}")
	public ResponseEntity<ApiResponse<PersonDto>> deletePerson(@PathVariable final String email) {
		log.info("Enter in deleteUser Method present in PersonController class");
		ApiResponse<PersonDto> response = personService.deletePerson(email);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAllPerson method is used to get all the persons from the person table
	 * 
	 * @author manus
	 * @date 14-Apr-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return ResponseEntity containing an PageableResponse with the PersonDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<PageableResponse<PersonDto>> getAllPerson(
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "email", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllPerson Method present in PersonController class");

		PageableResponse<PersonDto> response = personService.getAllPerson(pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}
}
