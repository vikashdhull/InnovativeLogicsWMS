package com.innovative.logics.wms.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryDto {

	private String id;
	
	@NotNull(message = "Name should not be null")
	private String name;

	private String description;
	
	private String party;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
