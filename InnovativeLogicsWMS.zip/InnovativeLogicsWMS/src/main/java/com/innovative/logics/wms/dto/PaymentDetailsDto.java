package com.innovative.logics.wms.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentDetailsDto {
	
	@NotBlank(message = "First name is required !!")
	private String firstName;

	@NotBlank(message = "Last name is required !!")
	private String lastName;

	@Email(message = "Invalid User Email !!")
	private String email;

	@Pattern(regexp="(^$|\\d{10})", message = "Invalid Phone number")
	private String phoneNumber;

	@NotNull(message = "Account number is required !!")
	@Pattern(regexp="[0-9]+", message = "Invalid Account number")
	private String accountNumber;

	private String description;
	
	private String party;

}
