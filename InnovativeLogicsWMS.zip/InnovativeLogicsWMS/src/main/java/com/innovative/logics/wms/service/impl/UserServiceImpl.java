package com.innovative.logics.wms.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException.BadRequest;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.MakeUserDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PersonDto;
import com.innovative.logics.wms.dto.RoleDto;
import com.innovative.logics.wms.dto.UserDto;
import com.innovative.logics.wms.dto.response.UserResponseDto;
import com.innovative.logics.wms.entity.Party;
import com.innovative.logics.wms.entity.PasswordResetOtp;
import com.innovative.logics.wms.entity.Person;
import com.innovative.logics.wms.entity.Role;
import com.innovative.logics.wms.entity.User;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.exception.ResourceNotFoundException;
import com.innovative.logics.wms.repository.PartyRepository;
import com.innovative.logics.wms.repository.PasswordResetOtpRepository;
import com.innovative.logics.wms.repository.PersonRepository;
import com.innovative.logics.wms.repository.RoleRepository;
import com.innovative.logics.wms.repository.UserRepository;
import com.innovative.logics.wms.service.UserService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

/**
 * This is a Spring Boot service implementation for User entity. It uses
 * repositories to interact with the database and a model mapper to map entities
 * to DTOs.
 * 
 * @author manus
 * @date 15-Apr-2023
 */
@Service
@Slf4j
@PropertySource("classpath:messages.properties")
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PersonRepository personRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private PartyRepository partyRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private PasswordResetOtpRepository passwordResetOtpRepository;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;

	@Autowired
	private ModelMapper modelMapper;

	private Locale locale = Locale.getDefault();

	private String userDetailsError = "userdetails.fetch.error.message";

	private String emailErrorMessage = "user.email.create.error.message";

	private String phoneCreateError = "user.phone.create.error.message";

	private String userDetailsUpdateSucess = "userdetails.update.success.message";

	private String userDetailsSucess = "userdetails.fetch.success.message";

	@Override
	public ApiResponse<UserResponseDto> createUser(UserDto userDto) {

		PersonDto personDto = userDto.getPerson();

		Person personByPhone = personRepository.findByPhoneNumber(personDto.getPhoneNumber());
		Person personByEmail = personRepository.findByEmail(personDto.getEmail());
		Optional<User> existByUserName = userRepository.findByUsername(personDto.getEmail());
		Optional<User> existUserByEmail = userRepository.findByPerson(personByEmail);
		Optional<User> existUserByPhone = userRepository.findByPerson(personByPhone);
		Optional<Party> findPartyByName = partyRepository.findByName(userDto.getParty());

		ApiResponse<UserResponseDto> response = new ApiResponse<>();

		try {
			if (existByUserName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "user.username.create.error.message");
			} else if (existUserByEmail.isPresent() && personByEmail != null) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, emailErrorMessage);
			} else if (existUserByPhone.isPresent() && personByPhone != null) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, phoneCreateError);
			} else {

				userDto.setPassword(passwordEncoder.encode(userDto.getPassword()));
				userDto.setLocale(locale);
				modelMapper.getConfiguration().setAmbiguityIgnored(true);
				User user = modelMapper.map(userDto, User.class);

				if (findPartyByName.isPresent()) {
					user.setParty(findPartyByName.get());
				} else {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, "organization.error.message");
				}
				Person person = modelMapper.map(userDto.getPerson(), Person.class);
				person.setUser(user);
				user.setUsername(personDto.getEmail());

				user.setPerson(person);
				User savedUser = userRepository.save(user);
				UserResponseDto newDto = entityToDto(savedUser);

				response.setData(newDto);
				response.setResult(true);
				response.setMessage(env.getProperty("user.create.success.message"));
				response.setStatus(HttpStatus.CREATED.value());
				return response;
			}
		} catch (Exception exp) {
			log.error("Exception in createUser Method present in UserServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<UserDto> updateUser(UserDto userDto) {

		ApiResponse<UserDto> response = new ApiResponse<>();

		try {
			Optional<User> userDetails = userRepository.findByUsername(userDto.getPerson().getEmail());
			if (userDetails.isPresent()) {
				User user = userDetails.get();

				Person person = user.getPerson();
				
				PersonDto personDto = userDto.getPerson();

				String email = userDto.getPerson().getEmail();
				
				user.setStatus(userDto.getStatus());
				user.setNotes(userDto.getNotes());
				
				person.setFirstName(personDto.getFirstName());
				person.setLastName(personDto.getLastName());
				Person personByEmail = personRepository.findByEmail(email);
				if (personByEmail != null && !personByEmail.getId().equals(person.getId())) {
					throw new BadApiRequestException(env.getProperty(emailErrorMessage));
				}
				person.setEmail(email);
				user.setUsername(email);

				Person personByPhone = personRepository.findByPhoneNumber(userDto.getPerson().getPhoneNumber());
				if (personByPhone != null && !personByPhone.getId().equals(person.getId())) {
					throw new BadApiRequestException(env.getProperty(phoneCreateError));
				}
				person.setPhoneNumber(personDto.getPhoneNumber());
				person.setStreetAddress(personDto.getStreetAddress());
				person.setCity(personDto.getCity());
				person.setState(personDto.getState());
				person.setCountry(personDto.getCountry());
				person.setZipCode(personDto.getZipCode());

				List<Role> roles = roleRepository
						.findByRoleNameIn(userDto.getRole().stream().map(RoleDto::getRoleName).toList());
				if (roles.size() != userDto.getRole().size()) {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, "role.fetch.error.message");
				}
				user.setRole(new HashSet<>(roles));

				user.setIsUser(!user.getRole().isEmpty() && user.getStatus());

				User updatedUser = userRepository.save(user);
				modelMapper.getConfiguration().setAmbiguityIgnored(true);
				UserDto updatedDto = modelMapper.map(updatedUser, UserDto.class);

				response.setData(updatedDto);
				response.setResult(true);
				response.setMessage(env.getProperty(userDetailsUpdateSucess));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, userDetailsError);
			}
		} catch (Exception exp) {
			log.error("Exception in updateUser Method present in UserServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public ApiResponse<UserDto> getUserByUsername(String username) throws ResourceNotFoundException {

		ApiResponse<UserDto> response = new ApiResponse<>();
		try {
			Optional<User> userDetails = userRepository.findByUsername(username);

			if (userDetails.isPresent()) {
				User user = userDetails.get();
				response.setMessage(env.getProperty(userDetailsSucess));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				UserDto userDto = modelMapper.map(user, UserDto.class);
				userDto.setParty(user.getParty().getName());
				response.setData(userDto);
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, userDetailsError);
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getUserById Method present in UserServiceImpl class{}", exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<UserDto> deleteUser(String id, String username) {
		ApiResponse<UserDto> response = new ApiResponse<>();
		try {

			Optional<User> userDetails = userRepository.findById(id);

			if (userDetails.isPresent()) {

				User user = userDetails.get();
				String userId = user.getId();

				if (Objects.equals(username, user.getUsername())) {
					return utility.errorResponse(response, HttpStatus.FORBIDDEN,
							"userdetails.self.delete.error.message");
				}

				Optional<PasswordResetOtp> findByUser = passwordResetOtpRepository.findByUserId(userId);

				if (findByUser.isPresent()) {
					passwordResetOtpRepository.delete(findByUser.get());
				}
				userRepository.deleteById(userId);
				response.setMessage(env.getProperty("userdetails.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "userdetails.delete.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteUser Method present in UserServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	@Override
	@Transactional
	public PageableResponse<UserResponseDto> getAllUser(String org, int pageNumber, int pageSize, String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<User> page = userRepository.findUsersByParty(org, pageable);

		PageableResponse<UserResponseDto> response = new PageableResponse<>();

		try {
			if (!page.isEmpty()) {

				List<UserResponseDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, userDetailsError);
			}
		} catch (BadRequest exp) {
			log.error("Exception Occured in getAllUser Method present in UserServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	@Override
	@Transactional
	public PageableResponse<UserResponseDto> searchUser(String keyword, int pageNumber, int pageSize, String sortBy,
			String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<User> user = userRepository.searchUserByName(keyword, pageable);

		PageableResponse<UserResponseDto> response = utility.getPageableResponse(user, UserResponseDto.class);
		try {
			if (!response.getData().isEmpty()) {

				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, userDetailsError);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in searchUser Method present in UserServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<UserDto> covertUserToPerson(UserDto userDto) {
		Person person = personRepository.findByEmail(userDto.getPerson().getEmail());

		ApiResponse<UserDto> response = new ApiResponse<>();

		try {
			if (person != null) {

				userDto.setPassword(passwordEncoder.encode(userDto.getPassword()));
				userDto.setLocale(locale);
				User user = modelMapper.map(userDto, User.class);
				person.setUser(user);
				user.setPerson(person);
				user.setId(person.getId());
				User savedUser = userRepository.save(user);
				UserDto newDto = modelMapper.map(savedUser, UserDto.class);

				response.setData(newDto);
				response.setResult(true);
				response.setMessage(env.getProperty("user.create.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.BAD_REQUEST, emailErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception in covertUserToPerson Method present in UserServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<PersonDto> updateCurrentUserProfile(PersonDto personDto, String username) {
		ApiResponse<PersonDto> response = new ApiResponse<>();

		try {
			Optional<User> userDetails = userRepository.findByUsername(username);
			if (userDetails.isPresent()) {
				User user = userDetails.get();
				Person person = user.getPerson();
				person.setFirstName(personDto.getFirstName());
				person.setLastName(personDto.getLastName());
				Person personByEmail = personRepository.findByEmail(personDto.getEmail());
				if (personByEmail != null && !personByEmail.getId().equals(person.getId())) {
					throw new BadApiRequestException(env.getProperty(emailErrorMessage));
				}
				person.setEmail(personDto.getEmail());

				Person personByPhone = personRepository.findByPhoneNumber(personDto.getPhoneNumber());
				if (personByPhone != null && !personByPhone.getId().equals(person.getId())) {
					throw new BadApiRequestException(env.getProperty(phoneCreateError));
				}
				person.setPhoneNumber(personDto.getPhoneNumber());

				person.setStreetAddress(personDto.getStreetAddress());
				person.setCity(personDto.getCity());
				person.setState(personDto.getState());
				person.setCountry(personDto.getCountry());
				person.setZipCode(personDto.getZipCode());

				Person updatedUser = personRepository.save(person);
				modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE);
				PersonDto updatedDto = modelMapper.map(updatedUser, PersonDto.class);

				response.setData(updatedDto);
				response.setResult(true);
				response.setMessage(env.getProperty(userDetailsUpdateSucess));
				response.setStatus(HttpStatus.OK.value());

				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.BAD_REQUEST, userDetailsError);
			}
		} catch (Exception exp) {
			log.error("Exception in updateCurrentUserProfile Method present in UserServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<MakeUserDto> makeUser(MakeUserDto userDto) {
		ApiResponse<MakeUserDto> response = new ApiResponse<>();

		try {
			Optional<User> userDetails = userRepository.findByUsername(userDto.getUsername());
			if (userDetails.isPresent()) {
				User user = userDetails.get();
				user.setStatus(userDto.getStatus());
				List<Role> roles = roleRepository
						.findByRoleNameIn(userDto.getRole().stream().map(RoleDto::getRoleName).toList());
				if (roles.size() != userDto.getRole().size()) {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, "role.fetch.error.message");
				}
				user.setRole(new HashSet<>(roles));

				user.setIsUser(!user.getRole().isEmpty() && user.getStatus());

				User updatedUser = userRepository.save(user);
				modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.LOOSE);
				MakeUserDto updatedDto = modelMapper.map(updatedUser, MakeUserDto.class);

				response.setData(updatedDto);
				response.setResult(true);
				response.setMessage(env.getProperty(userDetailsUpdateSucess));
				response.setStatus(HttpStatus.OK.value());

				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.BAD_REQUEST, "userdetails.update.error.message");
			}
		} catch (Exception exp) {
			log.error("Exception in makeUser Method present in UserServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private UserResponseDto entityToDto(User user) {

		UserResponseDto userResponseDto = new UserResponseDto();

		Person person = user.getPerson();

		userResponseDto.setId(user.getId());
		userResponseDto.setFirstName(person.getFirstName());
		userResponseDto.setLastName(person.getLastName());
		userResponseDto.setUsername(person.getEmail());
		userResponseDto.setEmail(person.getEmail());
		userResponseDto.setStatus(user.getStatus());
		userResponseDto.setNotes(user.getNotes());
		userResponseDto.setLocale(user.getLocale());
		userResponseDto.setIsUser(user.getIsUser());

		Set<Role> roles = user.getRole();
		if (roles != null) {
			Set<RoleDto> collect = roles.stream().map(role -> modelMapper.map(role, RoleDto.class))
					.collect(Collectors.toSet());

			userResponseDto.setRole(collect);
		} else {
			userResponseDto.setRole(null);
		}
		userResponseDto.setPhoneNumber(person.getPhoneNumber());
		userResponseDto.setStreetAddress(person.getStreetAddress());
		userResponseDto.setCity(person.getCity());
		userResponseDto.setState(person.getState());
		userResponseDto.setCountry(person.getCountry());
		userResponseDto.setZipCode(person.getZipCode());
		userResponseDto.setOrganization(user.getParty().getName());

		userResponseDto.setCreatedDate(person.getCreatedDate());
		userResponseDto.setUpdatedDate(person.getUpdatedDate());

		return userResponseDto;
	}

	@Override
	public ApiResponse<List<UserResponseDto>> getAllUsersByOrganization(String orgnization) {
		ApiResponse<List<UserResponseDto>> response = new ApiResponse<>();

		try {
			List<User> findUserByPartyName = userRepository.findByPartyName(orgnization);
			if (!findUserByPartyName.isEmpty()) {

				List<UserResponseDto> userResponseDtos = findUserByPartyName.stream().map(this::entityToDto).toList();
				response.setData(userResponseDtos);
				response.setMessage(env.getProperty(userDetailsSucess));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, userDetailsError);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getAllUsersByOrganization Method present in UserServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<List<UserResponseDto>> getAllActiveUsersByOrganization(String orgnization) {
		ApiResponse<List<UserResponseDto>> response = new ApiResponse<>();

		try {
			List<User> allActiveUsersByOrg = userRepository.getAllActiveUsersByOrg(orgnization);
			if (!allActiveUsersByOrg.isEmpty()) {

				List<UserResponseDto> userResponseDtos = allActiveUsersByOrg.stream().map(this::entityToDto).toList();
				response.setData(userResponseDtos);
				response.setMessage(env.getProperty(userDetailsSucess));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, userDetailsError);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getAllActiveUsersByOrganization Method present in UserServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

}
