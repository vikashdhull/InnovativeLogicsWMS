package com.innovative.logics.wms.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.MakeUserDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PersonDto;
import com.innovative.logics.wms.dto.UserDto;
import com.innovative.logics.wms.dto.response.UserResponseDto;
import com.innovative.logics.wms.service.UserService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * The UserController class contains REST endpoints for User related operations.
 * Endpoints are secured with Spring Security's @PreAuthorize annotation to
 * ensure that only users authorized user can perform CRUD operations on users.
 * 
 * @author manus
 * @date 15-Apr-2023
 */

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/users")
@Slf4j
public class UserController {

	@Autowired
	private UserService userService;

	/**
	 * The createUser method is used to create the user and save the data in user
	 * and person table based on given details
	 * 
	 * @author manus
	 * @date 22-Feb-2023
	 * @param userDto
	 * @return ResponseEntity containing an ApiResponse with the UserDto
	 */
	@PostMapping("/signup")
	public ResponseEntity<ApiResponse<UserResponseDto>> createUser(@Valid @RequestBody final UserDto userDto) {
		log.info("Enter in createUser Method present in UserController class");
		ApiResponse<UserResponseDto> response = userService.createUser(userDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The getUserByUserName method is used to fetch the single user details from
	 * the user and person table based on username
	 * 
	 * @author manus
	 * @date 24-Feb-2023
	 * @param id
	 * @return ResponseEntity containing an ApiResponse with the UserDto
	 */
//	@PreAuthorize(" hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{username}")
	public ResponseEntity<ApiResponse<UserDto>> getUserByUserName(@PathVariable("username") final String username) {
		log.info("Enter in getUserByUsername Method present in UserController class");
		ApiResponse<UserDto> response = userService.getUserByUsername(username);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The updateUserInformtion method is used to update the user details from the
	 * user and person table based on user details
	 * 
	 * @author manus
	 * @date 28-Feb-2023
	 * @param userDetails
	 * @return ResponseEntity containing an ApiResponse with the UserDto
	 */
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPERADMIN') or hasRole('MANAGER')")
	@PutMapping
	public ResponseEntity<ApiResponse<UserDto>> updateUserInformtion(@Valid @RequestBody final UserDto userDetails) {
		log.info("Enter in updateUserInformtion Method present in UserController class");
		ApiResponse<UserDto> response = userService.updateUser(userDetails);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	/**
	 * The deleteUser method is used to delete the user from the user and person
	 * table based on id
	 * 
	 * @author manus
	 * @date 17-Mar-2023
	 * @param id
	 * @param principal
	 * @return ResponseEntity containing an ApiResponse with the UserDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<UserDto>> deleteUser(@PathVariable final String id, Principal principal) {
		log.info("Enter in deleteUser Method present in UserController class");
		ApiResponse<UserDto> response = userService.deleteUser(id, principal.getName());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The getAllUsers method is used to fetch the users from the user and person
	 * table Get all the users
	 * 
	 * @author manus
	 * @date 23-Mar-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return ResponseEntity containing an PageableResponse with the UserDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<PageableResponse<UserResponseDto>> getAllUsers(
			@RequestParam(value = "org", required = true) String name,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "username", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllUsers Method present in UserController class");

		PageableResponse<UserResponseDto> response = userService.getAllUser(name, pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	/**
	 * 
	 * The searchUser method is used to search the users based on First Name or Last
	 * Name
	 * 
	 * @author manus
	 * @date 23-Mar-2023
	 * @param keyword
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return ResponseEntity containing an PageableResponse with the UserDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/search/{keyword}")
	public ResponseEntity<PageableResponse<UserResponseDto>> searchUser(@PathVariable String keyword,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "username", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		PageableResponse<UserResponseDto> response = userService.searchUser(keyword, pageNumber, pageSize, sortBy,
				sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The covertUserToPerson method is used to convert the existing person to users
	 * based on person details
	 * 
	 * @author manus
	 * @date 14-Apr-2023
	 * @param userDto
	 * @return ResponseEntity containing an ApiResponse with the UserDto
	 */
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPERADMIN')")
	@PutMapping("/userDetails")
	public ResponseEntity<ApiResponse<UserDto>> covertUserToPerson(@Valid @RequestBody final UserDto userDto) {
		log.info("Enter in covertUserToPerson Method present in UserController class");
		ApiResponse<UserDto> response = userService.covertUserToPerson(userDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * This method is used to update the logged in user information
	 * 
	 * @author manus
	 * @date 29-May-2023
	 * @param userDetails
	 * @param principal
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER') or hasRole('ASSISTANT')")
	@PutMapping("/update-user/")
	public ResponseEntity<ApiResponse<PersonDto>> updateCurrentUserInformtion(
			@Valid @RequestBody final PersonDto userDetails, Principal principal) {
		log.info("Enter in updateCurrentUserInformtion Method present in UserController class");

		ApiResponse<PersonDto> response = userService.updateCurrentUserProfile(userDetails, principal.getName());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@PutMapping("/make-user")
	public ResponseEntity<ApiResponse<MakeUserDto>> makeUser(@Valid @RequestBody final MakeUserDto userDetails) {
		log.info("Enter in updateCurrentUserInformtion Method present in UserController class");

		ApiResponse<MakeUserDto> response = userService.makeUser(userDetails);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/org")
	public ResponseEntity<ApiResponse<List<UserResponseDto>>> getAllUsersByOrgznization(
			@RequestParam("name") String name) {
		log.info("Enter in getAllUsersByOrgznization Method present in UserController class");

		ApiResponse<List<UserResponseDto>> response = userService.getAllUsersByOrganization(name);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("active/org")
	public ResponseEntity<ApiResponse<List<UserResponseDto>>> getAllActiveUsersByOrganization(
			@RequestParam("name") String name) {
		log.info("Enter in getAllActiveUsersByOrganization Method present in UserController class");

		ApiResponse<List<UserResponseDto>> response = userService.getAllActiveUsersByOrganization(name);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}