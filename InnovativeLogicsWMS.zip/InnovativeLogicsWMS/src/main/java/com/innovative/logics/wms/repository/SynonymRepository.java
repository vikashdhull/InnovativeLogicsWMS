package com.innovative.logics.wms.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.ProductPackage;
import com.innovative.logics.wms.entity.Synonym;

public interface SynonymRepository extends JpaRepository<Synonym, String> {
	
	final String SYNONYM_BY_PRODUCT_NAME = "SELECT s.* FROM synonym s JOIN product p ON s.product_id = p.id WHERE p.name = :productName";
	
	Optional<Synonym> findByName(String name);
	
	@Query(value = SYNONYM_BY_PRODUCT_NAME, nativeQuery = true)
	Page<ProductPackage> findSynonymByProductName(String productName, Pageable pageable);

}