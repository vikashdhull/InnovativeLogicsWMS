package com.innovative.logics.wms.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.StockListItemDto;
import com.innovative.logics.wms.dto.response.StockListItemResponseDto;
import com.innovative.logics.wms.entity.Product;
import com.innovative.logics.wms.entity.StockList;
import com.innovative.logics.wms.entity.StockListItem;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.repository.StockListItemRepository;
import com.innovative.logics.wms.repository.StockListRepository;
import com.innovative.logics.wms.service.StockListItemService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StockListItemServiceImpl implements StockListItemService {

	@Autowired
	private StockListItemRepository stockListItemRepo;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private StockListRepository stockListRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Environment env;

	@Override
	@Transactional(propagation = Propagation.SUPPORTS)
	public ApiResponse<StockListItemResponseDto> createStockListItem(StockListItemDto stockListItemDto) {

		ApiResponse<StockListItemResponseDto> apiResponse = new ApiResponse<>();

		Optional<Product> findByProduct = productRepository.findByName(stockListItemDto.getProduct().getName());

		Optional<StockList> findByStockList = stockListRepository.findByName(stockListItemDto.getStockList().getName());

		try {
			if (!findByStockList.isPresent()) {
				throw new BadApiRequestException(env.getProperty("stocklistitem.stocklist.error.message"));
			}
			if (!findByProduct.isPresent()) {
				throw new BadApiRequestException(env.getProperty("stocklistitem.product.error.message"));
			}

			boolean existStockListItemByProductNameAndStockList = stockListItemRepo
					.existStockListItemByProductNameAndStockList(stockListItemDto.getProduct().getName(),
							stockListItemDto.getStockList().getName());

			if (!existStockListItemByProductNameAndStockList) {
				StockListItem stockListItem = modelMapper.map(stockListItemDto, StockListItem.class);

				Product product = findByProduct.get();

				stockListItem.setStockList(findByStockList.get());

				stockListItem.setProduct(product);

				Double quantity = stockListItemDto.getQuantity();
				Double totalCost = (quantity * product.getAverageUnitPrice());
				stockListItem.setTotalCost(totalCost);
				StockListItem savedStockListItem = stockListItemRepo.save(stockListItem);

				StockListItemResponseDto stockListItemResponseDto = entityToDto(savedStockListItem);

				apiResponse.setData(stockListItemResponseDto);
				apiResponse.setMessage(env.getProperty("stockListItem.create.success.message"));
				apiResponse.setResult(true);
				apiResponse.setStatus(HttpStatus.CREATED.value());
				return apiResponse;
			} else {
				throw new BadApiRequestException(env.getProperty("stocklistitem.product.name.error.message"));
			}
		} catch (Exception exp) {
			log.error("Exception Occured in createStockListItem Method present in StockListItemImpl class{}",
					exp.getMessage());
			apiResponse.setMessage(exp.getMessage());
			apiResponse.setStatus(HttpStatus.BAD_REQUEST.value());
			return apiResponse;
		}
	}

	@Override
	@Transactional
	public ApiResponse<List<StockListItemResponseDto>> getAllStockListItemByStockListId(String id) {

		ApiResponse<List<StockListItemResponseDto>> response = new ApiResponse<>();
		List<StockListItem> stockListItem = stockListItemRepo.findByStockListId(id);
		try {
			if (!stockListItem.isEmpty()) {
				List<StockListItemResponseDto> stockListItemDto = stockListItem.stream().map(this::entityToDto)
						.toList();
				response.setData(stockListItemDto);
				response.setMessage(env.getProperty("stockListitem.fetch.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				response.setMessage(env.getProperty("stockListitem.not.found.message"));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getAllStockListItem Method present in StockListItemImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<StockListItemResponseDto> updateStockListItemById(StockListItemDto stockListItemDto, String id) {
		ApiResponse<StockListItemResponseDto> response = new ApiResponse<>();
		Optional<StockListItem> stockListItemDetails = stockListItemRepo.findById(id);
		try {
			if (stockListItemDetails.isPresent()) {
				StockListItem stockListItem = stockListItemDetails.get();

				boolean productEquals = Objects.equals(stockListItem.getProduct().getName(),
						stockListItemDto.getProduct().getName());

				boolean stockListEquals = Objects.equals(stockListItem.getStockList().getName(),
						stockListItemDto.getStockList().getName());

				Optional<Product> findByProductName = productRepository
						.findByName(stockListItemDto.getProduct().getName());
				if (!findByProductName.isPresent()) {
					throw new BadApiRequestException(env.getProperty("stocklistitem.product.error.message"));
				}

				Optional<StockList> findByStockList = stockListRepository
						.findByName(stockListItemDto.getStockList().getName());
				if (!findByStockList.isPresent()) {
					throw new BadApiRequestException(env.getProperty("stocklistitem.stocklist.error.message"));
				}

				boolean existStockListItemByProductNameAndStockList = stockListItemRepo
						.existStockListItemByProductNameAndStockList(stockListItemDto.getProduct().getName(),
								stockListItemDto.getStockList().getName());

				if (existStockListItemByProductNameAndStockList && !productEquals && !stockListEquals) {
					response.setResult(false);
					response.setMessage(env.getProperty("stocklistitem.product.name.error.message"));
					response.setStatus(HttpStatus.CONFLICT.value());
					return response;
				}

				stockListItem.setProduct(findByProductName.get());
				stockListItem.setStockList(findByStockList.get());
				stockListItem.setQuantity(stockListItemDto.getQuantity());
				Double quantity = stockListItemDto.getQuantity();
				Double totalCost = (quantity * findByProductName.get().getAverageUnitPrice());
				stockListItem.setTotalCost(totalCost);

				modelMapper.getConfiguration().setAmbiguityIgnored(true);
				StockListItem updatedstockListItem = stockListItemRepo.save(stockListItem);

				StockListItemResponseDto stockListItemResponseDto = entityToDto(updatedstockListItem);
				response.setData(stockListItemResponseDto);
				response.setResult(true);
				response.setMessage(env.getProperty("stocklistitem.update.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {

				response.setResult(false);
				response.setMessage(env.getProperty("stocklistitem.fetch.error.message"));
				response.setStatus(HttpStatus.CONFLICT.value());
				return response;
			}

		} catch (Exception exp) {
			log.error("Exception Occured in updateStockListItemById Method present in StockListItemImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	@Override
	public ApiResponse<StockListItemResponseDto> deleteStockListItemById(String id) {
		ApiResponse<StockListItemResponseDto> response = new ApiResponse<>();
		try {
			boolean existsById = stockListItemRepo.existsById(id);

			if (existsById) {
				stockListItemRepo.deleteById(id);
				response.setMessage(env.getProperty("stocklistItem.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				response.setMessage(env.getProperty("stocklistitem.fetch.error.message"));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteStockListItemById Method present in StockListItemServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private StockListItemResponseDto entityToDto(StockListItem stockListItem) {

		StockListItemResponseDto stockListItemResponseDto = new StockListItemResponseDto();

		stockListItemResponseDto.setId(stockListItem.getId());
		stockListItemResponseDto.setProduct(stockListItem.getProduct().getName());
		stockListItemResponseDto.setUnitCost(stockListItem.getProduct().getAverageUnitPrice());
		stockListItemResponseDto.setStockList(stockListItem.getStockList().getName());
		stockListItemResponseDto.setQuantity(stockListItem.getQuantity());
		stockListItemResponseDto.setTotalCost(stockListItem.getTotalCost());

		return stockListItemResponseDto;
	}

}
