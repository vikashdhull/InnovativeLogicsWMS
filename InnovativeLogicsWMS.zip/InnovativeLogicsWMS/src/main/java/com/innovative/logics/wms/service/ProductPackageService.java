package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.ProductPackageDto;
import com.innovative.logics.wms.dto.response.ProductPackageResponseDto;

public interface ProductPackageService {
	
	ApiResponse<ProductPackageResponseDto> createProductPackage(ProductPackageDto productPackageDto);

	ApiResponse<ProductPackageResponseDto> getProductPackageById(String productPackageId);
	
	ApiResponse<List<ProductPackageResponseDto>> getProductPackagesByProductname(String productName);
	
	ApiResponse<ProductPackageResponseDto> deleteProductPackageById(String productPackageId);

}
