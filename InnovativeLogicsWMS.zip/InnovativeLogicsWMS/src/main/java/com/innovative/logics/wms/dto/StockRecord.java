package com.innovative.logics.wms.dto;

public interface StockRecord {
	
	String getStatus();
	
	String getProductId();

	String getProductCode();
	
	String getProductName();
	
	String getLocation();
	
	String getAbcClass();
	
	Long getMinimumQuantity();
	
	Long getMaximumQuantity();
	
	Long getReorderQuantity();

	Long getCurrentQuantity();

	Double getAverageUnitPrice();
	
	Double getTotalValue();
	
}
