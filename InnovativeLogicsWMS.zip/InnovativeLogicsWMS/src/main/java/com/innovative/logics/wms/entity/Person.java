package com.innovative.logics.wms.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "person")
@Getter
@Setter
@ToString
public class Person implements Serializable {

	/** long Short Description */
	private static final long serialVersionUID = 1L;
	@UuidGenerator
	@Column(name = "id", updatable = false, nullable = false)
	@Id
	private String id;

	@OneToOne(cascade = CascadeType.ALL, mappedBy = "person")
	@PrimaryKeyJoinColumn
	private User user;

	@Column(name = "first_name", length = 50)
	private String firstName;

	@Column(name = "last_name", length = 50)
	private String lastName;

	@Column(name = "email", unique = true, length = 100)
	private String email;

	@Column(name = "phone", unique = true, length = 10)
	private String phoneNumber;

	@Column(name = "street_address", length = 50)
	private String streetAddress;

	@Column(name = "city", length = 50)
	private String city;

	@Column(name = "state", length = 50)
	private String state;

	@Column(name = "country", length = 50)
	private String country;

	@Column(name = "zip_code", length = 6)
	private String zipCode;

	@Column(name = "created_date", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createdDate;

	@Column(name = "updated_date")
	@UpdateTimestamp
	private LocalDateTime updatedDate;
}