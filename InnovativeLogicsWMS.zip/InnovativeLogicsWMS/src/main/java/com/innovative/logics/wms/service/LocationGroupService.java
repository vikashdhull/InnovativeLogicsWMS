package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.LocationGroupDto;
import com.innovative.logics.wms.dto.PageableResponse;

public interface LocationGroupService {

	/**
	 * 
	 * This method is used to create the locationGroup based on given details
	 * 
	 * @author manus
	 * @date 02-May-2023
	 * @param locationGroupDto
	 * @return
	 */
	ApiResponse<LocationGroupDto> createLocationGroup(LocationGroupDto locationGroupDto);

	/**
	 * 
	 * This method is used to update the LocationGroup details based on id
	 * 
	 * @author manus
	 * @date 31-May-2023
	 * @param locationGroupDto
	 * @param locationGroupId
	 * @return
	 */
	ApiResponse<LocationGroupDto> updateLocationGroup(LocationGroupDto locationGroupDto, String locationGroupId);

	/**
	 * 
	 * This method is used to delete the the locationGroup details based on id
	 * 
	 * @author manus
	 * @date 05-June-2023
	 * @param locationGroupId
	 * @return
	 */
	ApiResponse<LocationGroupDto> deleteLocationGroupById(String locationGroupId);

	/**
	 * 
	 * This method is used to fetch the single locationGroup details based on id
	 * 
	 * @author manus
	 * @date 04-May-2023
	 * @param locationGroupId
	 * @return
	 */
	ApiResponse<LocationGroupDto> getLocationGroupById(String locationGroupId);

	/**
	 * 
	 * This method is used to fetch all the locationGroup
	 * 
	 * @author manus
	 * @date 12-May-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<LocationGroupDto> getAllLocationGroup(String org, int pageNumber, int pageSize, String sortBy, String sortDir);

	/**
	 * 
	 * This method is used to search the locations based on LocationGroupName
	 * 
	 * @author manus
	 * @date 27-May-2023
	 * @param keyword
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<LocationGroupDto> searchLocationGroup(String keyword, int pageNumber, int pageSize, String sortBy,
			String sortDir);
	
	ApiResponse<List<LocationGroupDto>> getAllLocationGroupsByOrganization(String orgnization);

}
