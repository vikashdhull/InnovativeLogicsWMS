package com.innovative.logics.wms.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InventoryLevelDto {

	private String id;

	private String status;

	private ProductDto product;

	private LocationDto location;

	private String abcAnalysisClass;

	private String comments;

	private int minimumQuantity;

	private int maximumQuantity;

	private LocationDto defaultReplenishmentSource;

	private String replenishmentPeriodDays;

	private LocationDto defaultPutAwayLocation;

	private int forecastQuantity;

	private int forecastPeriod;
	
	private int reorderQuantity;
	
	private String expectedLeadTimeDays;
	
	private String party;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;
}
