package com.innovative.logics.wms.entity;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

import org.hibernate.annotations.UuidGenerator;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "users")
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class User implements UserDetails {

	/** long Short Description */
	private static final long serialVersionUID = 1L;

	@Id
	@UuidGenerator
	private String id;

	@Column(name = "username", length = 50)
	@NotNull(message = "Username should not be null")
	private String username;

	@JsonIgnore
	@Column(name = "password", length = 200)
	private String password;

	@Column(name = "active")
	private Boolean status ;

	@Column(name = "notes", length = 300)
	private String notes;

	@Column(name = "last_login_date")
	private LocalDateTime lastLoginDate;

	@Column(name = "locale", length = 50)
	private Locale locale;

	@OneToOne(optional = false, cascade = CascadeType.ALL)
	@JoinColumn(name = "id")
	@MapsId
	private Person person;
	
	@Column(name = "is_user")
	private Boolean isUser;
	
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinTable(name = "user_role", joinColumns = @JoinColumn(name = "user", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "role", referencedColumnName = "id"))
	private Set<Role> role;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "organization_id", referencedColumnName="id")
	private Party party;

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		
		return this.role.stream()
				.map(roles -> new SimpleGrantedAuthority(roles.getRoleName())).collect(Collectors.toSet());
	}

	@Override
	public String getUsername() {
		return this.username;
	}

	@Override
	public String getPassword() {
		return this.password;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}
}
