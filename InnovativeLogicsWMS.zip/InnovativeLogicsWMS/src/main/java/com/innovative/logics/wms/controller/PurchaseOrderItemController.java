package com.innovative.logics.wms.controller;

import java.security.Principal;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.OrderItemDto;
import com.innovative.logics.wms.dto.response.PurchaseOrderItemResponseDto;
import com.innovative.logics.wms.dto.response.PurchaseOrderResponseDto;
import com.innovative.logics.wms.entity.Order;
import com.innovative.logics.wms.repository.OrderRepository;
import com.innovative.logics.wms.service.PurchaseOrderItemService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * The PurchaseOrderItemController class defines the REST endpoints for creating
 * and retrieving purchase order items details.Endpoints are secured with
 * Spring Security's @PreAuthorize annotation to ensure that only authorized
 * users can perform CRUD operations on purchase order.
 * 
 * @author manus
 * @date 23-Dec-2023
 */
@RestController
@RequestMapping("/order-items")
@Slf4j
public class PurchaseOrderItemController {

	@Autowired
	private PurchaseOrderItemService purchaseOrderItemService;
	
	@Autowired
	OrderRepository orderRepository;
	
	/**
	 * 
	 * This createPurchaseOrderWithItems method is used to Ship the purchase Order with 
	 * multiple products.
	 * 
	 * @author manus
	 * @date 15-Dec-2023
	 * @param orderId
	 * @param orderItemDto
	 * @param principal
	 * @return ResponseEntity will return ApiResponse with the PurchaseOrderResponseDto
	 */	
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<PurchaseOrderResponseDto>> createPurchaseOrderWithItems(
			@Valid @RequestBody final List<OrderItemDto> orderItemDto, Principal principal,
			@RequestParam(value = "orderId", required = true) final String orderId) {
		log.info("Enter in createOrderWithMultipleItems Method present in OrderItemController class");
		ApiResponse<PurchaseOrderResponseDto> response = purchaseOrderItemService.createPurchaseOrderWithItems(orderId,
				orderItemDto, principal);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	/**
	 * 
	 * This getPurchaseOrderItemsByOrderId method is used to fetch the OrderItems details based on OrderId
	 * 
	 * @author manus
	 * @date 19-Dec-2023
	 * @param orderId
	 * @return ResponseEntity will return ApiResponse with the list of PurchaseOrderItemsResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<ApiResponse<List<PurchaseOrderItemResponseDto>>> getPurchaseOrderItemsByOrderId(
			@RequestParam(value = "orderId", required = true) String order) {
		log.info("Enter in getOrderItemByOrder Method present in OrderItemController class");
		ApiResponse<List<PurchaseOrderItemResponseDto>> response = purchaseOrderItemService.getPurchaseOrderItemsByOrderId(order);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}


	/**
	 * 
	 * This receivedPurchaseOrderItems method is used to Received the Order based on given orderId.
	 * 
	 * @author manus
	 * @date 21-Dec-2023
	 * @param principal
	 * @param order
	 * @return This will return ApiResponse with the PurchaseOrderResponseDto
	 */
	// This method will use to receive the shipped order
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/receiving")
	public ResponseEntity<ApiResponse<PurchaseOrderResponseDto>> receivePurchaseOrderItems(Principal principal,
			@RequestParam(value = "orderId", required = true) final String orderId) {
		
		ApiResponse<PurchaseOrderResponseDto> errorResponse = new ApiResponse<>();
		log.info("Enter in receivedPurchasedOrderItem Method present in OrderItemController class");
		
		Optional<Order> optionalOrder = orderRepository.findById(orderId);
		
		if (optionalOrder.isPresent()) {
		
		ApiResponse<PurchaseOrderResponseDto> response = purchaseOrderItemService.receivedPurchaseOrderItems(principal,
				optionalOrder.get());

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
		
		} else {
			errorResponse.setMessage("order.fetch.error.message");
			errorResponse.setResult(false);
			errorResponse.setStatus(HttpStatus.NOT_FOUND.value());		
			return new ResponseEntity<>(errorResponse, HttpStatus.valueOf(errorResponse.getStatus()));
		}		
	}
}
