package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductDto;
import com.innovative.logics.wms.dto.response.NumberOfQuantity;
import com.innovative.logics.wms.dto.response.ProductResponseDto;
import com.innovative.logics.wms.service.ProductService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * The ProductController class defines the REST endpoints for creating,
 * retrieving, updating, and deleting Product entities.Endpoints are secured
 * with Spring Security's @PreAuthorize annotation to ensure that only
 * authorized users can perform CRUD operations on products.
 * 
 * @author manus
 * @date 16-Aug-2023
 */

@RestController
@RequestMapping("/products")
@Slf4j
public class ProductController {

	@Autowired
	private ProductService productService;

	/**
	 * 
	 * The createProduct method is used to create the Product and save the data in
	 * product table based on given details
	 * 
	 * @author manus
	 * @date 16-Aug-2023
	 * @param productDto
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<ProductResponseDto>> createProduct(
			@Valid @RequestBody final ProductDto productDto) {
		log.info("Enter in createProduct Method present in ProductController class");
		ApiResponse<ProductResponseDto> response = productService.createProduct(productDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getProductById method is used to fetch the single Product details from
	 * the product table based on id
	 * 
	 * @author manus
	 * @date 22-Aug-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<ProductResponseDto>> getProductById(@PathVariable("id") final String id) {
		log.info("Enter in getProductById Method present in ProductController class");
		ApiResponse<ProductResponseDto> response = productService.getProductById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAllProduct method is used to fetch all the Products from the product
	 * table
	 * 
	 * @author manus
	 * @date 23-Aug-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<PageableResponse<ProductResponseDto>> getAllProduct(
			@RequestParam(value = "org", required = true) String name,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllProduct Method present in ProductController class");

		PageableResponse<ProductResponseDto> response = productService.getAllProduct(name, pageNumber, pageSize, sortBy,
				sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/search/{keyword}")
	public ResponseEntity<PageableResponse<ProductDto>> searchProduct(@PathVariable String keyword,
			@RequestParam(value = "org", required = true) String name,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in searchProduct Method present in ProductController class");

		PageableResponse<ProductDto> response = productService.searchProduct(keyword, name, pageNumber, pageSize, sortBy,
				sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The updateProduct method is used to update the Product details based on id
	 * 
	 * @author manus
	 * @date 25-Aug-2023
	 * @param productDto
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<ProductResponseDto>> updateProduct(
			@Valid @RequestBody final ProductDto productDto, @PathVariable("id") final String id) {
		log.info("Enter in updateProduct Method present in ProductController class");
		ApiResponse<ProductResponseDto> response = productService.updateProduct(productDto, id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<ProductResponseDto>> deleteProductById(@PathVariable final String id) {
		log.info("Enter in deleteProductById Method present in ProductController class");
		ApiResponse<ProductResponseDto> response = productService.deleteProductById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/catalog/{productCatalog}")
	public ResponseEntity<PageableResponse<ProductResponseDto>> getProductByCatalog(@PathVariable String productCatalog,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getProductByCatalog Method present in ProductController class");

		PageableResponse<ProductResponseDto> response = productService.getProductByCatalog(productCatalog, pageNumber,
				pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The uploadDocumentInProduct method is used to upload document in the Product
	 * 
	 * @author manus
	 * @date 16-Aug-2023
	 * @param productDto
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping("/{id}/uploadDocument")
	public ResponseEntity<ApiResponse<ProductResponseDto>> uploadDocumentInProduct(@PathVariable("id") String productId,
			@RequestParam("file") MultipartFile file, @Valid @RequestParam final String documentDto) {
		log.info("Enter in uploadDocumentInProduct Method present in ProductController class");
		ApiResponse<ProductResponseDto> response = productService.uploadDocumentInProduct(productId, file, documentDto);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The deleteDocumentByIdFromProduct method is used to delete/remove document
	 * from the Product
	 * 
	 * @author manus
	 * @date 14-Sep-2023
	 * @param documentId
	 * @param productId
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{id}/deleteDocument")
	public ResponseEntity<ApiResponse<ProductResponseDto>> deleteDocumentByIdFromProduct(
			@PathVariable("id") String productId, @RequestParam("documentId") final String documentId) {
		log.info("Enter in deleteDocumentByIdFromProduct Method present in ProductController class");
		ApiResponse<ProductResponseDto> response = productService.deleteDocumentByIdFromProduct(productId, documentId);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getProductInHand method is used to count all the Product
	 * 
	 * @author manus
	 * @date 04-Oct-2023
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/product-in-hand")
	public ResponseEntity<ApiResponse<NumberOfQuantity>> getProductInHand(@RequestParam("org") String org) {
		log.info("Enter in getProductInHand Method present in ProductController class");
		ApiResponse<NumberOfQuantity> response = productService.getProductInHand(org);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAllActiveProducts method is used to fetch all the active Products from
	 * the product table
	 * 
	 * @author manus
	 * @date 12-Oct-2023
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('MANAGER') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/active")
	public ResponseEntity<ApiResponse<List<ProductResponseDto>>> getAllActiveProducts() {
		log.info("Enter in getAllProducts Method present in ProductController class");

		ApiResponse<List<ProductResponseDto>> response = productService.getAllActiveProducts();

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('MANAGER') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/active/org")
	public ResponseEntity<ApiResponse<List<ProductResponseDto>>> getAllActiveProductsByOrganization(
			@RequestParam("name") String name) {
		log.info("Enter in getAllActiveProductsByOrgznization Method present in ProductController class");

		ApiResponse<List<ProductResponseDto>> response = productService.getAllActiveProductsByOrganization(name);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('MANAGER') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/org")
	public ResponseEntity<ApiResponse<List<ProductResponseDto>>> getAllProductsByOrgznization(
			@RequestParam("name") String name) {
		log.info("Enter in getAllProductsByOrgznization Method present in ProductController class");

		ApiResponse<List<ProductResponseDto>> response = productService.getAllProductsByOrganization(name);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
}
