package com.innovative.logics.wms.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "product_catalog", uniqueConstraints = { @UniqueConstraint(columnNames = { "name", "code" }) })
@Getter
@Setter
public class ProductCatalog {

	@Column(name = "id")
	@Id
	@UuidGenerator
	private String id;
	
	@Column(name = "active")
	private Boolean status;
	
	@Column(name = "name", length = 50)
	@NotNull(message = "Name should not be null")
	private String name;
	
	@Column(name = "code", length = 50)
	private String code;
	
	@Column(name = "color", length = 50)
	private String color;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "organization_id", referencedColumnName="id")
	private Party party;
	
	@Column(name = "description", length = 150)
	private String description;
	
	@Column(name = "created_date", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createdDate;
	
	@Column(name = "updated_date")
	@UpdateTimestamp
	private LocalDateTime updatedDate;
}