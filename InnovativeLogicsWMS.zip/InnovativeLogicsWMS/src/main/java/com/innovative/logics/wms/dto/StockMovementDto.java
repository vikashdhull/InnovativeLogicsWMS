package com.innovative.logics.wms.dto;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StockMovementDto {
	
	private String name;
	
	private String description;

	private LocationDto origin;

	private LocationDto destination;

	private UserDto requestedBy;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate requestedDate;

	private UserDto recipient;
	
	private List<StockMovementItemDto> productList;

}
