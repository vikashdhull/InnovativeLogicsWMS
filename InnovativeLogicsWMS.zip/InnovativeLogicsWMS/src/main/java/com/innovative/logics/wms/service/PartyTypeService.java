package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PartyTypeDto;

public interface PartyTypeService {

	/**
	 * 
	 * This method is used to create the partyType based on given details.
	 * 
	 * @author manus
	 * @date 05-Apr-2023
	 * @param partyTypeDto
	 * @return
	 */
	ApiResponse<PartyTypeDto> createPartyType(PartyTypeDto partyTypeDto);

	/**
	 * 
	 * This method is used to update the PartyType details based on id
	 * 
	 * @author manus
	 * @date 10-Jun-2023
	 * @param partyTypeDto
	 * @param partyId
	 * @return
	 */
	ApiResponse<PartyTypeDto> updatePartyType(PartyTypeDto partyTypeDto, String partyId);

	/**
	 * 
	 * This method is used to delete the the PartyType details based on id
	 * 
	 * @author manus
	 * @date 06-Apr-2023
	 * @param partyTypeId
	 * @return
	 */
	ApiResponse<PartyTypeDto> deletePartyTypeById(String partyTypeId);

	/**
	 * 
	 * This method is used to fetch the PartyType details based on id
	 * 
	 * @author manus
	 * @date 06-Apr-2023
	 * @param partyTypeId
	 * @return
	 */
	ApiResponse<PartyTypeDto> getPartyTypeById(String partyTypeId);

	/**
	 * 
	 * This method is used to fetch all the PartyType
	 * 
	 * @author manus
	 * @date 07-Apr-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<PartyTypeDto> getAllPartyType(int pageNumber, int pageSize, String sortBy, String sortDir);

	/**
	 * 
	 * This method is used to search the partyType based on PartyTypeName
	 * @author manus 
	 * @date 15-Jun-2023 
	 * @param keyword
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<PartyTypeDto> searchPartyType(String keyword, int pageNumber, int pageSize, String sortBy,
			String sortDir);
	
	ApiResponse<List<PartyTypeDto>> getPartyTypes();

}
