package com.innovative.logics.wms.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "address")
@Getter
@Setter
public class Address implements Serializable {

	/** long Short Description */
	private static final long serialVersionUID = 1L;

	@UuidGenerator
	@Column(name = "id", updatable = false)
	@Id
	private String id;

	@Column(name = "address1", length = 50)
	private String address1;

	@Column(name = "address2", length = 50)
	private String address2;

	@Column(name = "street_address", length = 50)
	private String streetAddress;

	@Column(name = "city", length = 50)
	private String city;

	@Column(name = "state_or_province", length = 50)
	private String state;

	@Column(name = "country", length = 50)
	private String country;

	@Column(name = "postalCode", length = 6)
	private String postalCode;

	@Column(name = "description", length = 150)
	private String description;

	@Column(name = "created_date")
	@CreationTimestamp
	private LocalDateTime createdDate;

	@Column(name = "updated_date")
	@UpdateTimestamp
	private LocalDateTime updatedDate;

}
