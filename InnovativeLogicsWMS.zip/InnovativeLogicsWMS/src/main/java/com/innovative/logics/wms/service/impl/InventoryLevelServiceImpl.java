package com.innovative.logics.wms.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.InventoryLevelDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.InventoryLevelResponseDto;
import com.innovative.logics.wms.entity.InventoryLevel;
import com.innovative.logics.wms.entity.Location;
import com.innovative.logics.wms.entity.Party;
import com.innovative.logics.wms.entity.Product;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.repository.InventoryLevelRepository;
import com.innovative.logics.wms.repository.LocationRepository;
import com.innovative.logics.wms.repository.PartyRepository;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.service.InventoryLevelService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class InventoryLevelServiceImpl implements InventoryLevelService {

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private InventoryLevelRepository inventoryLevelRepository;

	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private PartyRepository partyRepository;

	@Autowired
	private LocationRepository locationRepository;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;

	private String inventorylevelerrormessage = "inventory.level.create.error.message";

	@Override
	@Transactional(propagation = Propagation.SUPPORTS)
	public ApiResponse<InventoryLevelResponseDto> createInventorylevel(InventoryLevelDto inventoryLevelDto) {

		ApiResponse<InventoryLevelResponseDto> apiResponse = new ApiResponse<>();

		if ((inventoryLevelDto.getMinimumQuantity()) > (inventoryLevelDto.getMaximumQuantity())) {

			throw new BadApiRequestException(env.getProperty(inventorylevelerrormessage));
		} else {
			Optional<Product> findByName = productRepository.findByName(inventoryLevelDto.getProduct().getName());

			Optional<Location> findDefaultReplenishmentSourceByName = locationRepository
					.findByName(inventoryLevelDto.getDefaultReplenishmentSource().getName());

			Optional<Location> findDefaultPutAwayLocationByName = locationRepository
					.findByName(inventoryLevelDto.getDefaultPutAwayLocation().getName());

			Optional<Location> findDefaultLocationByName = locationRepository
					.findByName(inventoryLevelDto.getLocation().getName());
			
			Optional<Party> findOrgByName = partyRepository.findByName(inventoryLevelDto.getParty());

			InventoryLevel invLevel = modelMapper.map(inventoryLevelDto, InventoryLevel.class);

			setProduct(invLevel, findByName);

			boolean existInventoryLevelByProductAndLocation = inventoryLevelRepository
					.existInventoryLevelByProductAndLocation(inventoryLevelDto.getProduct().getName(),
							inventoryLevelDto.getLocation().getName());
			if (existInventoryLevelByProductAndLocation) {
				return utility.errorResponse(apiResponse, HttpStatus.CONFLICT,
						"inventory.level.product.location.error.message");
			} else {
				if (findDefaultLocationByName.isPresent()) {
					invLevel.setLocation(findDefaultLocationByName.get());
				} else {
					return utility.errorResponse(apiResponse, HttpStatus.NOT_FOUND, "location.fetch.error.message");
				}
			}

			setDefaultReplenishmentSource(invLevel, findDefaultReplenishmentSourceByName);

			setDefaultPutAwayLocation(invLevel, findDefaultPutAwayLocationByName);
			
			if (findOrgByName.isPresent()) {
				invLevel.setParty(findOrgByName.get());
			}

			InventoryLevel inventoryLevel = inventoryLevelRepository.save(invLevel);

			InventoryLevelResponseDto entityToDto = entityToDto(inventoryLevel);

			apiResponse.setData(entityToDto);
			apiResponse.setMessage(env.getProperty("inventoryLevel.create.success.message"));
			apiResponse.setResult(true);
			apiResponse.setStatus(HttpStatus.CREATED.value());
			return apiResponse;
		}
	}

	private void setProduct(InventoryLevel inventoryLevel, Optional<Product> findProductByName) {

		if (findProductByName.isPresent()) {
			inventoryLevel.setProduct(findProductByName.get());
		} else {
			throw new BadApiRequestException(env.getProperty("product.notFound.error.message"));
		}
	}

	private void setDefaultReplenishmentSource(InventoryLevel inventorylevel,
			Optional<Location> findDefaultReplenishmentSourceByName) {
		if (findDefaultReplenishmentSourceByName.isPresent()) {
			Location defaultReplenishmentSource = findDefaultReplenishmentSourceByName.get();
			inventorylevel.setDefaultReplenishmentSource(defaultReplenishmentSource);
		} else {
			inventorylevel.setDefaultReplenishmentSource(null);
		}
	}

	private void setDefaultPutAwayLocation(InventoryLevel inventorylevel,
			Optional<Location> findDefaultPutAwayLocationByName) {
		if (findDefaultPutAwayLocationByName.isPresent()) {
			Location defaultPutAwayLocation = findDefaultPutAwayLocationByName.get();

			inventorylevel.setDefaultPutAwayLocation(defaultPutAwayLocation);
		} else {
			inventorylevel.setDefaultPutAwayLocation(null);
		}
	}

	@Override
	public ApiResponse<InventoryLevelResponseDto> getInventoryLevelById(String inventoryId) {
		ApiResponse<InventoryLevelResponseDto> response = new ApiResponse<>();
		Optional<InventoryLevel> inventoryLevel = inventoryLevelRepository.findById(inventoryId);
		try {
			if (inventoryLevel.isPresent()) {

				InventoryLevelResponseDto entityToDto = entityToDto(inventoryLevel.get());

				response.setMessage(env.getProperty("inventory.level.get.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(entityToDto);
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "inventory.level.fetch.error.message");
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getInventoryLevelById Method present in InventoryLevelServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public ApiResponse<List<InventoryLevelResponseDto>> getInventoryLevelByProductId(String productId) {

		ApiResponse<List<InventoryLevelResponseDto>> response = new ApiResponse<>();
		List<InventoryLevel> inventoryLevels = inventoryLevelRepository.findByProductId(productId);
		List<InventoryLevelResponseDto> responseDtos = inventoryLevels.stream().map(this::entityToDto).toList();
		try {
			if (!inventoryLevels.isEmpty()) {
				response.setData(responseDtos);
				response.setMessage(env.getProperty("inventory.level.fetch.by.productId.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				response.setMessage(env.getProperty("inventory.level.not.found.message"));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occurred in getInventoryLevelByProductId method in InventoryLevelServiceImpl class: {}",
					exp.getMessage());
			throw new BadApiRequestException(exp.getMessage());
		}
	}

	// Method to take response by product name
	@Override
	@Transactional
	public ApiResponse<List<InventoryLevelResponseDto>> getInventoryLevelByLocationName(String name) {

		ApiResponse<List<InventoryLevelResponseDto>> response = new ApiResponse<>();
		List<InventoryLevel> inventoryLevels = inventoryLevelRepository.findByLocationName(name);
		List<InventoryLevelResponseDto> responseDtos = inventoryLevels.stream().map(this::entityToDto).toList();
		try {
			if (!inventoryLevels.isEmpty()) {
				response.setData(responseDtos);
				response.setMessage(env.getProperty("inventory.level.get.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND,
						"inventory.level.fetch.location.error.message");
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occurred in getInventoryLevelByLocationName method in InventoryLevelServiceImpl class: {}",
					exp.getMessage());
			throw new BadApiRequestException(exp.getMessage());
		}
	}

	@Override
	@Transactional
	public PageableResponse<InventoryLevelResponseDto> getAllInventoryLevels(String org, int pageNumber, int pageSize,
			String sortBy, String sortDir) {

		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
		Page<InventoryLevel> page = inventoryLevelRepository.findInventoryLevelsByParty(org, pageable);

		PageableResponse<InventoryLevelResponseDto> response = new PageableResponse<>();

		try {
			if (!page.isEmpty()) {
				List<InventoryLevelResponseDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND,
						"inventory.level.not.found.message");
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getAllUser Method present in UserServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	@Override
	public ApiResponse<InventoryLevelResponseDto> updateInventorylevel(InventoryLevelDto inventoryLevelDto, String id) {
		ApiResponse<InventoryLevelResponseDto> apiResponse = new ApiResponse<>();
		Optional<InventoryLevel> findById = inventoryLevelRepository.findById(id);

		try {
			if (findById.isPresent()) {

				InventoryLevel inventoryLevel = findById.get();
				boolean existInventoryLevelByProductAndLocation = inventoryLevelRepository
						.existInventoryLevelByProductAndLocation(inventoryLevelDto.getProduct().getName(),
								inventoryLevelDto.getLocation().getName());

				boolean productEquals = Objects.equals(inventoryLevel.getProduct().getName(),
						inventoryLevelDto.getProduct().getName());

				boolean locationEquals = Objects.equals(inventoryLevel.getLocation().getName(),
						inventoryLevelDto.getLocation().getName());

				if (existInventoryLevelByProductAndLocation && !productEquals && !locationEquals) {
					return utility.errorResponse(apiResponse, HttpStatus.CONFLICT,
							"inventory.level.product.error.message");
				}

				inventoryLevel.setStatus(inventoryLevelDto.getStatus());

				inventoryLevel.setAbcAnalysisClass(inventoryLevelDto.getAbcAnalysisClass());

				inventoryLevel.setComments(inventoryLevelDto.getComments());

				inventoryLevel.setMinimumQuantity(inventoryLevelDto.getMinimumQuantity());

				inventoryLevel.setMaximumQuantity(inventoryLevelDto.getMaximumQuantity());

				if ((inventoryLevelDto.getMinimumQuantity()) > (inventoryLevelDto.getMaximumQuantity())) {

					throw new BadApiRequestException(env.getProperty(inventorylevelerrormessage));
				}

				inventoryLevel.setReplenishmentPeriodDays(inventoryLevelDto.getReplenishmentPeriodDays());

				inventoryLevel.setForecastPeriod(inventoryLevelDto.getForecastPeriod());

				inventoryLevel.setForecastQuantity(inventoryLevelDto.getForecastQuantity());

				inventoryLevel.setReorderQuantity(inventoryLevelDto.getReorderQuantity());

				inventoryLevel.setExpectedLeadTimeDays(inventoryLevelDto.getExpectedLeadTimeDays());

				Optional<Location> findDefaultReplenishmentSourceByNames = locationRepository
						.findByName(inventoryLevelDto.getDefaultReplenishmentSource().getName());

				Optional<Location> findDefaultPutAwayLocationByName = locationRepository
						.findByName(inventoryLevelDto.getDefaultPutAwayLocation().getName());

				Optional<Location> findDefaultLocationByName = locationRepository
						.findByName(inventoryLevelDto.getLocation().getName());

				Optional<Product> findByName = productRepository.findByName(inventoryLevelDto.getProduct().getName());
				if (!findByName.isPresent()) {
					return utility.errorResponse(apiResponse, HttpStatus.NOT_FOUND, "product.fetch.error.message");
				}
				setProduct(inventoryLevel, findByName);

				if (findDefaultLocationByName.isPresent()) {
					inventoryLevel.setLocation(findDefaultLocationByName.get());
				} else {
					return utility.errorResponse(apiResponse, HttpStatus.NOT_FOUND, "location.fetch.error.message");
				}

				setDefaultReplenishmentSource(inventoryLevel, findDefaultReplenishmentSourceByNames);

				setDefaultPutAwayLocation(inventoryLevel, findDefaultPutAwayLocationByName);

				InventoryLevel savedInventoryLevel = inventoryLevelRepository.save(inventoryLevel);

				InventoryLevelResponseDto inventoryLevelDtos = entityToDto(savedInventoryLevel);

				apiResponse.setData(inventoryLevelDtos);
				apiResponse.setMessage(env.getProperty("inventory.level.update.success.message"));
				apiResponse.setResult(true);
				apiResponse.setStatus(HttpStatus.ACCEPTED.value());
				return apiResponse;

			} else {
				return utility.errorResponse(apiResponse, HttpStatus.NOT_FOUND, "inventory.level.update.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in updateInventoryLevel Method present in InventoryLevelServiceImpl class{}",
					exp.getMessage());

			apiResponse.setMessage(exp.getMessage());
			apiResponse.setResult(false);
			apiResponse.setStatus(HttpStatus.BAD_REQUEST.value());
			return apiResponse;
		}

	}

	@Override
	public ApiResponse<InventoryLevelResponseDto> deleteInventoryLevelById(String inventoryId) {
		ApiResponse<InventoryLevelResponseDto> response = new ApiResponse<>();
		boolean existsByInventoryLevelId = inventoryLevelRepository.existsById(inventoryId);
		try {
			if (existsByInventoryLevelId) {
				inventoryLevelRepository.deleteById(inventoryId);
				response.setMessage(env.getProperty("inventory.level.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				response.setMessage(env.getProperty("inventory.level.fetch.error.message"));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occured in deleteInventoryLevelById Method present in InventoryLevelServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private InventoryLevelResponseDto entityToDto(InventoryLevel inventoryLevel) {

		InventoryLevelResponseDto inventoryLevelResponseDto = new InventoryLevelResponseDto();

		inventoryLevelResponseDto.setId(inventoryLevel.getId());
		inventoryLevelResponseDto.setStatus(inventoryLevel.getStatus());
		inventoryLevelResponseDto.setProduct(inventoryLevel.getProduct().getName());
		inventoryLevelResponseDto.setProductCode(inventoryLevel.getProduct().getCode());
		inventoryLevelResponseDto.setLocation(inventoryLevel.getLocation().getName());
		inventoryLevelResponseDto.setAbcAnalysisClass(inventoryLevel.getAbcAnalysisClass());
		inventoryLevelResponseDto.setComments(inventoryLevel.getComments());
		inventoryLevelResponseDto.setMinimumQuantity(inventoryLevel.getMinimumQuantity());
		inventoryLevelResponseDto.setMaximumQuantity(inventoryLevel.getMaximumQuantity());

		Location defaultReplenishmentSource = inventoryLevel.getDefaultReplenishmentSource();
		if (defaultReplenishmentSource == null) {
			inventoryLevelResponseDto.setDefaultReplenishmentSource(null);
		} else {
			inventoryLevelResponseDto.setDefaultReplenishmentSource(defaultReplenishmentSource.getName());
		}
		inventoryLevelResponseDto.setReplenishmentPeriodDays(inventoryLevel.getReplenishmentPeriodDays());
		Location defaultPutAwayLocation = inventoryLevel.getDefaultPutAwayLocation();
		if (defaultPutAwayLocation == null) {
			inventoryLevelResponseDto.setDefaultPutAwayLocation(null);
		} else {
			inventoryLevelResponseDto.setDefaultPutAwayLocation(defaultPutAwayLocation.getName());
		}

		inventoryLevelResponseDto.setForecastQuantity(inventoryLevel.getForecastQuantity());
		inventoryLevelResponseDto.setForecastPeriod(inventoryLevel.getForecastPeriod());
		inventoryLevelResponseDto.setReorderQuantity(inventoryLevel.getReorderQuantity());
		inventoryLevelResponseDto.setExpectedLeadTimeDays(inventoryLevel.getExpectedLeadTimeDays());
		inventoryLevelResponseDto.setParty(inventoryLevel.getParty().getName());
		inventoryLevelResponseDto.setCreatedDate(inventoryLevel.getCreatedDate());
		inventoryLevelResponseDto.setUpdatedDate(inventoryLevel.getUpdatedDate());

		return inventoryLevelResponseDto;
	}

}
