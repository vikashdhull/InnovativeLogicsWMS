package com.innovative.logics.wms.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductCatalogDto {

	private String id;

	private Boolean status;

	@NotNull(message = "Name should not be null")
	private String name;

	@NotNull(message = "Code should not be null")
	private String code;

	private String color;
	
	private String party;

	private String description;
	
	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
