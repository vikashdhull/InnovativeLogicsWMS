package com.innovative.logics.wms.dto;

import java.util.Set;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PartyDto {

	private String id;

	@NotBlank(message = "Name should not be blank")
	private String name;

	@NotBlank(message = "Code should not be blank")
	private String code;

	private String description;

	private PartyTypeDto partyType;

	private Set<RoleDto> role;

	//@NotBlank(message = "orgLogo should not be blank")
	@Size(max = 100, message = "orgLogo max limit is 100")
	private String orgLogo;

}
