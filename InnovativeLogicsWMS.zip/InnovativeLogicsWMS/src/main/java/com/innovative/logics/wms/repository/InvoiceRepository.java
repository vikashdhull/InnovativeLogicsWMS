package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.Invoice;

public interface InvoiceRepository extends JpaRepository<Invoice, String> {

	final String FIND_INVOICE_BY_DESTINATION = "SELECT i.* FROM invoice i LEFT JOIN orders o ON i.order_id = o.id LEFT JOIN location l ON l.id = o.destination WHERE o.status = 'RECEIVED' and l.name = :destination";

	@Query(value = "SELECT * FROM invoice WHERE order_id = :orderId", nativeQuery = true)
	Optional<Invoice> findByOrder(String orderId);

	@Query(value = FIND_INVOICE_BY_DESTINATION, nativeQuery = true)
	List<Invoice> findInvoiceByDestination(String destination);
	
	@Query(value = "SELECT i FROM Invoice i LEFT JOIN Order o ON i.order = o LEFT JOIN Location l ON l = o.destination WHERE o.status = 'RECEIVED' and l.name = :destination")
	Page<Invoice> findPurchaseInvoiceByDestination(String destination, Pageable pageable);

}
