package com.innovative.logics.wms.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductTypeDto {

	private String id;

	@NotNull(message = "Name should not be null")
	private String name;

	@NotNull(message = "Code should not be null")
	private String code;

	private String productIdentifierFormat;
	
	private String party;
	
	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
