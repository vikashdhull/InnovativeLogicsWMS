package com.innovative.logics.wms.service.impl;

import java.math.BigDecimal;
import java.security.Principal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.StockMovementDto;
import com.innovative.logics.wms.dto.StockMovementItemDto;
import com.innovative.logics.wms.dto.StockMovementShippingDto;
import com.innovative.logics.wms.dto.StockMovementUpdateDto;
import com.innovative.logics.wms.dto.response.NumberOfQuantity;
import com.innovative.logics.wms.dto.response.StockMovementItemResponseDto;
import com.innovative.logics.wms.dto.response.StockMovementResponseDto;
import com.innovative.logics.wms.dto.response.TopDemandingProductResponseDto;
import com.innovative.logics.wms.entity.InventoryItem;
import com.innovative.logics.wms.entity.Location;
import com.innovative.logics.wms.entity.Product;
import com.innovative.logics.wms.entity.StockMovement;
import com.innovative.logics.wms.entity.StockMovementItem;
import com.innovative.logics.wms.entity.User;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.repository.InventoryItemRepository;
import com.innovative.logics.wms.repository.LocationRepository;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.repository.StockMovementItemRepository;
import com.innovative.logics.wms.repository.StockMovementRepository;
import com.innovative.logics.wms.repository.UserRepository;
import com.innovative.logics.wms.service.StockMovementService;
import com.innovative.logics.wms.util.Constants;
import com.innovative.logics.wms.util.Utility;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StockMovementServiceImpl implements StockMovementService {

	@Autowired
	private StockMovementRepository stockMovementRepository;

	@Autowired
	private StockMovementItemRepository stockMovementItemRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private LocationRepository locationRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	InventoryItemRepository inventoryItemRepository;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;

	private static final String ORDER_NOT_FOUND = "stock.movement.fetch.error.message";
	private static final String ALREADY_VERIFIED = "stock.movement.status.error.message";
	private static final String PRODUCT_ALREADY_SHIPPED = "stock.movement.item.ship.error.message";
	private static final String ORDER_CANCELLED = "stock.movement.calcelled";

	@Override
	public ApiResponse<StockMovementResponseDto> createStockMovement(StockMovementDto stockMovementDto) {

		ApiResponse<StockMovementResponseDto> apiResponse = new ApiResponse<>();
		Optional<StockMovement> findByName = stockMovementRepository.findByName(stockMovementDto.getName());

		List<StockMovementItemDto> productList = stockMovementDto.getProductList();

		List<String> productName = productList.stream().map(StockMovementItemDto::getProduct).toList();

		boolean result = productName.stream().map(String::toUpperCase).distinct().count() < productName.size();

		if (result) {
			throw new BadApiRequestException(env.getProperty("order.duplicate.product.error.message"));
		}

		StockMovement stockMovement = new StockMovement();
		List<StockMovementItem> list = new ArrayList<>();

		try {

			Location originLocation = checkOriginLocation(stockMovementDto);
			Location destinationLocation = checkDestinationLocation(stockMovementDto);

			User requestedUser = checkRequestedUserIsPresent(stockMovementDto);

			Optional<User> findRecipientByUsername = userRepository
					.findByUsername(stockMovementDto.getRecipient().getUsername());

			if (!findByName.isPresent()) {

				productList.stream().forEach(p -> {

					StockMovementItem item = new StockMovementItem();

					Optional<Product> findByProductName = productRepository.findByName(p.getProduct());

					if (!findByProductName.isPresent()) {

						throw new BadApiRequestException(env.getProperty("product.fetch.error.message"));
					}

					item.setProduct(findByProductName.get());
					item.setQuantity(p.getQuantity());

					stockMovement.setOrigin(originLocation);
					stockMovement.setDestination(destinationLocation);

					item.setRequestedBy(requestedUser);
					item.setStatus(Constants.VERIFYING);

					list.add(item);
				});

				User receiptUser = !findRecipientByUsername.isEmpty() ? findRecipientByUsername.get() : null;

				stockMovement.setRecipient(receiptUser);
				stockMovement.setRequestedBy(requestedUser);
				stockMovement.setRequestedDate(stockMovementDto.getRequestedDate());
				stockMovement.setDescription(stockMovementDto.getDescription());
				stockMovement.setName(stockMovementDto.getName());
				stockMovement.setStatus(Constants.VERIFYING);

				StockMovement savedMovement = stockMovementRepository.save(stockMovement);

				list.stream().forEach(i -> i.setStockMovement(savedMovement));

				stockMovementItemRepository.saveAll(list);

				StockMovementResponseDto stockMovementResponseDto = entityToDto(savedMovement);

				apiResponse.setData(stockMovementResponseDto);
				apiResponse.setMessage(env.getProperty("stock.movement.create.success.message"));
				apiResponse.setResult(true);
				apiResponse.setStatus(HttpStatus.CREATED.value());
				return apiResponse;
			} else {
				return utility.errorResponse(apiResponse, HttpStatus.ALREADY_REPORTED,
						"stock.movement.name.error.message");
			}
		} catch (Exception exp) {
			log.error("Exception Occured in createStockMovement Method present in StockMovementServiceImpl class: {}",
					exp.getMessage());
			apiResponse.setMessage(exp.getMessage());
			apiResponse.setStatus(HttpStatus.BAD_REQUEST.value());
			return apiResponse;
		}
	}

	@Override
	public ApiResponse<StockMovementResponseDto> updateStockMovement(
			Map<String, StockMovementUpdateDto> stockMovementUpdateDto, String stockMovementId, Principal principal) {

		ApiResponse<StockMovementResponseDto> response = new ApiResponse<>();

		User currentUser = getPresentUser(principal);

		Optional<StockMovement> optionalOrder = stockMovementRepository.findById(stockMovementId);

		if (optionalOrder.isEmpty()) {

			return utility.errorResponse(response, HttpStatus.NOT_FOUND, ORDER_NOT_FOUND);
		}

		StockMovement order = optionalOrder.get();

		if (!Objects.equals(Constants.VERIFYING, order.getStatus())) {

			return utility.errorResponse(response, HttpStatus.NOT_FOUND, ALREADY_VERIFIED);
		}

		List<StockMovementItem> orderItems = stockMovementItemRepository
				.findStockMovementItemByStockMovementId(order.getId());

		if (orderItems.isEmpty()) {

			return utility.errorResponse(response, HttpStatus.NOT_FOUND, "order.item.fetch.error.message");
		}

		try {

			orderItems.stream().forEach(i -> {

				StockMovementUpdateDto dto = stockMovementUpdateDto.get(i.getProduct().getName());

				if (dto == null) {
					throw new BadApiRequestException(env.getProperty("stock.movement.item.fetch.error.message"));
				}

				if (dto.getExpectedShippingdate().isBefore(LocalDate.now())) {

					throw new BadApiRequestException(env.getProperty("shipping.date.error.message"));
				}

				i.setComments(dto.getComment());
				i.setExpectedShippingDate(dto.getExpectedShippingdate());
				i.setUpdatedBy(currentUser.getUsername());
				i.setStatus(Constants.PENDING);

			});

			order.setApprovedBy(currentUser);
			order.setApprovedDate(LocalDate.now());
			order.setStatus(Constants.PENDING);

			stockMovementItemRepository.saveAll(orderItems);

			StockMovement savedOrder = stockMovementRepository.save(order);

			StockMovementResponseDto result = entityToDto(savedOrder);

			response.setData(result);
			response.setMessage(env.getProperty("stock.movement.update.success.message"));
			response.setResult(true);
			response.setStatus(HttpStatus.OK.value());

			return response;

		} catch (Exception exp) {
			log.error("Exception Occurred in updatestockMovement Method present in StockMovementServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	@Override
	public ApiResponse<StockMovementResponseDto> shipStockMovement(StockMovementShippingDto stockMovementShippingDto,
			Principal principal) {

		ApiResponse<StockMovementResponseDto> response = new ApiResponse<>();

		try {

			StockMovement order = getStockMovement(stockMovementShippingDto.getStockMovementName());

			if (order.getStatus().equals(Constants.VERIFYING)) {

				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "stock.movement.verified.error.message");
			}

			if (Objects.equals(order.getStatus(), Constants.PENDING)
					|| Objects.equals(order.getStatus(), Constants.PARTIALLY_SHIPPED)
					|| Objects.equals(order.getStatus(), Constants.PARTIALLY_RECEIVED)) {

				Collection<StockMovementItemDto> items = stockMovementShippingDto.getItems().values();

				productListCannotBeNull(items);

				User currentUser = getPresentUser(principal);

				List<StockMovementItem> orderItems = stockMovementItemRepository
						.findStockMovementItemByStockMovementId(order.getId());

				List<StockMovementItem> filteredList = orderItems.stream()
						.filter(i -> Objects.equals(i.getStatus(), Constants.PENDING)).toList();

				if (filteredList.isEmpty()) {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, PRODUCT_ALREADY_SHIPPED);
				}

				LocalDate deliveryDate = stockMovementShippingDto.getExpectedDeliveryDate();

				checkExpectedDeliveryDate(deliveryDate);

				String shipmentNumber = utility.generateUniqueCode(order.getName());

				List<StockMovementItem> list = new ArrayList<>();

				items.stream().forEach(p -> {

					String productName = p.getProduct();

					StockMovementItem orderItem = checkUserProductShippingStatus(productName, filteredList);

					List<InventoryItem> inventoryItem = inventoryItemRepository.findByLotNumberIn(p.getLotNumber());

					checkLotNumberBelongsToSameProduct(inventoryItem, productName);

					Long requireQuantity = p.getQuantity();

					Long orderQty = orderItem.getQuantity();

					shippingQuantityCheck(requireQuantity, orderQty);

					Long totalAvailableQuantity = inventoryItem.stream().mapToLong(InventoryItem::getQuantityOnHand)
							.sum();

					checkAvailableQuantity(totalAvailableQuantity, requireQuantity);

					processInventoryItems(inventoryItem, requireQuantity);

					orderItem.setShippedQuantity(requireQuantity);
					orderItem.setStockMovement(order);
					orderItem.setShipmentNumber(shipmentNumber);

					Double cost = orderItem.getProduct().getAverageUnitPrice() == null ? 1
							: orderItem.getProduct().getAverageUnitPrice();

					Double totalValue = p.getQuantity() * cost;

					orderItem.setTotalValue(totalValue);
					orderItem.setCreatedBy(currentUser.getUsername());
					orderItem.setStatus(Constants.SHIPPED);
					orderItem.setExpectedDeliveryDate(stockMovementShippingDto.getExpectedDeliveryDate());
					orderItem.setShippedby(currentUser);
					orderItem.setShippedDate(LocalDate.now());
					orderItem.setDriverName(stockMovementShippingDto.getDriverName());
					orderItem.setShipmentTypeName(stockMovementShippingDto.getShipmentType());

					orderItem.setAdditionalInformation(stockMovementShippingDto.getAdditionalInformation());

					list.add(orderItem);

				});

				stockMovementItemRepository.saveAll(list);

				List<StockMovementItem> saveditems = stockMovementItemRepository
						.findStockMovementItemByStockMovementId(order.getId());

				int numberOfItems = (int) saveditems.stream().filter(
						i -> i.getStatus().equals(Constants.SHIPPED) || i.getStatus().equals(Constants.RECEIVED))
						.count();

				setStatus(saveditems, numberOfItems, order);

				StockMovement savedOrder = stockMovementRepository.save(order);

				StockMovementResponseDto result = entityToDto(savedOrder);

				response.setData(result);
				response.setMessage(env.getProperty("stock.movement.shipped.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.CREATED.value());
				return response;

			}

			return utility.errorResponse(response, HttpStatus.ALREADY_REPORTED,
					"stock.movement.shipment.error.message");

		} catch (Exception exp) {
			log.error("Exception Occurred in shipStockMovement Method present in StockMovementServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());

			return response;
		}

	}

	public void setStatus(List<StockMovementItem> saveditems, int numberOfItems, StockMovement order) {

		if (saveditems.size() == numberOfItems) {

			if (order.getStatus().equals(Constants.PARTIALLY_SHIPPED) || order.getStatus().equals(Constants.PENDING)) {
				order.setStatus(Constants.SHIPPED);
			}

		} else {
			if (order.getStatus().equals(Constants.SHIPPED) || order.getStatus().equals(Constants.PENDING)) {
				order.setStatus(Constants.PARTIALLY_SHIPPED);
			}
		}
	}

	@Override
	public StockMovementItem checkUserProductShippingStatus(String productName, List<StockMovementItem> filteredList) {

		Optional<Product> optionalProduct = productRepository.findByName(productName);

		StockMovementItem result = new StockMovementItem();

		if (optionalProduct.isPresent()) {
			Product product = optionalProduct.get();

			List<StockMovementItem> optionalP = filteredList.stream().filter(i -> i.getProduct().equals(product))
					.toList();

			if (optionalP.isEmpty()) {
				throw new BadApiRequestException(env.getProperty(PRODUCT_ALREADY_SHIPPED));

			}

			result = optionalP.get(0);
		}

		return result;
	}

	@Override
	public StockMovement getStockMovement(String orderName) {

		Optional<StockMovement> optionalOrder = stockMovementRepository.findByName(orderName);

		if (optionalOrder.isEmpty()) {
			throw new BadApiRequestException(env.getProperty(ORDER_NOT_FOUND));
		}

		StockMovement order = optionalOrder.get();

		if (order.getStatus().equals(Constants.CANCEL)) {
			throw new BadApiRequestException(env.getProperty(ORDER_CANCELLED));
		}

		return order;
	}

	@Override
	public Location checkOriginLocation(StockMovementDto stockMovementDto) {

		Optional<Location> findOriginByName = locationRepository.findByName(stockMovementDto.getOrigin().getName());

		if (!findOriginByName.isPresent()) {

			throw new BadApiRequestException(env.getProperty("stocklist.location.origin.error.message"));
		}

		return findOriginByName.get();
	}

	@Override
	public Location checkDestinationLocation(StockMovementDto stockMovementDto) {

		Optional<Location> findDestinationByName = locationRepository
				.findByName(stockMovementDto.getDestination().getName());

		if (!findDestinationByName.isPresent()) {

			throw new BadApiRequestException(env.getProperty("stocklist.location.destination.error.message"));
		}

		return findDestinationByName.get();
	}

	@Override
	public void productListCannotBeNull(Collection<StockMovementItemDto> items) {
		if (items.isEmpty()) {
			throw new BadApiRequestException(env.getProperty("stock.movement.item.fetch.error.message"));
		}
	}

	private User checkRequestedUserIsPresent(StockMovementDto stockMovementDto) {

		Optional<User> findRequestedByByUsername = userRepository
				.findByUsername(stockMovementDto.getRequestedBy().getUsername());

		if (!findRequestedByByUsername.isPresent()) {

			throw new BadApiRequestException(env.getProperty("stocklist.location.destination.error.message"));
		}

		return findRequestedByByUsername.get();
	}

	User getPresentUser(Principal principal) {

		Optional<User> optionalUser = userRepository.findByUsername(principal.getName());

		if (optionalUser.isEmpty()) {

			throw new BadApiRequestException(env.getProperty("userdetails.fetch.error.message"));
		}

		return optionalUser.get();
	}

	@Transactional
	private void processInventoryItems(List<InventoryItem> inventoryItem, Long requireQuantity) {

		for (InventoryItem item : inventoryItem) {
			Long quantityOnHand = item.getQuantityOnHand();

			if (quantityOnHand >= requireQuantity) {

				Long balance = quantityOnHand - requireQuantity;
				item.setQuantityOnHand(balance);

				return;
			} else {

				requireQuantity -= quantityOnHand;
				item.setQuantityOnHand(0L);
			}
		}
	}

	private void checkExpectedDeliveryDate(LocalDate deliveryDate) {

		if (deliveryDate.isBefore(LocalDate.now())) {
			throw new BadApiRequestException(env.getProperty("delivery.date.error.message"));
		}
	}

	private void checkAvailableQuantity(Long totalAvailableQuantity, Long requireQuantity) {

		if (totalAvailableQuantity < requireQuantity) {
			throw new BadApiRequestException(env.getProperty("product.availability.error.message"));
		}
	}

	private void checkLotNumberBelongsToSameProduct(List<InventoryItem> items, String productName) {

		if (items.isEmpty()) {
			throw new BadApiRequestException(env.getProperty("lot.wrong.error.message"));
		}

		List<InventoryItem> check = items.stream()
				.filter(i -> i.getProductAvailability().getProduct().getName().equals(productName)).toList();

		if (check.isEmpty()) {
			throw new BadApiRequestException(env.getProperty("lot.wrong.error.message"));
		}
	}

	private void shippingQuantityCheck(Long requireQuantity, Long orderQty) {

		if (requireQuantity > orderQty) {
			throw new BadApiRequestException(env.getProperty("stock.movement.quantity.error.message"));
		}

	}

	@Override
	public StockMovementResponseDto entityToDto(StockMovement stockMovement) {

		List<StockMovementItem> savedOrderItems = stockMovementItemRepository
				.findStockMovementItemByStockMovementId(stockMovement.getId());

		List<StockMovementItemResponseDto> listDto = savedOrderItems.stream().map(StockMovementItemResponseDto::new)
				.toList();

		return new StockMovementResponseDto(stockMovement, listDto);
	}

	@Override
	public ApiResponse<List<TopDemandingProductResponseDto>> getTopDemandingProducts(String location,
			String organization, LocalDate dateFrom, LocalDate dateTo, Long recordsCount) {

		ApiResponse<List<TopDemandingProductResponseDto>> response = new ApiResponse<>();

		if (recordsCount == null || recordsCount == 0) {
			recordsCount = 10l;
		}

		LocalDate dateNow = LocalDate.now();

		if (dateFrom == null && dateTo == null) {

			dateTo = dateNow;
			dateFrom = dateTo.minusDays(30);
		}

		if (dateFrom == null || dateTo == null) {
			throw new BadApiRequestException(env.getProperty("top.demanding.date.error.message"));

		}

		if (dateTo.isBefore(dateFrom)) {
			throw new BadApiRequestException(env.getProperty("top.demanding.date.error.message"));
		}

		List<Object[]> result = stockMovementRepository.getTopDemandingProducts(location, organization, dateFrom,
				dateTo, recordsCount);

		if (result.isEmpty()) {

			return utility.errorResponse(response, HttpStatus.NOT_FOUND, "top.demanding.null.message");
		}

		List<TopDemandingProductResponseDto> list = new ArrayList<>();

		result.stream().forEach(i -> {

			String productName = (String) i[0];
			String locationName = (String) i[1];
			String orgName = (String) i[2];
			BigDecimal qty = (BigDecimal) i[3];

			TopDemandingProductResponseDto p = new TopDemandingProductResponseDto(productName, locationName, orgName,
					qty.longValue());

			list.add(p);
		});

		response.setData(list);
		response.setMessage(env.getProperty("top.demanding.fetch.success.message"));
		response.setResult(true);
		response.setStatus(HttpStatus.OK.value());

		return response;
	}

	@Override
	public ApiResponse<NumberOfQuantity> getPendingMovementCounts(String origin) {
		ApiResponse<NumberOfQuantity> response = new ApiResponse<>();
		try {
			NumberOfQuantity numberOfItem = stockMovementRepository.getPendingStockMovement(origin);

			if (numberOfItem != null) {

				response.setMessage(env.getProperty("stock.movement.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(numberOfItem);
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "order.item.fetch.error.message");
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in getPendingMovementCounts Method present in StockMovementServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

}
