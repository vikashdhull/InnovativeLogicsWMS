package com.innovative.logics.wms.dto;

import java.time.LocalDate;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StockMovementShippingDto {
	
	private String stockMovementName;

	private String shipmentType;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate expectedDeliveryDate;

	private String driverName;

	private String additionalInformation;
	
	private Map<String, StockMovementItemDto> items;
		
}
