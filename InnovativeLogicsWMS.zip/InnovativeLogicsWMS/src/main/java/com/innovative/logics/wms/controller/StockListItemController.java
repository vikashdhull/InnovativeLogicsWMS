package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.StockListItemDto;
import com.innovative.logics.wms.dto.response.StockListItemResponseDto;
import com.innovative.logics.wms.service.StockListItemService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/stocklistitem")
@Slf4j
public class StockListItemController {

	@Autowired
	private StockListItemService stockListItemService;

	/**
	 * 
	 * The createStockListItem method is used to create the StockListItem and save
	 * the data in requisition_item table based on given details.
	 * 
	 * @author abhineets
	 * @date 08-SEP-2023
	 * @param stockListItemDto
	 * @return
	 */

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<StockListItemResponseDto>> createStockListItem(
			@Valid @RequestBody final StockListItemDto stockListItemDto) {
		log.info("Enter in createStockList Method present in StockListItemController class");
		ApiResponse<StockListItemResponseDto> response = stockListItemService.createStockListItem(stockListItemDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The getAllStockListItem method is used to fetch all the StockListItem by
	 * given id from the requisition_item table
	 * 
	 * @author abhineets
	 * @date 08-SEP-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<List<StockListItemResponseDto>>> getAllStockListItem(@PathVariable("id") String id) {
		log.info("Enter in getAllStockListItem Method present in StockListItemController class");
		ApiResponse<List<StockListItemResponseDto>> response = stockListItemService.getAllStockListItemByStockListId(id);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The updateStockListItem method is used to update the StockListItem based on
	 * id
	 * 
	 * @author abhineets
	 * @date 8-Sep-2023
	 * @param stockListItemDto
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<StockListItemResponseDto>> updateStockListItem(
			@Valid @RequestBody final StockListItemDto stockListItemDto, @PathVariable("id") String id) {
		log.info("Enter in updateStockList Method present in StockListItemController class");
		ApiResponse<StockListItemResponseDto> response = stockListItemService.updateStockListItemById(stockListItemDto, id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The deleteStockListItem method is used to delete the StockListItem based on id
	 * @author abhineets
	 * @date 8-Sep-2023
	 * @param id
	 * @return
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<StockListItemResponseDto>> deleteStockListItem(@PathVariable("id") String id) {
		log.info("Enter in deleteStockListItem Method present in StockListItemController class");
		ApiResponse<StockListItemResponseDto> response = stockListItemService.deleteStockListItemById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
