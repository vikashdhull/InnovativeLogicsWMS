package com.innovative.logics.wms.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.util.IOUtils;
import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PartyDto;
import com.innovative.logics.wms.dto.RoleDto;
import com.innovative.logics.wms.entity.Party;
import com.innovative.logics.wms.entity.PartyType;
import com.innovative.logics.wms.entity.Role;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.exception.ResourceNotFoundException;
import com.innovative.logics.wms.repository.LocationRepository;
import com.innovative.logics.wms.repository.OrderRepository;
import com.innovative.logics.wms.repository.PartyRepository;
import com.innovative.logics.wms.repository.PartyTypeRepository;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.repository.ProductSourceRepository;
import com.innovative.logics.wms.repository.RoleRepository;
import com.innovative.logics.wms.repository.UserRepository;
import com.innovative.logics.wms.service.PartyService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PartyServiceImpl implements PartyService {

	@Autowired
	private Environment env;

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	private PartyRepository partyRepository;

	@Autowired
	private PartyTypeRepository partyTypeRepository;
	
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private LocationRepository locationRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ProductSourceRepository productSourceRepository;

	@Autowired
	private OrderRepository orderRepository;

	@Value("${aws.s3.bucket}")
	private String uploadLogo;
	
	@Value("${aws.s3.logo.path}")
	private String logoPath;

	@Autowired
	private AmazonS3 s3Client;

	@Autowired
	private Utility utility;

	private String partyFetchError = "party.fetch.error.message";

	private String partyFetchSuccess = "party.fetch.success.message";

	@Override
	public ApiResponse<PartyDto> createParty(PartyDto partyDto, MultipartFile orgLogo) {
		Optional<Party> existPartyByName = partyRepository.findByName(partyDto.getName());
		Optional<Party> existPartyByCode = partyRepository.findByCode(partyDto.getCode());

		ApiResponse<PartyDto> response = new ApiResponse<>();

		try {
			if (existPartyByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "party.name.create.error.message");
			} else if (existPartyByCode.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "party.code.create.error.message");
			} else {

				Party party = modelMapper.map(partyDto, Party.class);
				Optional<PartyType> partyType = partyTypeRepository.findByName(partyDto.getPartyType().getName());
				if (partyType.isPresent()) {
					PartyType partyType2 = partyType.get();
					party.setPartyType(partyType2);
				} else {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, "party.type.not.found.message");
				}
				List<Role> roles = roleRepository
						.findByRoleNameIn(partyDto.getRole().stream().map(RoleDto::getRoleName).toList());
				if (roles.size() != partyDto.getRole().size()) {
					return utility.errorResponse(response, HttpStatus.NOT_FOUND, "role.fetch.error.message");
				}
				generateFileName(orgLogo, party);

				party.setRole(new HashSet<>(roles));
				Party savedParty = partyRepository.save(party);
				PartyDto newDto = modelMapper.map(savedParty, PartyDto.class);

				response.setData(newDto);
				response.setResult(true);
				response.setMessage(env.getProperty("party.create.success.message"));
				response.setStatus(HttpStatus.CREATED.value());
				return response;
			}
		} catch (Exception e) {
			log.error("Exception in create party method present in PartyServiceImpl class{}", e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private void generateFileName(MultipartFile file, Party party) {
		String originalFilename = file.getOriginalFilename();
		File convertMultipartFileToFile = convertMultipartFileToFile(file);
		log.info("originalFilename : {}", originalFilename);

		if (originalFilename != null
				&& !(originalFilename.toLowerCase().endsWith(".png") || originalFilename.toLowerCase().endsWith(".jpeg")
						|| originalFilename.toLowerCase().endsWith(".jpg"))) {

			throw new IllegalArgumentException("Invalid image file extension. Only 'PNG', 'JPEG', 'JPG' are allowed.");
		}
		String filename = UUID.randomUUID().toString() + "-" + originalFilename;
		s3Client.putObject(new PutObjectRequest(uploadLogo, logoPath+filename, convertMultipartFileToFile));
		convertMultipartFileToFile.delete();
		party.setOrgLogo(filename);
	}

	private File convertMultipartFileToFile(MultipartFile file) {

		File convertedFile = new File(file.getOriginalFilename());
		try (FileOutputStream fos = new FileOutputStream(convertedFile)) {
			fos.write(file.getBytes());
		} catch (Exception e) {
			log.error("Error Converting multipart file to file" + e);
		}
		return convertedFile;
	}

	public byte[] downloadFile(String filename) {
		S3Object s3Object = s3Client.getObject(uploadLogo, logoPath+filename);
		S3ObjectInputStream inputStream = s3Object.getObjectContent();
		try {
			return IOUtils.toByteArray(inputStream);
		} catch (Exception e) {
			log.error("Error in downloadFile method for downloading multipart file" + e);
		}
		return new byte[0];
	}

	public void deleteFile(String filename) {
		s3Client.deleteObject(uploadLogo, logoPath+filename);
	}

	@Override
	public ApiResponse<PartyDto> updateParty(PartyDto partyDto, String partyId, MultipartFile orgLogo)
			throws IOException {
		ApiResponse<PartyDto> response = new ApiResponse<>();

		Optional<Party> party = partyRepository.findById(partyId);

		Optional<Party> existPartyByName = partyRepository.findByName(partyDto.getName());
		Optional<Party> existPartyByCode = partyRepository.findByCode(partyDto.getCode());

		try {
			if (party.isPresent()) {
				Party partyData = party.get();
				if (existPartyByName.isPresent() && !Objects.equals(partyData.getName(), partyDto.getName())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "party.name.create.error.message");
				} else {
					partyData.setName(partyDto.getName());
				}
				if (existPartyByCode.isPresent() && !Objects.equals(partyData.getCode(), partyDto.getCode())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "party.code.create.error.message");
				} else {

					partyData.setCode(partyDto.getCode());
				}
				partyData.setDescription(partyDto.getDescription());

				Optional<PartyType> partyType = partyTypeRepository.findByName(partyDto.getPartyType().getName());

				setPartyType(partyData, partyType);
				checkAndUpdateRoles(partyDto, partyData);

				if (orgLogo != null) {
					deleteFile(partyData.getOrgLogo());
					generateFileName(orgLogo, partyData);
				} else {
					partyData.setOrgLogo(partyData.getOrgLogo());
				}

				Party updatedParty = partyRepository.save(partyData);
				PartyDto updatedDto = modelMapper.map(updatedParty, PartyDto.class);
				response.setData(updatedDto);
				response.setResult(true);
				response.setMessage(env.getProperty("party.update.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, partyFetchError);
			}
		} catch (Exception e) {
			log.error("Exception in update Party method present in PartyServiceImpl class{}", e.getMessage());
			response.setMessage(e.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<PartyDto> deletePartyById(String partyId) {
		ApiResponse<PartyDto> response = new ApiResponse<>();
		try {

			Optional<Party> partyDetails = partyRepository.findById(partyId);

			if (partyDetails.isPresent()) {
				Party party = partyDetails.get();
				boolean partyInUse = checkIfPartyInUse(partyId);
				if (partyInUse) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "delete.use.error.message");
				}
				partyRepository.deleteById(partyId);
				deleteFile(party.getOrgLogo());
				response.setMessage(env.getProperty("party.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, partyFetchError);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteParty Method present in PartyServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private boolean checkIfPartyInUse(String partyId) {

		boolean existByOrganizationId = locationRepository.existByOrganizationId(partyId);
		boolean existPartyInProduct = productRepository.existPartyInProduct(partyId);
		boolean existPartyInProductSource = productSourceRepository.existPartyInProductSource(partyId);
		boolean existOriginPartyInOrder = orderRepository.existOriginPartyInOrder(partyId);
		boolean existDestinationPartyInOrder = orderRepository.existDestinationPartyInOrder(partyId);
		boolean existByOrganization = userRepository.existByOrganization(partyId);
		return existByOrganizationId || existPartyInProduct || existPartyInProductSource || existOriginPartyInOrder
				|| existDestinationPartyInOrder || existByOrganization;
	}

	@Override
	public ApiResponse<PartyDto> getPartyById(String partyId) {
		ApiResponse<PartyDto> response = new ApiResponse<>();
		try {
			Optional<Party> party = partyRepository.findById(partyId);

			if (party.isPresent()) {
				response.setMessage(env.getProperty(partyFetchSuccess));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(modelMapper.map(party.get(), PartyDto.class));
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, partyFetchError);
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getPartyById Method present in PartyServiceImpl class{}", exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public PageableResponse<PartyDto> getAllParty(int pageNumber, int pageSize, String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<Party> page = partyRepository.findAll(pageable);

		PageableResponse<PartyDto> response = utility.getPageableResponse(page, PartyDto.class);
		try {
			if (!response.getData().isEmpty()) {

				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, partyFetchError);
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getAllParty Method present in PartyServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	@Override
	@Transactional
	public PageableResponse<PartyDto> searchParty(String keyword, int pageNumber, int pageSize, String sortBy,
			String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<Party> party = partyRepository.findByNameContaining(keyword, pageable);

		PageableResponse<PartyDto> response = utility.getPageableResponse(party, PartyDto.class);
		try {
			if (!response.getData().isEmpty()) {

				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, partyFetchError);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in searchParty Method present in PartyServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private void checkAndUpdateRoles(PartyDto partyDto, Party partyData) {
		List<Role> roles = roleRepository
				.findByRoleNameIn(partyDto.getRole().stream().map(RoleDto::getRoleName).toList());
		if (roles.size() != partyDto.getRole().size()) {
			throw new ResourceNotFoundException(env.getProperty("role.fetch.error.message"));
		} else {
			partyData.setRole(new HashSet<>(roles));
		}
	}

	private void setPartyType(Party party, Optional<PartyType> partyType) {
		if (partyType.isPresent()) {
			party.setPartyType(partyType.get());
		} else {
			throw new BadApiRequestException(env.getProperty("party.type.not.found.message"));
		}
	}

	@Override
	public ApiResponse<List<PartyDto>> getPartyByRole(String roleName) {
		ApiResponse<List<PartyDto>> response = new ApiResponse<>();

		try {
			List<Party> parties = partyRepository.findPartyByRoleName(roleName);
			List<PartyDto> partyDtos = parties.stream().map(party -> modelMapper.map(party, PartyDto.class)).toList();

			if (!parties.isEmpty()) {
				response.setData(partyDtos);
				response.setResult(true);
				response.setMessage(env.getProperty(partyFetchSuccess));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, partyFetchError);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getPartyByRole Method present in PartyServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<List<PartyDto>> getAllParties() {
		ApiResponse<List<PartyDto>> response = new ApiResponse<>();

		try {
			List<Party> parties = partyRepository.findAll();
			List<PartyDto> partyDtos = parties.stream().map(party -> modelMapper.map(party, PartyDto.class)).toList();

			if (!parties.isEmpty()) {
				response.setData(partyDtos);
				response.setResult(true);
				response.setMessage(env.getProperty(partyFetchSuccess));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, partyFetchError);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getAllParties Method present in PartyServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ByteArrayResource getOrgLogo(String partyName) throws IOException {

		if (partyName != null) {
			Optional<Party> party = partyRepository.findByName(partyName);

			if (party.isPresent()) {
				Party receiveParty = party.get();
				String orgLogoName = receiveParty.getOrgLogo();
				if (orgLogoName != null) {
					byte[] downloadFile = downloadFile(orgLogoName);
					return new ByteArrayResource(downloadFile);
				} else {
					throw new ResourceNotFoundException("logo not found");
				}
			} else {
				throw new ResourceNotFoundException("logoName is not exists");
			}

		} else {
			throw new ResourceNotFoundException("partyName should not be null");
		}
	}

}
