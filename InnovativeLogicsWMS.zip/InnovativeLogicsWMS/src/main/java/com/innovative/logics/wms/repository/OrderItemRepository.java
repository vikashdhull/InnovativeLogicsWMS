package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.OrderItem;

public interface OrderItemRepository extends JpaRepository<OrderItem, String> {

	final String FIND_ORDER_ITEM_BY_ORDER_ID = "SELECT oi.* FROM order_items oi WHERE oi.order_id = :orderId";

	@Query(value = FIND_ORDER_ITEM_BY_ORDER_ID, nativeQuery = true)
	OrderItem findOrderItemByOrder(String orderId);

	Optional<OrderItem> findByLot(String lot);

	@Query(value = FIND_ORDER_ITEM_BY_ORDER_ID, nativeQuery = true)
	Optional<OrderItem> findPurchaseOrderByOrder(String orderId);

	// to get multiple product items
	@Query(value = FIND_ORDER_ITEM_BY_ORDER_ID, nativeQuery = true)
	List<OrderItem> findPurchaseOrderByOrderId(String orderId);

}
