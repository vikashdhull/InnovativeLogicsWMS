package com.innovative.logics.wms.dto;

import java.time.LocalDateTime;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InventoryStatusDto {
	
	private String id;

	private ProductDto product;

	private LocationDto location;
	
	@JsonIgnore
	private Set<StockRecordDto> inventoryItem;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
