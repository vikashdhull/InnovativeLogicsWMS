package com.innovative.logics.wms.dto.response;

public interface NumberOfQuantity {

	Integer getNumberOfCount();

}
