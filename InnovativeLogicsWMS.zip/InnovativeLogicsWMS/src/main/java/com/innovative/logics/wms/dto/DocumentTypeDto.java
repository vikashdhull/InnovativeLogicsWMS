package com.innovative.logics.wms.dto;

import java.time.LocalDateTime;


import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentTypeDto {

	private String id;

	@NotNull(message = "Name should not be null")
	@Size(max = 30 , message = "Name maximum 30 characters long")
	private String name;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;
}
