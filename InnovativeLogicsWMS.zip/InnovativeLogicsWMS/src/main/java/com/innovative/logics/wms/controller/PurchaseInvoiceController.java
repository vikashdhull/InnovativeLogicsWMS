package com.innovative.logics.wms.controller;

import java.security.Principal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.InvoiceDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.PurchaseInvoiceResponseDto;
import com.innovative.logics.wms.entity.Order;
import com.innovative.logics.wms.repository.OrderRepository;
import com.innovative.logics.wms.service.PurchaseInvoiceService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;


/**
 * The PurchaseInvoiceController class defines the REST endpoints for creating
 * and retrieving invoice entities.Endpoints are secured with
 * Spring Security's @PreAuthorize annotation to ensure that only authorized
 * users can perform CRUD operations on purchase invoices.
 * 
 * @author manus
 * @date 02-Jan-2024
 */

@RestController
@RequestMapping("/invoice")
@Slf4j
public class PurchaseInvoiceController {

	@Autowired
	private PurchaseInvoiceService purchaseInvoiceService;
	
	@Autowired
	OrderRepository orderRepository;

	/**
	 * 
	 * The createPurchaseInvoice method is used to create the invoice based on given details.
	 * 
	 * @author manus
	 * @date 26-Dec-2023
	 * @param invoiceDto
	 * @return ResponseEntity containing an ApiResponse with the PurchaseInvoiceResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<PurchaseInvoiceResponseDto>> createPurchaseInvoice(
			@Valid @RequestBody final InvoiceDto invoiceDto, Principal principal) {
		
		ApiResponse<PurchaseInvoiceResponseDto> errorResponse = new ApiResponse<>();
		log.info("Enter in createInvoice Method present in PurchaseInvoiceController class");
		
		Optional<Order> findOrderByName = orderRepository.findByName(invoiceDto.getOrder());
		
		if (findOrderByName.isPresent()) {

			Order order = findOrderByName.get();
		
		ApiResponse<PurchaseInvoiceResponseDto> response = purchaseInvoiceService.createPurchaseInvoice(order, principal);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
		}
		else {
			errorResponse.setMessage("order.fetch.error.message");
			errorResponse.setResult(false);
			errorResponse.setStatus(HttpStatus.NOT_FOUND.value());		
			return new ResponseEntity<>(errorResponse, HttpStatus.valueOf(errorResponse.getStatus()) );
		}
	}

	/**
	 * 
	 * The getAllPurchaseInvoiceByDestination method is used to get the all invoices page wise based on given destination and page.
	 * 
	 * @author manus
	 * @date 28-Dec-2023
	 * @param destination
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return ResponseEntity containing an PageableResponse with the PurchaseInvoiceResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/location")
	public ResponseEntity<PageableResponse<PurchaseInvoiceResponseDto>> getAllPurchaseInvoiceByDestination(
			@RequestParam(value = "destination", required = true) String destination,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "invoiceNumber", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllPurchaseInvoiceByDestination Method present in PurchaseInvoiceController class");
		PageableResponse<PurchaseInvoiceResponseDto> response = purchaseInvoiceService.getAllPurchaseInvoiceByDestination(destination,
				pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getPurchaseInvoiceByPurchaseOrderId method is used to get the invoice based on given orderId.
	 * 
	 * @author manus
	 * @date 30-Dec-2023
	 * @param purchaseOrderId
	 * @return ResponseEntity containing an ApiResponse with the PurchaseInvoiceResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/order/{id}")
	public ResponseEntity<ApiResponse<PurchaseInvoiceResponseDto>> getPurchaseInvoiceByPurchaseOrderId(@PathVariable("id") final String orderId) {
		log.info("Enter in getPurchaseInvoiceByPurchaseOrder Method present in PurchaseInvoiceController class");
		ApiResponse<PurchaseInvoiceResponseDto> response = purchaseInvoiceService.getPurchaseInvoiceByPurchaseOrder(orderId);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	/**
	 * 
	 * The getPurchaseInvoiceByInvoiceId method is used to get the invoice based on given invoiceId.
	 * 
	 * @author manus
	 * @date 17-Jan-2024
	 * @param invoiceId
	 * @return ResponseEntity containing an ApiResponse with the PurchaseInvoiceResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<PurchaseInvoiceResponseDto>> getPurchaseInvoiceByInvoiceId(@PathVariable("id") final String invoiceId) {
		log.info("Enter in getPurchaseInvoiceByInvoiceId Method present in PurchaseInvoiceController class");
		ApiResponse<PurchaseInvoiceResponseDto> response = purchaseInvoiceService.getPurchaseInvoiceByInvoiceId(invoiceId);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	 
}
