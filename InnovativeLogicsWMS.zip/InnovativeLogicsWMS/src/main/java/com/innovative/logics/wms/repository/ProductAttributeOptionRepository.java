package com.innovative.logics.wms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.Product;
import com.innovative.logics.wms.entity.ProductAttributeOption;

public interface ProductAttributeOptionRepository extends JpaRepository<ProductAttributeOption, String> {

	final String EXIST_ATTRIBUTE = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM product_attribute_options pa WHERE pa.attribute_id = :attributeId";

	List<ProductAttributeOption> findByProductIn(List<Product> content);

	@Query(value = EXIST_ATTRIBUTE, nativeQuery = true)
	boolean existAttributeInProduct(String attributeId);

}
