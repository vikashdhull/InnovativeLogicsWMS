package com.innovative.logics.wms.dto.response;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductSourceResponseDto {

	private String id;

	@NotNull(message = "Code should not be null")
	private String code;

	@NotNull(message = "Name should not be null")
	private String name;

	private String description;

	private String productName;
	
	private String productCode;

	private String supplierName;
	
	private String supplierCode;

	private String manufacturerName;
	
	private String manufacturerCode;

	private Double contractPrice;

	private LocalDate contractValidUntil;

	private Long minOrderQuantity;

	private String ratingType;

	private String preferenceType;
	
	private String org;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
