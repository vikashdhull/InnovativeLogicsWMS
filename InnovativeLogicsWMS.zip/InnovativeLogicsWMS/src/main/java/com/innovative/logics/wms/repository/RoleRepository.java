package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.Role;

public interface RoleRepository extends JpaRepository<Role, String> {

	Optional<Role> findByRoleName(String roleName);

	List<Role> findByRoleNameIn(List<String> roleNames);

	List<Role> findByRoleCode(String roleCode);

	@Query(value = "SELECT r.role_name FROM role r LEFT JOIN user_role ur ON r.id = ur.role LEFT JOIN users u ON u.id = ur.user WHERE u.username =:username", nativeQuery = true)
	Role findRoleByUsername(String username);
}
