package com.innovative.logics.wms.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductDto;
import com.innovative.logics.wms.dto.response.NumberOfQuantity;
import com.innovative.logics.wms.dto.response.ProductResponseDto;

public interface ProductService {

	/**
	 * 
	 * This method is used to create the Product based on given details
	 * 
	 * @author manus
	 * @date 16-Aug-2023
	 * @param productDto
	 * @return
	 */
	ApiResponse<ProductResponseDto> createProduct(ProductDto productDto);

	/**
	 * 
	 * The updateProduct method is used to update the Product details based on id
	 * 
	 * @author manus
	 * @date 25-Aug-2023
	 * @param productDto
	 * @param productId
	 * @return
	 */
	ApiResponse<ProductResponseDto> updateProduct(ProductDto productDto, String productId);

	ApiResponse<ProductResponseDto> deleteProductById(String productId);

	/**
	 * 
	 * The getProductById method is used to fetch the single Product details based
	 * on id
	 * 
	 * @author manus
	 * @date 22-Aug-2023
	 * @param productId
	 * @return
	 */
	ApiResponse<ProductResponseDto> getProductById(String productId);

	/**
	 * 
	 * The getAllProduct method is used to fetch all the Products
	 * 
	 * @author manus
	 * @date 23-Aug-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<ProductResponseDto> getAllProduct(String org, int pageNumber, int pageSize, String sortBy, String sortDir);

	PageableResponse<ProductDto> searchProduct(String org, String keyword, int pageNumber, int pageSize, String sortBy,
			String sortDir);

	PageableResponse<ProductResponseDto> getProductByCatalog(String productCatalog, int pageNumber, int pageSize,
			String sortBy, String sortDir);

	ApiResponse<ProductResponseDto> uploadDocumentInProduct(String productId, MultipartFile file, String documentDto);

	ApiResponse<ProductResponseDto> deleteDocumentByIdFromProduct(String productId, String documentId);

	/**
	 * 
	 * This method is used to count all the Product
	 * 
	 * @author manus
	 * @date 04-Oct-2023
	 * @return
	 */
	ApiResponse<NumberOfQuantity> getProductInHand(String org);

	/**
	 * 
	 * This method is used to fetch all the active Products
	 * 
	 * @author manus
	 * @date 12-Oct-2023
	 * @return
	 */
	ApiResponse<List<ProductResponseDto>> getAllActiveProducts();
	
	ApiResponse<List<ProductResponseDto>> getAllProductsByOrganization(String orgnization);
	
	ApiResponse<List<ProductResponseDto>> getAllActiveProductsByOrganization(String orgnization);
}
