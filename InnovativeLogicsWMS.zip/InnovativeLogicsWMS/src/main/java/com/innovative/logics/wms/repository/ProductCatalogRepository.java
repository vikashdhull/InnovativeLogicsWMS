package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.ProductCatalog;

public interface ProductCatalogRepository extends JpaRepository<ProductCatalog, String> {
	
	final String GET_ALL_ACTIVE_PRODUCT_CATALOG = "SELECT pc.* FROM product_catalog pc LEFT JOIN party org ON org.id = pc.organization_id WHERE pc.active = true and org.name =:name";
	
	Optional<ProductCatalog> findByName(String name);
	
	Optional<ProductCatalog> findByCode(String code);
	
	@Query(value = GET_ALL_ACTIVE_PRODUCT_CATALOG, nativeQuery = true)
	List<ProductCatalog> getAllActiveProductCatalogsByOrg(String name);
	
	@Query(value = "SELECT pc FROM ProductCatalog pc WHERE pc.party.name =:name")
	Page<ProductCatalog> findCategoriesByParty(String name, Pageable pageable);

}
