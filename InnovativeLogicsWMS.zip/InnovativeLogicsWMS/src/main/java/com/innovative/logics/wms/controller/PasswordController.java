package com.innovative.logics.wms.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.ChangePasswordDto;
import com.innovative.logics.wms.dto.PasswordDto;
import com.innovative.logics.wms.dto.ResetPasswordRequestDto;
import com.innovative.logics.wms.service.PasswordService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class PasswordController {

	@Autowired
	private PasswordService passwordService;

	/**
	 * 
	 * The forgotPassword method is used to send the OTP on the email
	 * 
	 * @author manus
	 * @date 19-Apr-2023
	 * @param dto
	 * @return ApiResponse containing the ForgotPasswordDto.
	 */
	@PostMapping("/forgot-password")
	public ResponseEntity<ApiResponse<PasswordDto>> forgotPassword(final @RequestBody PasswordDto dto, HttpServletRequest servletRequest) {
		log.info("Enter in forgotPassword Method present in PasswordController class");
		ApiResponse<PasswordDto> response = passwordService.forgotPassword(dto, servletRequest);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	/**
	 * 
	 * The resetPassword method is used to reset the password using OTP
	 * 
	 * @author manus
	 * @date 21-Apr-2023
	 * @param resetPasswordRequestDto
	 * @return ApiResponse containing the ResetPasswordRequestDto.
	 */
	@PostMapping("/reset-password")
	public ResponseEntity<ApiResponse<ResetPasswordRequestDto>> resetPassword(
			final @RequestBody ResetPasswordRequestDto resetPasswordRequestDto) {
		log.info("Enter in resetPassword Method present in PasswordController class");
		ApiResponse<ResetPasswordRequestDto> response = passwordService.resetPassword(resetPasswordRequestDto);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	/**
	 * 
	 * The changePassword method is used to update the password using Old password
	 * @author manus 
	 * @date 11-May-2023 
	 * @param changePasswordDto
	 * @param username
	 * @return
	 */
	@PreAuthorize(" hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	 @PostMapping("/change-password")
	    public ResponseEntity<ApiResponse<ChangePasswordDto>> changePassword(@Valid @RequestBody final ChangePasswordDto changePasswordDto, Principal principal){
		 log.info("Enter in changePassword Method present in PasswordController class");
			ApiResponse<ChangePasswordDto> response = passwordService.changePassword(principal.getName(), changePasswordDto);

			return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	    }

}
