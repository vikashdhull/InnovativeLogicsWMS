package com.innovative.logics.wms.exception;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DuplicateEmailException extends Exception{
	
	 /** long Short Description */
		private static final long serialVersionUID = 1791740603935826133L;

		public DuplicateEmailException(String message) {
			log.error(message);
		}

		public DuplicateEmailException(String message, Throwable throwable) {
			log.error(message, throwable);
		}

}
