package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.RoleDto;
import com.innovative.logics.wms.service.RoleService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * The RoleController class is a REST API controller that handles requests
 * related to Roles.The controller utilizes a RoleService instance for
 * performing operations related to roles.
 * 
 * @author manus
 * @date 15-Apr-2023
 */
@RestController
@RequestMapping("/roles")
@Slf4j
public class RoleController {

	@Autowired
	private RoleService roleService;

	/**
	 * The createRole method is used to create the Role and save the data in role
	 * table based on give details
	 * 
	 * @author manus
	 * @date 28-Feb-2023
	 * @param roleDto
	 * @return ResponseEntity containing an ApiResponse with the RoleDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN')")
	@PostMapping
	public ResponseEntity<ApiResponse<RoleDto>> createRole(@Valid @RequestBody final RoleDto roleDto) {
		log.info("Enter in createRole Method present in RoleController class");
		ApiResponse<RoleDto> response = roleService.createRole(roleDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The getRoleByRoleType method is used to fetch the single role from the user
	 * and person table based on role type
	 * 
	 * @author manus
	 * @date 01-Mar-2023
	 * @param id
	 * @return ResponseEntity containing an ApiResponse with the RoleDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@GetMapping("/{roleName}")
	public ResponseEntity<ApiResponse<RoleDto>> getRoleByRoleName(@PathVariable("roleName") final String roleName) {
		log.info("Enter in getRoleByRoleName Method present in RoleController class");
		ApiResponse<RoleDto> response = roleService.getRoleByRoleName(roleName);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAllRoles method is used to fetch the roles from the role table
	 * 
	 * @author manus
	 * @date 24-Mar-2023
	 * @return ResponseEntity containing an ApiResponse with list of RoleDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@GetMapping
	public ResponseEntity<ApiResponse<List<RoleDto>>> getAllRoles() {
		log.info("Enter in getAllRoles Method present in RoleController class");
		ApiResponse<List<RoleDto>> response = roleService.getAllRoles();

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	/**
	 * 
	 * The getRolesByCode method is used to fetch the roles from the role table
	 * 
	 * @author manus
	 * @date 27-Apr-2023
	 * @return ResponseEntity containing an ApiResponse with list of RoleDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@GetMapping("/codes/{roleCode}")
	public ResponseEntity<ApiResponse<List<RoleDto>>> getRolesByCode(@PathVariable("roleCode") final String roleCode) {
		log.info("Enter in getRolesByCode Method present in RoleController class");
		ApiResponse<List<RoleDto>> response = roleService.getRolesByCode(roleCode);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * Add method description here
	 * @author manus
	 * @date 27-Apr-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<RoleDto>> deleteRole(@PathVariable final String id) {
		log.info("Enter in deleteRole Method present in RoleController class");
		ApiResponse<RoleDto> response = roleService.deleteRole(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	/**
	 * 
	 * Add method description here
	 * @author manus 
	 * @date 19-May-2023 
	 * @param roleDto
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<RoleDto>> updateRole(@Valid @RequestBody final RoleDto roleDto, @PathVariable("id") final String id) {
		log.info("Enter in updateRole Method present in RoleController class");
		ApiResponse<RoleDto> response = roleService.updateRole(roleDto, id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
}
