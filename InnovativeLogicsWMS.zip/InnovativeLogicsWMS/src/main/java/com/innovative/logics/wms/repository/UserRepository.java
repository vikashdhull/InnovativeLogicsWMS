package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.innovative.logics.wms.entity.Person;
import com.innovative.logics.wms.entity.User;

public interface UserRepository extends JpaRepository<User, String> {

	final String SEARCH_DETAILS = "SELECT p.*, u.* FROM users u INNER JOIN person p ON (u.id = p.id) WHERE p.first_name LIKE CONCAT('%',:keyword,'%') or p.last_name LIKE CONCAT('%',:keyword,'%')";

	final String EXIST_ROLE = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM user_role ur WHERE ur.role = :roleId";

	final String EXIST_ORGANIZATION = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM users u WHERE u.organization_id =:organizationId";

	final String GET_ALL_ACTIVE_USERS_BY_ORGANIZATION = "SELECT u.* FROM users u LEFT JOIN party o ON u.organization_id = o.id WHERE u.active = true and u.is_user =true and o.name =:name";

	final String FIND_USER_BY_USERNAME_AND_PARTY = "SELECT u.* FROM users u JOIN party p ON u.organization_id = p.id WHERE u.username = :username and p.name = :party";
	
	List<User> findByPartyName(String name);

	Optional<User> findByUsername(String username);

	Optional<User> findByPerson(Person person);

	@Query(value = SEARCH_DETAILS, nativeQuery = true)
	Page<User> searchUserByName(@Param("keyword") String keyword, Pageable pageable);

	@Query(value = EXIST_ROLE, nativeQuery = true)
	boolean existByRoleId(String roleId);

	@Query(value = EXIST_ORGANIZATION, nativeQuery = true)
	boolean existByOrganization(String organizationId);

	@Query(value = GET_ALL_ACTIVE_USERS_BY_ORGANIZATION, nativeQuery = true)
	List<User> getAllActiveUsersByOrg(String name);

	@Query(value = "SELECT u FROM User u WHERE u.party.name =:name")
	Page<User> findUsersByParty(@Param("name") String name, Pageable pageable);
	
	
	@Query(value = FIND_USER_BY_USERNAME_AND_PARTY, nativeQuery = true)
	Optional<User> findUserByUsernameAndParty(String username, String party);

}