package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.AttributeDto;
import com.innovative.logics.wms.dto.PageableResponse;

public interface AttributeService {

	/**
	 * 
	 * This method is used to create the Attribute based on given details
	 * 
	 * @author manus
	 * @date 04-Jul-2023
	 * @param attributeDto
	 * @return
	 */
	ApiResponse<AttributeDto> createAttribute(AttributeDto attributeDto);

	/**
	 * 
	 * This method is used to update the Attribute details based on id
	 * 
	 * @author manus
	 * @date 13-Jul-2023
	 * @param attributeDto
	 * @param attributeId
	 * @return
	 */
	ApiResponse<AttributeDto> updateAttribute(AttributeDto attributeDto, String attributeId);

	/**
	 * 
	 * The deleteAttributeById method is used to delete the Attribute and option
	 * based on id
	 * 
	 * @author manus
	 * @date 30-Aug-2023
	 * @param attributeId
	 * @return
	 */
	ApiResponse<AttributeDto> deleteAttributeById(String attributeId);

	/**
	 * 
	 * This method is used to fetch the single Attribute details based on id
	 * 
	 * @author manus
	 * @date 08-Jul-2023
	 * @param attributeId
	 * @return
	 */
	ApiResponse<AttributeDto> getAttributeById(String attributeId);

	/**
	 * 
	 * This method is used to fetch all the Attribute with pagination and sorting
	 * 
	 * @author manus
	 * @date 11-Jul-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<AttributeDto> getAllAttribute(String org, int pageNumber, int pageSize, String sortBy, String sortDir);
	
	ApiResponse<List<AttributeDto>> getAllAttributesByOrganization(String orgnization);

}
