package com.innovative.logics.wms.service;

import java.util.List;
import java.util.Optional;

import javax.naming.SizeLimitExceededException;

import org.springframework.web.multipart.MultipartFile;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.DocumentDto;
import com.innovative.logics.wms.entity.Document;


public interface DocumentService {
	ApiResponse<DocumentDto> uploadDocument(MultipartFile file, String documentDto);
	
	Document uploadDocument(MultipartFile file, DocumentDto documentDto) throws SizeLimitExceededException;

	ApiResponse<List<DocumentDto>> getAllDocuments();

	ApiResponse<Optional<DocumentDto>> getDocumentById(String id);
	
	ApiResponse<DocumentDto> updateDocument(String id, DocumentDto updateDocumentDto);
	
	ApiResponse<DocumentDto> deleteDocument(String id);
	

}

