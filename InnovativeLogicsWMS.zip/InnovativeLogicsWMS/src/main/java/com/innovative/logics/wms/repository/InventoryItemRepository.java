package com.innovative.logics.wms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.InventoryItem;

public interface InventoryItemRepository extends JpaRepository<InventoryItem, String> {

	final String COUNT_PRODUCT_AVAILABLITY = "SELECT Count(*) FROM inventory_item where product_availability_id = :productAvailabilityId";

	Boolean existsByLotNumberIn(List<String> lotNumbers);

	@Query(value = "SELECT ii FROM InventoryItem ii INNER JOIN ii.productAvailability pa LEFT JOIN pa.location l WHERE l.name = :locationName")
	Page<InventoryItem> findAllByLocation(String locationName, Pageable pageable);

	boolean existsByLotNumber(String lotNumber);

	@Query(value = "SELECT ii.* FROM inventory_item ii WHERE ii.lot_number = :lotNumber", nativeQuery = true)
	InventoryItem findLotByLotNumber(String lotNumber);

	Optional<InventoryItem> findByLotNumber(String lotNumber);

	List<InventoryItem> findByLotNumberIn(List<String> lotNumber);

	@Query(value = COUNT_PRODUCT_AVAILABLITY, nativeQuery = true)
	int productAvailablityCount(String productAvailabilityId);

}
