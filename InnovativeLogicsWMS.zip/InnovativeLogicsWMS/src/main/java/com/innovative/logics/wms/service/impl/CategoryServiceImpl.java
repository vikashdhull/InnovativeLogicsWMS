package com.innovative.logics.wms.service.impl;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.CategoryDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.NumberOfQuantity;
import com.innovative.logics.wms.entity.Category;
import com.innovative.logics.wms.entity.Party;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.repository.CategoryRepository;
import com.innovative.logics.wms.repository.PartyRepository;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.service.CategoryService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private PartyRepository partyRepository;

	@Autowired
	private Environment env;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Utility utility;

	private String categoryFetchErrorMessage = "category.fetch.error.message";

	@Override
	public ApiResponse<CategoryDto> createCategory(CategoryDto categoryDto) {

		ApiResponse<CategoryDto> response = new ApiResponse<>();

		Optional<Category> existCategoryByName = categoryRepository.findByName(categoryDto.getName());
		
		Optional<Party> findOrgByName = partyRepository.findByName(categoryDto.getParty());

		try {
			if (existCategoryByName.isPresent()) {
				throw new BadApiRequestException(env.getProperty("category.create.error.message"));
			}

			modelMapper.getConfiguration().setAmbiguityIgnored(true);

			Category category = modelMapper.map(categoryDto, Category.class);
			
			if (findOrgByName.isPresent()) {
				category.setParty(findOrgByName.get());
			}

			Category savedCategory = categoryRepository.save(category);

			CategoryDto newDto = entityToDto(savedCategory);

			response.setData(newDto);
			response.setResult(true);
			response.setMessage(env.getProperty("category.create.success.message"));
			response.setStatus(HttpStatus.CREATED.value());

			return response;
		} catch (Exception exp) {
			log.error("Exception Occured in createCategory Method present in CategoryServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public ApiResponse<CategoryDto> updateCategory(CategoryDto categoryDto, String categoryId) {
		ApiResponse<CategoryDto> response = new ApiResponse<>();

		Optional<Category> optionalCategory = categoryRepository.findById(categoryId);
		Optional<Category> existCategoryByName = categoryRepository.findByName(categoryDto.getName());

		try {
			if (optionalCategory.isPresent()) {
				Category category = optionalCategory.get();

				if (existCategoryByName.isPresent() && !existCategoryByName.get().getId().equals(categoryId)) {
					throw new BadApiRequestException(env.getProperty("category.name.error.message"));
				}
				category.setName(categoryDto.getName());
				category.setDescription(categoryDto.getDescription());

				Category savedCategory = categoryRepository.save(category);
				CategoryDto updatedDto = entityToDto(savedCategory);

				response.setData(updatedDto);
				response.setResult(true);
				response.setMessage(env.getProperty("category.update.success.message"));
				response.setStatus(HttpStatus.OK.value());
			} else {
				response.setMessage(env.getProperty(categoryFetchErrorMessage));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
			}

			return response;
		} catch (Exception exp) {
			log.error("Exception Occurred in updateCategory Method present in CategoryServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<CategoryDto> deleteCategoryById(String categoryId) {
		ApiResponse<CategoryDto> response = new ApiResponse<>();
		try {

			Optional<Category> categoryDetails = categoryRepository.findById(categoryId);

			if (categoryDetails.isPresent()) {

				boolean categoryInUse = checkIfCategoryInUse(categoryId);

				if (categoryInUse) {
					response.setMessage(env.getProperty("category.use.error.message"));
					response.setResult(false);
					response.setStatus(HttpStatus.CONFLICT.value());
					return response;
				}

				categoryRepository.deleteById(categoryId);
				response.setMessage(env.getProperty("category.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				response.setMessage(env.getProperty(categoryFetchErrorMessage));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteCategoryById Method present in CategoryServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public ApiResponse<CategoryDto> getCategoryById(String categoryId) {
		ApiResponse<CategoryDto> response = new ApiResponse<>();
		try {
			Optional<Category> category = categoryRepository.findById(categoryId);

			if (category.isPresent()) {
				CategoryDto categoryDto = entityToDto(category.get());
				response.setMessage(env.getProperty("category.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(categoryDto);
				return response;
			} else {
				response.setMessage(env.getProperty(categoryFetchErrorMessage));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getCategoryById Method present in CategoryServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public PageableResponse<CategoryDto> getAllCategory(String org, int pageNumber, int pageSize, String sortBy,
			String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<Category> page = categoryRepository.findCategoriesByParty(org, pageable);

		PageableResponse<CategoryDto> response = new PageableResponse<>();
		try {
			if (!page.isEmpty()) {

				List<CategoryDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, categoryFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getAllCategory Method present in CategoryServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private boolean checkIfCategoryInUse(String categoryId) {

		return productRepository.existCategoryInProduct(categoryId);
	}

	@Override
	public ApiResponse<NumberOfQuantity> getNumberOfCategories(String org) {
		ApiResponse<NumberOfQuantity> response = new ApiResponse<>();
		try {

			NumberOfQuantity categoriesCount = categoryRepository.getCategoriesCount(org);
			if (categoriesCount != null) {

				response.setMessage(env.getProperty("category.count.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(categoriesCount);
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, categoryFetchErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in getNumberOfCategories Method present in CategoryServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<List<CategoryDto>> getAllCategoriesByOrganization(String orgnization) {
		ApiResponse<List<CategoryDto>> response = new ApiResponse<>();

		try {
			List<Category> categoriesByorg = categoryRepository.findByPartyName(orgnization);
			if (!categoriesByorg.isEmpty()) {
				List<CategoryDto> categoryDto = categoriesByorg.stream().map(this::entityToDto).toList();

				response.setData(categoryDto);
				response.setMessage(env.getProperty("category.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, categoryFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error(
					"Exception Occured in getAllCategoriesByOrganization Method present in CategoryServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private CategoryDto entityToDto(Category category) {
		CategoryDto categoryDto = modelMapper.map(category, CategoryDto.class);

		categoryDto.setId(category.getId());

		categoryDto.setParty(category.getParty().getName());

		return categoryDto;
	}
}
