package com.innovative.logics.wms.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.RoleDto;
import com.innovative.logics.wms.entity.Role;
import com.innovative.logics.wms.repository.LocationRepository;
import com.innovative.logics.wms.repository.PartyRepository;
import com.innovative.logics.wms.repository.RoleRepository;
import com.innovative.logics.wms.repository.UserRepository;
import com.innovative.logics.wms.service.RoleService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
//@PropertySource("classpath:messages.properties")
@Slf4j
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PartyRepository partyRepository;

	@Autowired
	private LocationRepository locationRepository;

	@Autowired
	private Environment env;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Utility utility;

	private String roleFetchSuccessMessage = "role.fetch.success.message";

	private String roleFetchErrorMessage = "role.fetch.error.message";

	@Override
	public ApiResponse<RoleDto> createRole(RoleDto roleDto) {
		ApiResponse<RoleDto> response = new ApiResponse<>();

		Optional<Role> existRole = roleRepository.findByRoleName(roleDto.getRoleName());
		try {
			if (existRole.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "role.create.error.message");
			} else {
				Role role = modelMapper.map(roleDto, Role.class);
				Role savedRole = roleRepository.save(role);
				RoleDto newDto = modelMapper.map(savedRole, RoleDto.class);
				response.setData(newDto);
				response.setResult(true);
				response.setMessage(env.getProperty("role.create.success.message"));
				response.setStatus(HttpStatus.CREATED.value());
				return response;
			}
		} catch (Exception e) {
			log.error("Exception in create role operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<RoleDto> updateRole(RoleDto roleDto, String id) {
		ApiResponse<RoleDto> response = new ApiResponse<>();

		Optional<Role> role = roleRepository.findById(id);

		Optional<Role> existByRoleName = roleRepository.findByRoleName(roleDto.getRoleName());

		try {
			if (role.isPresent()) {
				Role roleData = role.get();

				if (existByRoleName.isPresent() && !Objects.equals(roleData.getRoleName(), roleDto.getRoleName())) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "role.name.error.message");

				} else {
					roleData.setRoleName(roleDto.getRoleName());
				}
				roleData.setDescription(roleDto.getDescription());
				roleData.setRoleCode(roleDto.getRoleCode());

				Role updatedRole = roleRepository.save(roleData);
				RoleDto updatedDto = modelMapper.map(updatedRole, RoleDto.class);

				response.setData(updatedDto);
				response.setResult(true);
				response.setMessage(env.getProperty("role.update.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, roleFetchErrorMessage);
			}
		} catch (Exception e) {
			log.error("Exception in update role operation..." + e.getMessage());
			response.setMessage(e.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<RoleDto> deleteRole(String roleId) {
		ApiResponse<RoleDto> response = new ApiResponse<>();
		try {

			Optional<Role> roleDetails = roleRepository.findById(roleId);

			if (roleDetails.isPresent()) {

				boolean roleInUse = checkIfRoleInUse(roleId);
				if (roleInUse) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "role.use.error.message");
				}
				roleRepository.deleteById(roleId);
				response.setMessage(env.getProperty("role.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, roleFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteRole Method present in RoleServiceImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private boolean checkIfRoleInUse(String roleId) {
		boolean userExistForRole = userRepository.existByRoleId(roleId);

		boolean pertyExistForRole = partyRepository.existByRoleId(roleId);

		boolean locationExistForRole = locationRepository.existByRoleId(roleId);

		return userExistForRole || pertyExistForRole || locationExistForRole;
	}

	@Override
	public ApiResponse<RoleDto> getRoleByRoleName(String roleName) {
		ApiResponse<RoleDto> response = new ApiResponse<>();
		try {

			Optional<Role> role = roleRepository.findByRoleName(roleName);

			if (role.isPresent()) {
				Role roleData = role.get();
				response.setData(modelMapper.map(roleData, RoleDto.class));
				response.setResult(true);
				response.setMessage(env.getProperty(roleFetchSuccessMessage));
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, roleFetchErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getRoleById Method present in RoleServiceImpl class{}", exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	@Override
	public ApiResponse<List<RoleDto>> getAllRoles() {
		ApiResponse<List<RoleDto>> response = new ApiResponse<>();

		try {
			List<Role> roles = roleRepository.findAll();
			List<RoleDto> roleDtos = roles.stream().map(role -> modelMapper.map(role, RoleDto.class)).toList();

			if (!roles.isEmpty()) {
				response.setMessage(env.getProperty(roleFetchSuccessMessage));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(roleDtos);
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "roles.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getAllRole Method present in RoleServiceImpl class{}", exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<List<RoleDto>> getRolesByCode(String roleCode) {
		ApiResponse<List<RoleDto>> response = new ApiResponse<>();

		try {
			List<Role> roles = roleRepository.findByRoleCode(roleCode);
			List<RoleDto> roleDtos = roles.stream().map(role -> modelMapper.map(role, RoleDto.class)).toList();

			if (!roles.isEmpty()) {
				response.setMessage(env.getProperty(roleFetchSuccessMessage));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(roleDtos);
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, "roles.fetch.error.message");
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getRolesByCode Method present in RoleServiceImpl class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}
}
