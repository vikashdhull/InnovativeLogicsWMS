package com.innovative.logics.wms.dto.response;

import java.time.LocalDateTime;
import java.util.List;

import com.innovative.logics.wms.dto.InventoryItemDto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductAvailabilityResponseDto {
	
	private String id;

	private String productName;
	
	private String productCode;

	private String location;
	
	private List<InventoryItemDto> inventoryItem;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
