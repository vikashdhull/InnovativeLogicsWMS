package com.innovative.logics.wms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.StockRecordDto;
import com.innovative.logics.wms.dto.response.StockRecordResponseDto;
import com.innovative.logics.wms.service.InventoryItemService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/inventory-items")
@Slf4j
public class InventoryItemController {

	@Autowired
	private InventoryItemService inventoryItemService;

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{locationName}")
	public ResponseEntity<PageableResponse<StockRecordResponseDto>> getAllInventoryItemByLocation(
			@PathVariable("locationName") final String locationName,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "lotNumber", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllInventoryItemByLocation Method present in InventoryItemController class");

		PageableResponse<StockRecordResponseDto> response = inventoryItemService
				.getAllInventoryItemByLocation(locationName, pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<StockRecordResponseDto>> updateInventoryItem(
			@Valid @RequestBody final StockRecordDto inventoryItemDto, @PathVariable final String id) {
		log.info("Enter in updateInventoryItem Method present in InventoryItemController class");
		ApiResponse<StockRecordResponseDto> response = inventoryItemService.updateInventoryItem(inventoryItemDto, id);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * Add method description here
	 * @author manus 
	 * @date 27-Oct-2023 
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<StockRecordResponseDto>> deleteInventoryItem(@PathVariable("id") String id) {
		log.info("Enter in deleteInventoryItem Method present in InventoryItemController class");
		ApiResponse<StockRecordResponseDto> response = inventoryItemService.deleteInventoryItemById(id);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
