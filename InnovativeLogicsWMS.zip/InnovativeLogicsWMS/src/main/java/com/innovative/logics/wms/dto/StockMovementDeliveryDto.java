package com.innovative.logics.wms.dto;

import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StockMovementDeliveryDto {
	
	private String stockMovementName;
	
	private Map<String, StockMovementItemDto> items;
		
}
