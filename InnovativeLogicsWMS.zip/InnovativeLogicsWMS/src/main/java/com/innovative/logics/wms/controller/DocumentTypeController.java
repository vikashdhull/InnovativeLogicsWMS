package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.DocumentTypeDto;
import com.innovative.logics.wms.service.DocumentTypeService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/document-type")
@Slf4j
public class DocumentTypeController {

	@Autowired
	private DocumentTypeService documentTypeService;

	/**
	 * 
	 * The createDocumentType method is used to create the Document Type and save
	 * the data in document_type table based on given details
	 * 
	 * @author abhineets
	 * @date 01-Sep-2023
	 * @param documentTypeDto
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<DocumentTypeDto>> createDocumentType(
			@Valid @RequestBody final DocumentTypeDto documentTypeDto) {
		log.info("Enter in createDocumentType method present in DocumentTypeController class");
		ApiResponse<DocumentTypeDto> response = documentTypeService.createDocumentType(documentTypeDto);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAllDocumentType method is used to fetch all the Document Type from the
	 * document_type table
	 * 
	 * @author abhineets
	 * @date 04-Sep-2023
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<ApiResponse<List<DocumentTypeDto>>> getAllDocumentType() {
		log.info("Enter in getAllDocumentType Method present in DocumentTypeService class");
		ApiResponse<List<DocumentTypeDto>> response = documentTypeService.getAllDocumentType();
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/{documentTypeId}")
	public ResponseEntity<ApiResponse<DocumentTypeDto>> updateDocumentType(
			@Valid @RequestBody final DocumentTypeDto documentTypeDto, @PathVariable final String documentTypeId) {
		log.info("Enter in updateDocumentType Method present in DocumentTypeController class");
		ApiResponse<DocumentTypeDto> response = documentTypeService.updateDocumentType(documentTypeDto, documentTypeId);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
}
