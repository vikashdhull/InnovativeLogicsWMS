package com.innovative.logics.wms.service;

import com.innovative.logics.wms.dto.response.JwtResponse;

public interface LoginService {

	/**
	 * 
	 * This method is used to generate the token based on given details
	 * 
	 * @author manus
	 * @date 20-Mar-2023
	 * @param username
	 * @param password
	 * @return
	 */
	JwtResponse login(String username, String password);

}
