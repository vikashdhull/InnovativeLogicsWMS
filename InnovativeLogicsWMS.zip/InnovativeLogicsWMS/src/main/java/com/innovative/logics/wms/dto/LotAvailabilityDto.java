package com.innovative.logics.wms.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LotAvailabilityDto {

	private String id;

	private String lotNumber;

	private int quantityOnHand;

	private String comment;

	private InventoryItemDto inventoryItem;

}
