package com.innovative.logics.wms.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderDto {

	private String name;

	private String description;

	private String origin;

	private String destination;

	private String paymentMethodType;

	private String paymentTerm;

}
