package com.innovative.logics.wms.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.StockMovementDeliveryDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.StockMovementResponseDto;
import com.innovative.logics.wms.service.StockMovementReceiveService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * The StockMovementController class defines the REST endpoints for creating,
 * updating and retrieving stock movement details.Endpoints are secured with
 * Spring Security's @PreAuthorize annotation to ensure that only authorized
 * users can perform CRUD operations on stock movement.
 * 
 * @author manus
 * @date 20-Jan-2024
 */
@RestController
@RequestMapping("/movement")
@Slf4j
public class StockMovementReceiveController {
	
	@Autowired
	StockMovementReceiveService stockMovementReceiveService;

	/**
	 * 
	 * This receiveStockMovement method is used to receive the stock movement, 
	 * and user will also able to partially receive the stock movement.
	 * 
	 * @author manus
	 * @date 15-Jan-2024
	 * @param stockMovementDeliveryDto
	 *  @param principle
	 * @return ResponseEntity will return ApiResponse with the StockMovementResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping("/receive")
	public ResponseEntity<ApiResponse<StockMovementResponseDto>> receiveStockMovement(
			@Valid @RequestBody final StockMovementDeliveryDto stockMovementDeliveryDto, Principal principal) {
		log.info("Enter in receiveStockMovement Method present in StockMovementReceiveController class");
		
		ApiResponse<StockMovementResponseDto> response = stockMovementReceiveService.receiveStockMovement(stockMovementDeliveryDto, principal);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	/**
	 * 
	 * This getAllStockMovementByOrigin method is used to fetch the stock movement by 
	 * location from goods are requested with requested page.
	 * 
	 * @author manus
	 * @date 16-Jan-2024
	 * @param origin
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return ResponseEntity will return PageableResponse with the list of StockMovementResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/o-location")
	public ResponseEntity<PageableResponse<StockMovementResponseDto>> getAllStockMovementByOrigin(
			@RequestParam(value = "origin", required = true) String origin,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllStockMovementByOrigin Method present in StockMovementReceiveController class");
		PageableResponse<StockMovementResponseDto> response = stockMovementReceiveService.getAllStockMovementByOrigin(
				origin, pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	/**
	 * 
	 * This getAllStockMovementByDestination method is used to fetch the stock movement with 
	 * location where stock movement was create and where goods are delivered with requested page.
	 * 
	 * @author manus
	 * @date 17-Jan-2024
	 * @param destination
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return ResponseEntity will return PageableResponse with the StockMovementResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/d-location")
	public ResponseEntity<PageableResponse<StockMovementResponseDto>> getAllStockMovementByDestination(

			@RequestParam(value = "destination", required = true) String destination,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllStockMovementByDestination Method present in StockMovementReceiveController class");
		PageableResponse<StockMovementResponseDto> response = stockMovementReceiveService.getAllStockMovementByDestination(
				destination, pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	/**
	 * 
	 * This uploadStockMovementDocuments method is used to upload documents related to stock movement with shipping number.
	 * 
	 * @author manus
	 * @date 18-Jan-2024
	 * @param stockMId
	 * @param file
	 * @param documentDto
	 * @param shipmentNumber
	 * @return ResponseEntity will return ApiResponse with the StockMovementResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping("/document/{id}")
	public ResponseEntity<ApiResponse<StockMovementResponseDto>> uploadStockMovementDocuments(
			@PathVariable("id") String stockMId, @RequestParam("file") MultipartFile file,
			@Valid @RequestParam final String documentDto, @RequestParam final String shipmentNumber ) {
		log.info("Enter in uploadDocumentInOutboundShipment Method present in OutboundShipmentController class");
		ApiResponse<StockMovementResponseDto> response = stockMovementReceiveService
				.uploadStockMovementDocuments(stockMId, file, documentDto, shipmentNumber);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	 
	/**
	 * 
	 * This cancelStockMovement method is used to cancel the stock movement before shipping.
	 * 
	 * @author manus
	 * @date 19-Jan-2024
	 * @param orderName
	 * @param principal
	 * @return ResponseEntity will return ApiResponse with the StockMovementResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/cancel")
	public ResponseEntity<ApiResponse<StockMovementResponseDto>> cancelStockMovement(
			@Valid @RequestParam final String orderName, Principal principal) {
		log.info("Enter in cancelStockMovement Method present in OutboundShipmentController class");
		ApiResponse<StockMovementResponseDto> response = stockMovementReceiveService
				.cancelStockMovement(orderName, principal);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	/**
	 * 
	 * This findStockMovementById method is used to fetch the stock movement by orderId
	 * 
	 * @author manus
	 * @date 20-Jan-2024
	 * @param orderId
	 * @return ResponseEntity will return ApiResponse with the StockMovementResponseDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<StockMovementResponseDto>> findStockMovementById(
			@PathVariable("id") String orderId) {
		log.info("Enter in getAllStockMovementByDestination Method present in StockMovementReceiveController class");
		ApiResponse<StockMovementResponseDto> response = stockMovementReceiveService.findById(orderId);
				

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
