package com.innovative.logics.wms.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProductSourceDto {
	
	private String id;

	@NotNull(message = "Code should not be null")
	private String code;

	@NotNull(message = "Name should not be null")
	private String name;

	private String description;

	private ProductDto product;

	private LocationDto location;

	private PartyDto party;

	private Double contractPrice;

	private LocalDate contractValidUntil;

	private Long minOrderQuantity;

	private String ratingType;
	
	private String preferenceType;
	
	private String org;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
