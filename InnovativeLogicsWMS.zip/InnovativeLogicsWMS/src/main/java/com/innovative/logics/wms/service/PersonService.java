package com.innovative.logics.wms.service;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PersonDto;

public interface PersonService {

	/**
	 * This method is used to create the person and save the data in person table
	 * based on given details
	 * 
	 * @author manus
	 * @date 31-Mar-2023
	 * @param personDto
	 * @return
	 */
	ApiResponse<PersonDto> createPerson(PersonDto personDto);

	/**
	 * 
	 * Add method description here
	 * 
	 * @author manus
	 * @date 10-Jun-2023
	 * @param personDto
	 * @return
	 */
	ApiResponse<PersonDto> updatePerson(PersonDto personDto);

	/**
	 * 
	 * This method is used to delete the person based on email
	 * 
	 * @author manus
	 * @date 03-Apr-2023
	 * @param email
	 * @return
	 */
	ApiResponse<PersonDto> deletePerson(String email);

	/**
	 * 
	 * This method is used to fetch the single person details based on id
	 * 
	 * @author manus
	 * @date 03-Apr-2023
	 * @param id
	 * @return
	 */
	ApiResponse<PersonDto> getPersonById(String id);

	/**
	 * 
	 * This method is used to get all the persons from the person table
	 * 
	 * @author manus
	 * @date 14-Apr-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<PersonDto> getAllPerson(int pageNumber, int pageSize, String sortBy, String sortDir);

}
