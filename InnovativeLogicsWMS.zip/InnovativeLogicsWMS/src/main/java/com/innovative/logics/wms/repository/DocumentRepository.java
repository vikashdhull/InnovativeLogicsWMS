package com.innovative.logics.wms.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.innovative.logics.wms.entity.Document;

public interface DocumentRepository extends JpaRepository<Document, String> {
	
	Optional<Document> findByFileName(String name);
	Optional<Document> findByFileNameOrName(String fileName,String name);
}
