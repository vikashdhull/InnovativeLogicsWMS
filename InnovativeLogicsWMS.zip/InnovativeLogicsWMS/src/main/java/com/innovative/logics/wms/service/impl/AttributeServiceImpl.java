package com.innovative.logics.wms.service.impl;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.AttributeDto;
import com.innovative.logics.wms.dto.AttributeOptionDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.entity.Attribute;
import com.innovative.logics.wms.entity.AttributeOption;
import com.innovative.logics.wms.entity.Party;
import com.innovative.logics.wms.repository.AttributeOptionRepository;
import com.innovative.logics.wms.repository.AttributeRepository;
import com.innovative.logics.wms.repository.PartyRepository;
import com.innovative.logics.wms.repository.ProductAttributeOptionRepository;
import com.innovative.logics.wms.service.AttributeService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AttributeServiceImpl implements AttributeService {

	@Autowired
	private AttributeRepository attributeRepository;

	@Autowired
	private AttributeOptionRepository attributeOptionRepository;

	@Autowired
	private PartyRepository partyRepository;

	@Autowired
	private ProductAttributeOptionRepository productAttributeOptionRepository;

	@Autowired
	private Environment env;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private Utility utility;

	private String attributeFetchErrorMessage = "attribute.fetch.error.message";

	@Override
	public ApiResponse<AttributeDto> createAttribute(AttributeDto attributeDto) {
		ApiResponse<AttributeDto> response = new ApiResponse<>();

		Optional<Attribute> existAttributeByName = attributeRepository.findByName(attributeDto.getName());

		Optional<Party> findOrgByName = partyRepository.findByName(attributeDto.getParty());

		try {
			if (existAttributeByName.isPresent()) {
				return utility.errorResponse(response, HttpStatus.CONFLICT, "attribute.name.error.message");
			}

			modelMapper.getConfiguration().setAmbiguityIgnored(true);
			Attribute attribute = modelMapper.map(attributeDto, Attribute.class);

			if (findOrgByName.isPresent()) {
				attribute.setParty(findOrgByName.get());
			}

			Attribute savedAttribute = attributeRepository.save(attribute);
			List<AttributeOptionDto> options = attributeDto.getOption();

			if (options != null && !options.isEmpty()) {
				List<AttributeOption> attributeOptions = attributeDto.getOption().stream().map(optionDto -> {
					AttributeOption attributeOption = modelMapper.map(optionDto, AttributeOption.class);
					attributeOption.setAttribute(savedAttribute);
					return attributeOption;
				}).toList();

				attributeOptionRepository.saveAll(attributeOptions);
			}

			AttributeDto newDto = entityToDto(savedAttribute);

			response.setData(newDto);
			response.setResult(true);
			response.setMessage(env.getProperty("attribute.create.success.message"));
			response.setStatus(HttpStatus.CREATED.value());
		} catch (Exception exp) {
			log.error("Exception Occurred in createAttribute Method present in AttributeService class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
		return response;
	}

	@Transactional
	@Override
	public ApiResponse<AttributeDto> updateAttribute(AttributeDto attributeDto, String attributeId) {
		ApiResponse<AttributeDto> response = new ApiResponse<>();

		try {
			Optional<Attribute> existingAttributeOptional = attributeRepository.findById(attributeId);
			if (!existingAttributeOptional.isPresent()) {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, attributeFetchErrorMessage);
			} else {
				Attribute attributedata = existingAttributeOptional.get();
				Optional<Attribute> existAttributeByName = attributeRepository.findByName(attributeDto.getName());

				if (existAttributeByName.isPresent() && !existAttributeByName.get().getId().equals(attributeId)) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "attribute.name.error.message");
				}
				attributedata.setId(attributeId);
				attributedata.setName(attributeDto.getName());
				attributedata.setDescription(attributeDto.getDescription());

				Attribute updatedAttribute = attributeRepository.save(attributedata);

				attributeOptionRepository.deleteByAttributeId(attributeId);

				List<AttributeOption> attributeOptions = attributeDto.getOption().stream().map(optionDto -> {
					AttributeOption attributeOption = modelMapper.map(optionDto, AttributeOption.class);
					attributeOption.setAttribute(updatedAttribute);
					return attributeOption;
				}).toList();

				attributeOptionRepository.saveAll(attributeOptions);

				List<AttributeOption> updatedAttributeOptions = attributeOptionRepository
						.findByAttribute(updatedAttribute);
				List<AttributeOptionDto> optionDtos = updatedAttributeOptions.stream()
						.map(option -> modelMapper.map(option, AttributeOptionDto.class)).toList();
				AttributeDto newDto = entityToDto(updatedAttribute);
				newDto.setOption(optionDtos);

				response.setData(newDto);
				response.setResult(true);
				response.setMessage(env.getProperty("attribute.update.success.message"));
				response.setStatus(HttpStatus.OK.value());
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in updateAttribute Method present in AttributeService class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

		return response;
	}

	@Override
	public ApiResponse<AttributeDto> deleteAttributeById(String attributeId) {
		ApiResponse<AttributeDto> response = new ApiResponse<>();
		try {

			Optional<Attribute> attributeDetails = attributeRepository.findById(attributeId);

			if (attributeDetails.isPresent()) {

				boolean attributeInUse = checkIfAttributeInUse(attributeId);

				if (attributeInUse) {
					return utility.errorResponse(response, HttpStatus.CONFLICT, "attribute.use.error.message");
				}
				attributeRepository.deleteById(attributeId);
				response.setMessage(env.getProperty("attribute.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, attributeFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteAttributeById Method present in AttributeService class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Transactional
	@Override
	public ApiResponse<AttributeDto> getAttributeById(String attributeId) {
		ApiResponse<AttributeDto> response = new ApiResponse<>();
		try {
			Optional<Attribute> attribute = attributeRepository.findById(attributeId);

			if (attribute.isPresent()) {
				AttributeDto attributeDto = entityToDto(attribute.get());
				response.setMessage(env.getProperty("attribute.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(attributeDto);
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, attributeFetchErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getAttributeById Method present in AttributeService class{}",
					exp.getMessage());

			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional
	public PageableResponse<AttributeDto> getAllAttribute(String org, int pageNumber, int pageSize, String sortBy,
			String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<Attribute> page = attributeRepository.findAttributesByParty(org, pageable);

		PageableResponse<AttributeDto> response = new PageableResponse<>();
		try {
			if (!page.isEmpty()) {

				List<AttributeDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, attributeFetchErrorMessage);
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getAllAttribute Method present in AttributeService class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private boolean checkIfAttributeInUse(String attributeId) {
		return productAttributeOptionRepository.existAttributeInProduct(attributeId);
	}

	@Override
	public ApiResponse<List<AttributeDto>> getAllAttributesByOrganization(String orgnization) {
		ApiResponse<List<AttributeDto>> response = new ApiResponse<>();

		try {
			List<Attribute> attributesByorg = attributeRepository.findByPartyName(orgnization);
			if (!attributesByorg.isEmpty()) {
				List<AttributeDto> attributeDto = attributesByorg.stream().map(this::entityToDto).toList();

				response.setData(attributeDto);
				response.setMessage(env.getProperty("attribute.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				return utility.errorResponse(response, HttpStatus.NOT_FOUND, attributeFetchErrorMessage);
			}

		} catch (Exception exp) {
			log.error("Exception Occured in getAllAttributesByOrganization Method present in AttributeService class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private AttributeDto entityToDto(Attribute attribute) {
		AttributeDto attributeDto = modelMapper.map(attribute, AttributeDto.class);

		attributeDto.setId(attribute.getId());
		attributeDto.setName(attribute.getName());
		attributeDto.setDescription(attribute.getDescription());
		attributeDto.setParty(attribute.getParty().getName());
		attributeDto.setCreatedDate(attribute.getCreatedDate());
		attributeDto.setUpdatedDate(attribute.getUpdatedDate());

		return attributeDto;
	}

}
