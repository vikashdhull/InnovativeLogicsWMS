package com.innovative.logics.wms.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.DocumentDto;
import com.innovative.logics.wms.service.DocumentService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/documents")
public class DocumentController {
	@Autowired
	private DocumentService documentService;

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@PostMapping
	public ResponseEntity<ApiResponse<DocumentDto>> saveUpload(@RequestParam("file") MultipartFile file,
			@Valid @RequestParam final String documentDto){
		log.info("Enter in saveUpload Method present in DocumentController class");
		ApiResponse<DocumentDto> response = documentService.uploadDocument(file, documentDto);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<ApiResponse<List<DocumentDto>>> getAllDocuments() {
		log.info("Enter in getAllDocuments Method present in DocumentController class");
		ApiResponse<List<DocumentDto>> response = documentService.getAllDocuments();
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<Optional<DocumentDto>>> getDocumentById(@PathVariable final String id) {
		log.info("Enter in getDocumentById Method present in DocumentController class");
		ApiResponse<Optional<DocumentDto>> response = documentService.getDocumentById(id);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<DocumentDto>> updateDocument(@PathVariable final String id,
			@RequestBody DocumentDto updateDocument) {
		ApiResponse<DocumentDto> response = documentService.updateDocument(id, updateDocument);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<DocumentDto>> deleteDocument(@PathVariable final String id) {
		ApiResponse<DocumentDto> response = documentService.deleteDocument(id);
		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
}
