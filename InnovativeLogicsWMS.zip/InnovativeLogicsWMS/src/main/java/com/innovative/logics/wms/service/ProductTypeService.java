package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductTypeDto;

public interface ProductTypeService {

	/**
	 * This method is used to create the Product Type based on given details
	 * 
	 * @author manus
	 * @date 18-Jul-2023
	 * @param productTypeDto
	 * @return
	 */
	ApiResponse<ProductTypeDto> createProductType(ProductTypeDto productTypeDto);

	/**
	 * 
	 * This method is used to update the Product Type details based on id
	 * 
	 * @author manus
	 * @date 24-Jul-2023
	 * @param productTypeDto
	 * @param productTypeId
	 * @return
	 */
	ApiResponse<ProductTypeDto> updateProductType(ProductTypeDto productTypeDto, String productTypeId);

	ApiResponse<ProductTypeDto> deleteProductTypeById(String productTypeId);

	/**
	 * 
	 * This method is used to fetch the single Product Type details based on id
	 * 
	 * @author manus
	 * @date 21-Jul-2023
	 * @param productTypeId
	 * @return
	 */
	ApiResponse<ProductTypeDto> getProductTypeById(String productTypeId);

	/**
	 * 
	 * Add method description here
	 * @author manus 
	 * @date 26-Jul-2023 
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<ProductTypeDto> getAllProductType(String org, int pageNumber, int pageSize, String sortBy, String sortDir);
	
	ApiResponse<List<ProductTypeDto>> getAllProductTypesByOrganization(String orgnization);

}
