package com.innovative.logics.wms.entity;

import java.time.LocalDate;


import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "stock_movement")
@Getter
@Setter
public class StockMovement {
	
	@Column(name = "id")
	@Id
	@UuidGenerator
	private String id;

	@Column(name = "name", length = 100)
	@NotNull(message = "Name should not be null")
	private String name;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "origin_id", referencedColumnName = "id")
	private Location origin;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "destination_id", referencedColumnName = "id")
	private Location destination;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "requested_by", referencedColumnName = "id")
	private User requestedBy;
	
	@Column(name = "requested_date")
	private LocalDate requestedDate;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "status", length = 100)
	private String status;
	
	@Column(name = "created_date", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createdDate;

	@Column(name = "updated_date")
	@UpdateTimestamp
	private LocalDateTime updatedDate;
	
	@ManyToOne(cascade = CascadeType.DETACH)
	@JoinColumn(name = "recipient", referencedColumnName = "id")
	private User recipient;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "approved_by", referencedColumnName = "id")
	private User approvedBy;

	@Column(name = "approved_date")
	private LocalDate approvedDate;
	
	@ManyToOne(cascade = CascadeType.DETACH)
	@JoinColumn(name = "cancelledBy", referencedColumnName = "id")
	private User cancelledBy;
	
	@Column(name = "cancelled_date")
	private LocalDate cancelledDate;
	
}
