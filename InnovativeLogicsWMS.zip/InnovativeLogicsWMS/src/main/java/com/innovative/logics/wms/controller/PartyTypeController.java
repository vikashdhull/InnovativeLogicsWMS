package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PartyTypeDto;
import com.innovative.logics.wms.service.PartyTypeService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * The PartyTypeController class defines the REST endpoints for creating,
 * retrieving, updating, and deleting PartyType entities.Endpoints are secured
 * with Spring Security's @PreAuthorize annotation to ensure that only
 * authorized users can perform CRUD operations on parties.
 * 
 * @author manus
 * @date 15-Apr-2023
 */
@RestController
@RequestMapping("/partyType")
@Slf4j
public class PartyTypeController {

	@Autowired
	private PartyTypeService partyTypeService;

	/**
	 * 
	 * The createPartyType method is used to create the partyType based on given
	 * details.
	 * 
	 * @author manus
	 * @date 05-Apr-2023
	 * @param partyTypeDto
	 * @return ResponseEntity containing an ApiResponse with the PartyTypeDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN')")
	@PostMapping
	public ResponseEntity<ApiResponse<PartyTypeDto>> createPartyType(
			@Valid @RequestBody final PartyTypeDto partyTypeDto) {
		log.info("Enter in createPartyType Method present in PartyTypeController class");
		ApiResponse<PartyTypeDto> response = partyTypeService.createPartyType(partyTypeDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getPartyTypeById method is used to fetch the PartyType details from the
	 * partyType table based on id
	 * 
	 * @author manus
	 * @date 06-Apr-2023
	 * @param id
	 * @return ResponseEntity containing an ApiResponse with the PartyTypeDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<PartyTypeDto>> getPartyTypeById(@PathVariable("id") final String id) {
		log.info("Enter in getPartyTypeById Method present in PartyTypeController class");
		ApiResponse<PartyTypeDto> response = partyTypeService.getPartyTypeById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The deletePartyTypeById method is used to delete the the PartyType details
	 * from the partyType table based on id
	 * 
	 * @author manus
	 * @date 06-Apr-2023
	 * @param id
	 * @return ResponseEntity containing an ApiResponse with the PartyTypeDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<PartyTypeDto>> deletePartyTypeById(@PathVariable final String id) {
		log.info("Enter in deletePartyType Method present in PartyTypeController class");
		ApiResponse<PartyTypeDto> response = partyTypeService.deletePartyTypeById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * The getAllPartyType method is used to fetch all the PartyType from the
	 * PartyType table
	 * 
	 * @author manus
	 * @date 07-Apr-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return ResponseEntity containing an PageableResponse with the PartyTypeDto
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/")
	public ResponseEntity<PageableResponse<PartyTypeDto>> getAllPartyType(
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllPartyType Method present in PartyTypeController class");

		PageableResponse<PartyTypeDto> response = partyTypeService.getAllPartyType(pageNumber, pageSize, sortBy,
				sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));

	}

	/**
	 * 
	 * The updatePartyTypeInformtion method is used to update the PartyType details
	 * based on id
	 * 
	 * @author manus
	 * @date 06-Jun-2023
	 * @param partyTypeDetails
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<PartyTypeDto>> updatePartyTypeInformtion(
			@Valid @RequestBody final PartyTypeDto partyTypeDetails, @PathVariable("id") final String id) {
		log.info("Enter in updatePartyTypeInformtion Method present in PartyTypeController class");
		ApiResponse<PartyTypeDto> response = partyTypeService.updatePartyType(partyTypeDetails, id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	/**
	 * The searchPartyType method is used to search the parties based on PartyTypeName
	 * 
	 * Add method description here
	 * @author manus
	 * @date 15-Jun-2023
	 * @param keyword
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/search/{keyword}")
	public ResponseEntity<PageableResponse<PartyTypeDto>> searchPartyType(@PathVariable String keyword,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		PageableResponse<PartyTypeDto> response = partyTypeService.searchPartyType(keyword, pageNumber, pageSize, sortBy, sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	/**
	 * 
	 * Add method description here
	 * @author manus 
	 * @date 28-Nov-2023 
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping("/org/type")
	public ResponseEntity<ApiResponse<List<PartyTypeDto>>> getPartyTypes() {
		log.info("Enter in getPartyTypes Method present in PartyTypeController class");
		ApiResponse<List<PartyTypeDto>> response = partyTypeService.getPartyTypes();

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}
}