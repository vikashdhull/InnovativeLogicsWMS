package com.innovative.logics.wms.service;

import java.io.IOException;
import java.util.List;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.web.multipart.MultipartFile;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.PartyDto;

public interface PartyService {

	/**
	 * 
	 * This method is used to create the party based on given details.
	 * 
	 * @author manus
	 * @date 07-Apr-2023
	 * @param partyDto
	 * @return
	 */
	ApiResponse<PartyDto> createParty(PartyDto partyDto, MultipartFile orgLogo);

	/**
	 * 
	 * This method is used to update the Party details based on id
	 * 
	 * @author manus
	 * @date 31-May-2023
	 * @param partyDto
	 * @param partyId
	 * @return
	 */
	ApiResponse<PartyDto> updateParty(PartyDto partyDto, String partyId, MultipartFile orgLogo)
			throws IOException;

	/**
	 * 
	 * This method is used to delete the the Party details based on id
	 * 
	 * @author manus
	 * @date 19-Apr-2023
	 * @param partyId
	 * @return
	 */
	ApiResponse<PartyDto> deletePartyById(String partyId);

	/**
	 * 
	 * This method is used to fetch the single party details based on id
	 * 
	 * @author manus
	 * @date 27-Mar-2023
	 * @param partyId
	 * @return
	 */
	ApiResponse<PartyDto> getPartyById(String partyId);

	/**
	 * 
	 * This method is used to fetch all the party from the party table
	 * 
	 * @author manus
	 * @date 12-Apr-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<PartyDto> getAllParty(int pageNumber, int pageSize, String sortBy, String sortDir);

	/**
	 * 
	 * This method is used to search the parties based on PartyName
	 * 
	 * @author manus
	 * @date 18-Apr-2023
	 * @param keyword
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<PartyDto> searchParty(String keyword, int pageNumber, int pageSize, String sortBy, String sortDir);

	/**
	 * 
	 * This method is used to get the parties based on RoleName
	 * 
	 * @author manus
	 * @date 04-Sep-2023
	 * @param roleName
	 * @return
	 */
	ApiResponse<List<PartyDto>> getPartyByRole(String roleName);
	
	ApiResponse<List<PartyDto>> getAllParties();
	
	ByteArrayResource getOrgLogo(String partyName) throws IOException;

}
