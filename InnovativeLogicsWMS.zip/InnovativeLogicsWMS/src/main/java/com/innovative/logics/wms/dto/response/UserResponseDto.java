package com.innovative.logics.wms.dto.response;

import java.time.LocalDateTime;
import java.util.Locale;
import java.util.Set;

import com.innovative.logics.wms.dto.RoleDto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserResponseDto {

	private String id;

	private String firstName;

	private String lastName;

	private String username;

	private String email;

	private Boolean status;

	private String notes;

	private Locale locale;

	private Boolean isUser;

	private Set<RoleDto> role;

	private String phoneNumber;

	private String streetAddress;

	private String city;

	private String state;

	private String country;

	private String zipCode;

	private String organization;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
