package com.innovative.logics.wms.service.impl;

import java.security.Principal;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.StockListDto;
import com.innovative.logics.wms.dto.response.StockListResponseDto;
import com.innovative.logics.wms.entity.Location;
import com.innovative.logics.wms.entity.Party;
import com.innovative.logics.wms.entity.StockList;
import com.innovative.logics.wms.entity.StockListItem;
import com.innovative.logics.wms.exception.BadApiRequestException;
import com.innovative.logics.wms.repository.LocationRepository;
import com.innovative.logics.wms.repository.PartyRepository;
import com.innovative.logics.wms.repository.StockListItemRepository;
import com.innovative.logics.wms.repository.StockListRepository;
import com.innovative.logics.wms.service.StockListService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StockListServiceImpl implements StockListService {

	private String stockListFetchErrorMessage = "stocklist.fetch.error.message";

	@Autowired
	private StockListRepository stockListRepository;

	@Autowired
	private StockListItemRepository stockListItemRepository;
	
	@Autowired
	private PartyRepository partyRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private LocationRepository locationRepository;

	@Autowired
	private Environment env;

	@Autowired
	private Utility utility;

	@Override
	@Transactional(propagation = Propagation.SUPPORTS)
	public ApiResponse<StockListResponseDto> createStockList(StockListDto stockListDto, Principal principal) {

		ApiResponse<StockListResponseDto> apiResponse = new ApiResponse<>();

		Optional<Location> findByOriginName = locationRepository.findByName(stockListDto.getOrigin().getName());
		
		Optional<Party> findOrgByName = partyRepository.findByName(stockListDto.getParty());

		Optional<Location> findByDestinationName = locationRepository
				.findByName(stockListDto.getDestination().getName());

		try {
			if (!findByOriginName.isPresent()) {
				throw new BadApiRequestException(env.getProperty("stocklist.location.origin.error.message"));
			}

			if (!findByDestinationName.isPresent()) {
				throw new BadApiRequestException(env.getProperty("stocklist.location.destination.error.message"));
			}

			if (findByOriginName.get().getName().equals(findByDestinationName.get().getName())) {
				throw new BadApiRequestException(env.getProperty("stocklist.location.name.error.message"));
			}

			StockList sList = modelMapper.map(stockListDto, StockList.class);
			
			if (findOrgByName.isPresent()) {
				sList.setParty(findOrgByName.get());
			}

			sList.setCreatedBy(principal.getName());

			sList.setOrigin(findByOriginName.get());

			sList.setDestination(findByDestinationName.get());

			boolean existStockListByName = stockListRepository.existStockListByName(stockListDto.getName());

			if (!existStockListByName) {
				StockList list = stockListRepository.save(sList);

				apiResponse.setData(entityToDto(list));
				apiResponse.setMessage(env.getProperty("stockList.create.success.message"));
				apiResponse.setResult(true);
				apiResponse.setStatus(HttpStatus.CREATED.value());
				return apiResponse;
			} else {
				throw new BadApiRequestException(env.getProperty("stocklist.name.error.message"));
			}

		} catch (Exception exp) {
			log.error("Exception Occured in createStockList Method present in StockListServiceImpl class{}",
					exp.getMessage());
			apiResponse.setMessage(exp.getMessage());
			apiResponse.setStatus(HttpStatus.BAD_REQUEST.value());
			return apiResponse;
		}

	}

	@Override
	@Transactional
	public PageableResponse<StockListResponseDto> getAllStockListPage(String org, int pageNumber, int pageSize, String sortBy,
			String sortDir) {

		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());

		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

		Page<StockList> page = stockListRepository.findStockListsByParty(org, pageable);

		PageableResponse<StockListResponseDto> response = new PageableResponse<>();
		try {
			if (!page.isEmpty()) {

				List<StockListResponseDto> dtolist = page.stream().map(this::entityToDto).toList();

				long totalElements = page.getTotalElements();
				int totalPages = page.getTotalPages();
				response.setData(dtolist);
				response.setPageNumber(page.getNumber());
				response.setPageSize(page.getSize());
				response.setTotalElements(totalElements);
				response.setTotalPages(totalPages);
				response.setLastPage(page.isLast());
				response.setMessage(env.getProperty("record.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;

			} else {
				return utility.pageableErrorResponse(response, HttpStatus.NOT_FOUND, stockListFetchErrorMessage);

			}
		} catch (Exception exp) {
			log.error("Exception Occured in getAllStockList Method present in StockListImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

//no use for now because without pagination
	@Override
	@Transactional
	public ApiResponse<List<StockListResponseDto>> getAllStockList(String organization) {

		ApiResponse<List<StockListResponseDto>> response = new ApiResponse<>();
		List<StockList> stockLists = stockListRepository.findAll();
		try {
			if (!stockLists.isEmpty()) {

				List<StockListResponseDto> stockListResponseDtos = stockLists.stream().map(stockList -> {

					StockListResponseDto stockListResponseDto = entityToDto(stockList);

					stockListResponseDto.setRequisitionItems(stockList.getStockListItem().size());

					return stockListResponseDto;
				}).toList();

				response.setData(stockListResponseDtos);
				response.setMessage(env.getProperty("stockList.fetch.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				response.setMessage(env.getProperty(stockListFetchErrorMessage));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}
		} catch (Exception exp) {
			log.error("Exception Occured in getAllStockList Method present in StockListImpl class{}", exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS)
	public ApiResponse<StockListResponseDto> updateStockListById(StockListDto stockListDto, String id,
			Principal principal) {
		ApiResponse<StockListResponseDto> response = new ApiResponse<>();
		Optional<StockList> stockListDetails = stockListRepository.findById(id);
		Optional<StockList> existByName = stockListRepository.findByName(stockListDto.getName());
		try {

			if (stockListDetails.isPresent()) {
				StockList stockList = stockListDetails.get();

				if (existByName.isPresent() && !Objects.equals(stockList.getName(), stockListDto.getName())) {
					response.setResult(false);
					response.setMessage(env.getProperty("stocklist.name.error.message"));
					response.setStatus(HttpStatus.CONFLICT.value());
					return response;
				}
				Optional<Location> findByOriginName = locationRepository.findByName(stockListDto.getOrigin().getName());

				Optional<Location> findByDestinationName = locationRepository
						.findByName(stockListDto.getDestination().getName());

				if (!findByOriginName.isPresent()) {
					throw new BadApiRequestException(env.getProperty("stocklist.location.origin.error.message"));
				}

				if (!findByDestinationName.isPresent()) {
					throw new BadApiRequestException(env.getProperty("stocklist.location.destination.error.message"));
				}

				if (findByOriginName.get().getName().equals(findByDestinationName.get().getName())) {
					throw new BadApiRequestException(env.getProperty("stocklist.location.name.error.message"));
				}

				stockList.setUpdatedBy(principal.getName());

				stockList.setName(stockListDto.getName());
				stockList.setOrigin(findByOriginName.get());
				stockList.setDestination(findByDestinationName.get());
				stockList.setDescription(stockListDto.getDescription());
				stockList.setReplenishmentPeriodDays(stockListDto.getReplenishmentPeriodDays());
				stockList.setReplenishmentType(stockListDto.getReplenishmentType());
				stockList.setPublished(stockListDto.isPublished());
				modelMapper.getConfiguration().setAmbiguityIgnored(true);

				StockList updatedStockList = stockListRepository.save(stockList);

				response.setData(entityToDto(updatedStockList));
				response.setResult(true);
				response.setMessage(env.getProperty("stocklist.update.success.message"));
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				throw new BadApiRequestException(env.getProperty(stockListFetchErrorMessage));
			}

		} catch (Exception exp) {
			log.error("Exception Occured in updateStockListById Method present in StockListServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}

	}

	@Override
	public ApiResponse<StockListResponseDto> deleteStockListById(String id) {
		ApiResponse<StockListResponseDto> response = new ApiResponse<>();
		boolean existsById = stockListRepository.existsById(id);
		try {

			List<StockListItem> findByStockListId = stockListItemRepository.findByStockListId(id);
			if (!findByStockListId.isEmpty()) {
				throw new BadApiRequestException(env.getProperty("stocklist.stocklistitem.error.message"));
			}
			if (existsById) {
				stockListRepository.deleteById(id);
				response.setMessage(env.getProperty("stocklist.delete.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				response.setMessage(env.getProperty(stockListFetchErrorMessage));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}

		} catch (Exception exp) {
			log.error("Exception Occured in deleteStockListById Method present in StockListServiceImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<List<StockListResponseDto>> getAllStockListByOriginAndDestination(String originName,
			String destinationName) {
		ApiResponse<List<StockListResponseDto>> response = new ApiResponse<>();
		List<StockList> stockLists = stockListRepository.findStockListByOriginAndDestination(originName,
				destinationName);
		try {
			if (!stockLists.isEmpty()) {

				List<StockListResponseDto> stockListResponseDtos = stockLists.stream().map(this::entityToDto).toList();

				response.setData(stockListResponseDtos);
				response.setMessage(env.getProperty("stockList.fetch.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				return response;
			} else {
				response.setMessage(env.getProperty(stockListFetchErrorMessage));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}
		} catch (Exception exp) {
			log.error(
					"Exception Occured in getAllStockListByOriginAndDestination Method present in StockListImpl class{}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private StockListResponseDto entityToDto(StockList stockList) {

		StockListResponseDto stockListResponseDto = new StockListResponseDto();

		stockListResponseDto.setId(stockList.getId());
		stockListResponseDto.setName(stockList.getName());
		stockListResponseDto.setOrigin(stockList.getOrigin().getName());
		stockListResponseDto.setDestination(stockList.getDestination().getName());
		stockListResponseDto.setReplenishmentPeriodDays(stockList.getReplenishmentPeriodDays());
		stockListResponseDto.setReplenishmentType(stockList.getReplenishmentType());
		stockListResponseDto.setPublished(stockList.isPublished());
		stockListResponseDto.setDescription(stockList.getDescription());
		stockListResponseDto.setParty(stockList.getParty().getName());
		stockListResponseDto.setCreatedBy(stockList.getCreatedBy());
		stockListResponseDto.setUpdatedBy(stockList.getUpdatedBy());
		stockListResponseDto.setCreatedDate(stockList.getCreatedDate());
		stockListResponseDto.setUpdatedDate(stockList.getUpdatedDate());

		return stockListResponseDto;
	}

}
