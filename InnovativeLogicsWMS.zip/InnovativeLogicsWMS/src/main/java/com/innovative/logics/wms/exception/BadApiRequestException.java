package com.innovative.logics.wms.exception;

public class BadApiRequestException extends RuntimeException {
	
    /** long Short Description */
	private static final long serialVersionUID = 1L;

	public BadApiRequestException(String message) {
        super(message);
    }

    public BadApiRequestException() {
        super("Bad Request !!");
    }

}
