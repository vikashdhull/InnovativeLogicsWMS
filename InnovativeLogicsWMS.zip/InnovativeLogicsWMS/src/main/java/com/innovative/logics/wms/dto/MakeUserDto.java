package com.innovative.logics.wms.dto;

import java.util.Set;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MakeUserDto {
	
	private String id;

	@NotBlank(message = "User name should not be blank")
	private String username;

	private Boolean status= false;

	private Set<RoleDto> role;
	
	private Boolean isUser = false;

}
