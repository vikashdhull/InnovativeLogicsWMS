package com.innovative.logics.wms.service.impl;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.SynonymDto;
import com.innovative.logics.wms.entity.Product;
import com.innovative.logics.wms.entity.ProductPackage;
import com.innovative.logics.wms.entity.Synonym;
import com.innovative.logics.wms.repository.ProductRepository;
import com.innovative.logics.wms.repository.SynonymRepository;
import com.innovative.logics.wms.service.SynonymService;
import com.innovative.logics.wms.util.Utility;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SynonymServiceImpl implements SynonymService {

	@Autowired
	private SynonymRepository synonymRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private Environment env;

	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private Utility utility;

	@Override
	public ApiResponse<SynonymDto> createSynonym(SynonymDto synonymDto) {
		ApiResponse<SynonymDto> response = new ApiResponse<>();

		Optional<Synonym> findByName = synonymRepository.findByName(synonymDto.getName());

		try {

			if (findByName.isPresent()) {
				return errorResponse(response, HttpStatus.CONFLICT, "synonym.name.error.message");
			}

			Optional<Product> findProductByName = productRepository.findByName(synonymDto.getProduct().getName());

			Synonym synonym = modelMapper.map(synonymDto, Synonym.class);

			if (!findProductByName.isPresent()) {
				return errorResponse(response, HttpStatus.NOT_FOUND, "product.fetch.error.message");
			}

			synonym.setProduct(findProductByName.get());

			Synonym savedSynonym = synonymRepository.save(synonym);

			modelMapper.getConfiguration().setAmbiguityIgnored(true);
			SynonymDto newDto = modelMapper.map(savedSynonym, SynonymDto.class);

			response.setData(newDto);
			response.setResult(true);
			response.setMessage(env.getProperty("synonym.create.success.message"));
			response.setStatus(HttpStatus.CREATED.value());
			return response;

		} catch (Exception exp) {
			log.error("Exception Occurred in createSynonym Method present in SynonymServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public ApiResponse<SynonymDto> getSynonymById(String synonymId) {
		ApiResponse<SynonymDto> response = new ApiResponse<>();
		try {
			Optional<Synonym> synonymOptional = synonymRepository.findById(synonymId);

			if (synonymOptional.isPresent()) {
				modelMapper.getConfiguration().setAmbiguityIgnored(true);
				Synonym synonym = synonymOptional.get();
				SynonymDto synonymDto = modelMapper.map(synonym, SynonymDto.class);

				response.setMessage(env.getProperty("synonym.fetch.success.message"));
				response.setResult(true);
				response.setStatus(HttpStatus.OK.value());
				response.setData(synonymDto);
				return response;

			} else {
				return errorResponse(response, HttpStatus.NOT_FOUND, "synonym.fetch.error.message");
			}
		} catch (Exception exp) {
			log.error("Exception Occurred in getSynonymById Method present in SynonymServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	@Override
	public PageableResponse<SynonymDto> getSynonymByProductname(String productName, int pageNumber, int pageSize,
			String sortBy, String sortDir) {
		Sort sort = (sortDir.equalsIgnoreCase("desc")) ? (Sort.by(sortBy).descending()) : (Sort.by(sortBy).ascending());
		Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
		Page<ProductPackage> page = synonymRepository.findSynonymByProductName(productName, pageable);

		PageableResponse<SynonymDto> response = utility.getPageableResponse(page, SynonymDto.class);

		try {
			if (!response.getData().isEmpty()) {
				return response;
			} else {
				response.setMessage(env.getProperty("synonym.fetch.error.message"));
				response.setResult(false);
				response.setStatus(HttpStatus.NOT_FOUND.value());
				return response;
			}
		} catch (Exception exp) {
			log.error(
					"Exception Occurred in getSynonymByProductname Method present in SynonymServiceImpl class: {}",
					exp.getMessage());
			response.setMessage(exp.getMessage());
			response.setResult(false);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			return response;
		}
	}

	private ApiResponse<SynonymDto> errorResponse(ApiResponse<SynonymDto> response, HttpStatus status,
			String errorMessage) {
		response.setResult(false);
		response.setMessage(env.getProperty(errorMessage));
		response.setStatus(status.value());
		return response;
	}

}
