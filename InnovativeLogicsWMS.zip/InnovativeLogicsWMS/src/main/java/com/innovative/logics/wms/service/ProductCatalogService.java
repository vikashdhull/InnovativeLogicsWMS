package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.ProductCatalogDto;

public interface ProductCatalogService {

	/**
	 * 
	 * This method is used to create the ProductCatalog based on given details
	 * 
	 * @author manus
	 * @date 21-Jun-2023
	 * @param productCatalogDto
	 * @return
	 */
	ApiResponse<ProductCatalogDto> createProductCatalog(ProductCatalogDto productCatalogDto);

	/**
	 * 
	 * This method is used to update the Product Catalog details
	 * 
	 * @author manus
	 * @date 29-Jun-2023
	 * @param productCatalogDto
	 * @param productCatalogId
	 * @return
	 */
	ApiResponse<ProductCatalogDto> updateProductCatalog(ProductCatalogDto productCatalogDto, String productCatalogId);

	/**
	 * 
	 * This method is used to delete the Product Catalog based on id
	 * 
	 * @author manus
	 * @date 31-Aug-2023
	 * @param productCatalogId
	 * @return
	 */
	ApiResponse<ProductCatalogDto> deleteProductCatalogById(String productCatalogId);

	/**
	 * 
	 * This method is used to fetch the single Product Catalog details based on id
	 * 
	 * @author manus
	 * @date 24-Jun-2023
	 * @param productCatalogId
	 * @return
	 */
	ApiResponse<ProductCatalogDto> getProductCatalogById(String productCatalogId);

	/**
	 * 
	 * This method is used to fetch all the ProductCatalog.
	 * 
	 * @author manus
	 * @date 27-Jun-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	PageableResponse<ProductCatalogDto> getAllProductCatalog(String org, int pageNumber, int pageSize, String sortBy,
			String sortDir);
	
	ApiResponse<List<ProductCatalogDto>> getAllActiveProductCatalogs(String organization);

}
