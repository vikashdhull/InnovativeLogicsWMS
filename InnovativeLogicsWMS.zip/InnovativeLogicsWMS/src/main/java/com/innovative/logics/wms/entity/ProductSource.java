package com.innovative.logics.wms.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "product_source", uniqueConstraints = { @UniqueConstraint(columnNames = { "name", "code" }) })
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProductSource {

	@Column(name = "id")
	@Id
	@UuidGenerator
	private String id;
	
	@Column(name = "code", length = 50)
	private String code;
	
	@Column(name = "name", length = 50)
	private String name;
	
	@Column(name = "description", columnDefinition = "MEDIUMTEXT")
	private String description;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "product_id", referencedColumnName = "id")
	private Product product;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "supplier_id", referencedColumnName = "id")
	private Location location;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "manufacturer_id", referencedColumnName = "id")
	private Party party;
	
	@Column(name = "contract_price")
	private Double contractPrice;
	
	@Column(name = "contract_valid_until")
	private LocalDate contractValidUntil;
	
	@Column(name = "min_order_quantity")
	private Long minOrderQuantity;
	
	@Column(name = "rating_type")
	private String ratingType;
	
	@Column(name = "preference_type")
	private String preferenceType;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "organization_id", referencedColumnName="id")
	private Party org;
	
	@Column(name = "created_date", nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createdDate;

	@Column(name = "updated_date")
	@UpdateTimestamp
	private LocalDateTime updatedDate;
}