package com.innovative.logics.wms.dto.response;

import java.time.LocalDateTime;
import java.util.Set;

import com.innovative.logics.wms.dto.AddressDto;
import com.innovative.logics.wms.dto.RoleDto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LocationResponseDto {
	
	private String id;

	private String name;

	private String locationNumber;

	private String description;

	private String locationGroup;

	private String party;

	private String parentLocation;
	
	private AddressDto address;
	
	private Set<RoleDto> role;

	private LocalDateTime createdDate;

	private LocalDateTime updatedDate;

}
