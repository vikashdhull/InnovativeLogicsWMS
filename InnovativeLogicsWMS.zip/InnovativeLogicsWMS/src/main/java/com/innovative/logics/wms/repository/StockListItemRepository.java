package com.innovative.logics.wms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovative.logics.wms.entity.StockListItem;

public interface StockListItemRepository extends JpaRepository<StockListItem, String> {

	List<StockListItem> findByStockListId(String id);

	final String EXIST_STOCK_LIST_ITEM_BY_PRODUCTNAME = "SELECT CASE WHEN EXISTS (SELECT r.* FROM requisition_item r JOIN Product p ON r.product_id=p.id WHERE p.name = :productName) THEN 'true' ELSE 'false' END AS result";

	final String EXIST_STOCK_LIST_ITEM_BY_PRODUCT_AND_STOCKLIST = "SELECT CASE WHEN EXISTS (SELECT 1 FROM requisition_item ri JOIN product p ON ri.product_id = p.id "
			+ "JOIN requisition r ON ri.requistion_id = r.id WHERE p.name = :productName AND r.name = :requistionName) THEN 'true' ELSE 'false' END AS result";
	
	final String EXIST_PRODUCT_IN_STOCK_LIST_ITEM = "SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END FROM requisition_item ri WHERE ri.product_id = :productId";
	
	@Query(value = EXIST_STOCK_LIST_ITEM_BY_PRODUCTNAME, nativeQuery = true)
	boolean existStockListItemByProductName(String productName);
	
	@Query(value = EXIST_STOCK_LIST_ITEM_BY_PRODUCT_AND_STOCKLIST, nativeQuery = true)
	boolean existStockListItemByProductNameAndStockList(String productName,String requistionName);
	
	
	@Query(value = EXIST_PRODUCT_IN_STOCK_LIST_ITEM, nativeQuery = true)
	boolean existProductInStockListItem(String productId);

}
