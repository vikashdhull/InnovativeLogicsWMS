package com.innovative.logics.wms.service;

import java.security.Principal;

import org.springframework.web.multipart.MultipartFile;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.StockMovementDeliveryDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.dto.response.StockMovementResponseDto;

public interface StockMovementReceiveService {
	
	/**
	 * 
	 * This receiveStockMovement method is used to receive the stock movement, 
	 * and user will also able to partially receive the stock movement.
	 * 
	 * @author manus
	 * @date 15-Jan-2024
	 * @param stockMovementDeliveryDto
	 *  @param principle
	 * @return This will return ApiResponse with the StockMovementResponseDto
	 */
	ApiResponse<StockMovementResponseDto> receiveStockMovement(StockMovementDeliveryDto stockMovementDeliveryDto, 
			 Principal principal);
	  
	/**
	 * 
	 * This getAllStockMovementByOrigin method is used to fetch the stock movement by 
	 * location from goods are requested with requested page.
	 * 
	 * @author manus
	 * @date 16-Jan-2024
	 * @param origin
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return This will return PageableResponse with the list of StockMovementResponseDto
	 */
	PageableResponse<StockMovementResponseDto> getAllStockMovementByOrigin(String originName,
			int pageNumber, int pageSize, String sortBy, String sortDir);
	
	/**
	 * 
	 * This getAllStockMovementByDestination method is used to fetch the stock movement with 
	 * location where stock movement was create and where goods are delivered with requested page.
	 * 
	 * @author manus
	 * @date 17-Jan-2024
	 * @param destination
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return This will return PageableResponse with the StockMovementResponseDto
	 */
	PageableResponse<StockMovementResponseDto> getAllStockMovementByDestination(String destinationName,
			int pageNumber, int pageSize, String sortBy, String sortDir);
	
	/**
	 * 
	 * This uploadStockMovementDocuments method is used to upload documents related to stock movement with shipping number.
	 * 
	 * @author manus
	 * @date 18-Jan-2024
	 * @param stockMId
	 * @param file
	 * @param documentDto
	 * @param shipmentNumber
	 * @return This will return ApiResponse with the StockMovementResponseDto
	 */
	ApiResponse<StockMovementResponseDto> uploadStockMovementDocuments(String stockMId,
			MultipartFile file, String documentDto, String shipmentNumber);
	
	/**
	 * 
	 * This cancelStockMovement method is used to cancel the stock movement before shipping.
	 * 
	 * @author manus
	 * @date 19-Jan-2024
	 * @param orderName
	 * @param principal
	 * @return This will return ApiResponse with the StockMovementResponseDto
	 */
	ApiResponse<StockMovementResponseDto> cancelStockMovement(String orderName, 
			 Principal principal);
	
	/**
	 * 
	 * This findStockMovementById method is used to fetch the stock movement by orderId
	 * 
	 * @author manus
	 * @date 20-Jan-2024
	 * @param orderId
	 * @return This will return ApiResponse with the StockMovementResponseDto
	 */
	ApiResponse<StockMovementResponseDto> findById(String orderId);

}