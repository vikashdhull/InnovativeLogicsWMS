package com.innovative.logics.wms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.AttributeDto;
import com.innovative.logics.wms.dto.PageableResponse;
import com.innovative.logics.wms.service.AttributeService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/attributes")
@Slf4j
public class AttributeController {

	@Autowired
	private AttributeService attributeService;

	/**
	 * 
	 * The createAttribute method is used to create the Attribute and save the data
	 * in attribute and attributes_option table based on given details
	 * 
	 * @author manus
	 * @date 04-Jul-2023
	 * @param attributeDto
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PostMapping
	public ResponseEntity<ApiResponse<AttributeDto>> createAttribute(
			@Valid @RequestBody final AttributeDto attributeDto) {
		log.info("Enter in createAttribute Method present in AttributeController class");
		ApiResponse<AttributeDto> response = attributeService.createAttribute(attributeDto);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAttributeById method is used to fetch the single Attribute details
	 * from the attribute and attributes_option table based on id
	 * 
	 * @author manus
	 * @date 08-Jul-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@GetMapping("/{id}")
	public ResponseEntity<ApiResponse<AttributeDto>> getAttributeById(@PathVariable("id") final String id) {
		log.info("Enter in getAttributeById Method present in AttributeController class");
		ApiResponse<AttributeDto> response = attributeService.getAttributeById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The updateAttribute method is used to update the Attribute details based on
	 * id
	 * 
	 * @author manus
	 * @date 13-Jul-2023
	 * @param attributeDto
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER')")
	@PutMapping("/{id}")
	public ResponseEntity<ApiResponse<AttributeDto>> updateAttribute(
			@Valid @RequestBody final AttributeDto attributeDto, @PathVariable("id") final String id) {
		log.info("Enter in updateAttribute Method present in AttributeController class");
		ApiResponse<AttributeDto> response = attributeService.updateAttribute(attributeDto, id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The getAllAttribute method is used to fetch all the Attribute from the
	 * attribute and attributes_option table with Pagination and Sorting
	 * 
	 * @author manus
	 * @date 11-Jul-2023
	 * @param pageNumber
	 * @param pageSize
	 * @param sortBy
	 * @param sortDir
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN') or hasRole('MANAGER') or hasRole('BROWSER')")
	@GetMapping
	public ResponseEntity<PageableResponse<AttributeDto>> getAllAttribute(
			@RequestParam(value = "org", required = true) String name,
			@RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "25", required = false) int pageSize,
			@RequestParam(value = "sortBy", defaultValue = "name", required = false) String sortBy,
			@RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir) {
		log.info("Enter in getAllAttribute Method present in AttributeController class");

		PageableResponse<AttributeDto> response = attributeService.getAllAttribute(name, pageNumber, pageSize, sortBy,
				sortDir);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	/**
	 * 
	 * The deleteAttributeById method is used to delete the Attribute and option
	 * from the attribute and attribute_option table based on id
	 * 
	 * @author manus
	 * @date 30-Aug-2023
	 * @param id
	 * @return
	 */
	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<ApiResponse<AttributeDto>> deleteAttributeById(@PathVariable final String id) {
		log.info("Enter in deleteAttributeById Method present in AttributeController class");
		ApiResponse<AttributeDto> response = attributeService.deleteAttributeById(id);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@PreAuthorize("hasRole('SUPERADMIN') or hasRole('MANAGER') or hasRole('ADMIN') or hasRole('BROWSER')")
	@GetMapping("org")
	public ResponseEntity<ApiResponse<List<AttributeDto>>> getAllAttributesByOrganization(
			@RequestParam("name") String name) {
		log.info("Enter in getAllAttributesByOrganization Method present in AttributeController class");

		ApiResponse<List<AttributeDto>> response = attributeService.getAllAttributesByOrganization(name);

		return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
