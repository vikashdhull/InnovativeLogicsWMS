package com.innovative.logics.wms.service;

import java.util.List;

import com.innovative.logics.wms.dto.ApiResponse;
import com.innovative.logics.wms.dto.RoleDto;

public interface RoleService {

	/**
	 * 
	 * This method is used to create the new Role
	 * 
	 * @author manus
	 * @date 28-Feb-2023
	 * @param roleDto
	 * @return
	 */
	ApiResponse<RoleDto> createRole(RoleDto roleDto);

	/**
	 * 
	 * This method is used to update the existing Role
	 * 
	 * @author manus
	 * @date 19-May-2023
	 * @param roleDto
	 * @return
	 */
	ApiResponse<RoleDto> updateRole(RoleDto roleDto, String id);

	/**
	 * 
	 * This method is used to delete the Role based on id
	 * 
	 * @author manus
	 * @date 27-Apr-2023
	 * @param roleId
	 * @return
	 */
	ApiResponse<RoleDto> deleteRole(String roleId);

	/**
	 * 
	 * This method is used to get the single Role based on given roleName
	 * 
	 * @author manus
	 * @date 01-Mar-2023
	 * @param roleName
	 * @return
	 */
	ApiResponse<RoleDto> getRoleByRoleName(String roleName);

	/**
	 * 
	 * This method is used to get all the Roles
	 * 
	 * @author manus
	 * @date 24-Mar-2023
	 * @return
	 */
	ApiResponse<List<RoleDto>> getAllRoles();

	/**
	 * 
	 * This method is used to get all the Roles based on given role code
	 * 
	 * @author manus
	 * @date 27-Apr-2023
	 * @param roleCode
	 * @return
	 */
	ApiResponse<List<RoleDto>> getRolesByCode(String roleCode);

}
