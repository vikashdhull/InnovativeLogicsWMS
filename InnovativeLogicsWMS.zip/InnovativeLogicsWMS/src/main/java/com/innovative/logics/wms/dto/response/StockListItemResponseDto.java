package com.innovative.logics.wms.dto.response;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class StockListItemResponseDto {

	private String id;

	private String product;
	
	private Double unitCost;

	private String stockList;
	
	private Double quantity;

	private Double totalCost;

}
