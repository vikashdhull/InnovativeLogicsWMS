package com.innovative.logics.wms.entity;

import java.time.LocalDate;


import java.util.HashSet;
import java.util.Set;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "stock_movement_item")
@Getter
@Setter
public class StockMovementItem {
	
	@Column(name = "id")
	@Id
	@UuidGenerator
	private String id;	
	
	@Column(name = "comments", length = 150)
	private String comments;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "stock_movement_id", referencedColumnName = "id")
	private StockMovement stockMovement;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "product_id", referencedColumnName = "id")
	private Product product;
	
	@Column(name = "quantity")
	private Long quantity;
	
	@Column(name = "shipped_quantity")
	private Long shippedQuantity;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "requested_by", referencedColumnName = "id")
	private User requestedBy;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "received_by", referencedColumnName = "id")
	private User receivedBy;
	
	@Column(name = "date_received")
	private LocalDate receivedDate;
	
	@ManyToOne(optional = true)
	@JoinColumn(name = "shipped_by", referencedColumnName = "id")
	private User shippedby;

	@Column(name = "shipping_date")
	private LocalDate shippedDate;
	
	@Column(name = "shipment_type_name")
	private String shipmentTypeName;
	
	@Column(name = "driver_name")
	private String driverName;
	
	private String status;

	@Column(name = "shipment_number")
	private String shipmentNumber;
	
	@Column(name = "expected_shipping_date")
	private LocalDate expectedShippingDate;
	
	@Column(name = "expected_delivery_date")
	private LocalDate expectedDeliveryDate;

	private Long receivedQuantity;

	private Long remainingQuantity;

	@Column(name = "is_split_item")
	private boolean isSplitItem;

	@Column(name = "total_value", length = 15)
	private Double totalValue;

	@Column(name = "additional_information")
	private String additionalInformation;

	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	@JoinTable(name = "stock_movement_item_document", joinColumns = @JoinColumn(name = "stock_movement_item_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "document_id", referencedColumnName = "id"))
	private Set<Document> documents = new HashSet<>();

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "updated_by")
	private String updatedBy;
	
}
