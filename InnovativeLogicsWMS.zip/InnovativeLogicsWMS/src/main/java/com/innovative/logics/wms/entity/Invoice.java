package com.innovative.logics.wms.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "invoice")
@Getter
@Setter
public class Invoice {

	@Column(name = "id")
	@Id
	@UuidGenerator
	private String id;
	
	@Column(name = "invoice_number")
	private String invoiceNumber;
	
	@Column(name = "issue_date")
	@CreationTimestamp
	private LocalDateTime issueDate;
	
	@Column(name = "total_amount")
	private Double totalAmount;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "order_id", referencedColumnName = "id")
	private Order order;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinColumn(name = "created_by", referencedColumnName = "id")
	private User createdBy;

}
